<?php
/**
 * Title: Customer reviews
 * Slug: tradewell/reviews
 * Categories: tradewell, testimonials
 * Keywords: reviews, testimonials, quotes
 * Description: Placeholder reviews. Replace with real reviews from your customers.
 *
 * @package Tradewell
 */

$tradewell_reviews = array(
	array( __( 'Our AC quit on the hottest day of the year. They were here in under an hour, quoted a price before starting and had it running by dinner.', 'tradewell' ), __( 'Homeowner, North District', 'tradewell' ), __( 'AC repair', 'tradewell' ) ),
	array( __( 'Three companies told us we needed a new roof. These folks found the actual leak, fixed it for a fraction of the cost and sent photos of everything.', 'tradewell' ), __( 'Homeowner, Riverside', 'tradewell' ), __( 'Roof repair', 'tradewell' ) ),
	array( __( 'The panel upgrade and EV charger were done in one day. The electrician explained every step and pulled the permit for us.', 'tradewell' ), __( 'Homeowner, Oak Hills', 'tradewell' ), __( 'Electrical', 'tradewell' ) ),
);
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"margin":{"top":"0"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull" style="margin-top:0;padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:group {"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|50"}}},"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
<div class="wp-block-group" style="margin-bottom:var(--wp--preset--spacing--50)">
<!-- wp:group {"style":{"spacing":{"blockGap":"0.5rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group">
<!-- wp:paragraph {"className":"is-style-tw-eyebrow"} -->
<p class="is-style-tw-eyebrow"><?php esc_html_e( 'Reviews', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading"><?php esc_html_e( 'Neighbors who called us back', 'tradewell' ); ?></h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size"><span class="tw-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span> <strong>4.9</strong> <?php esc_html_e( 'average rating', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|40"}}}} -->
<div class="wp-block-columns">
<?php foreach ( $tradewell_reviews as $tradewell_r ) : ?>
<!-- wp:column {"className":"is-style-tw-card","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"}}}} -->
<div class="wp-block-column is-style-tw-card" style="padding:var(--wp--preset--spacing--40)">
<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size"><span class="tw-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p>&ldquo;<?php echo esc_html( $tradewell_r[0] ); ?>&rdquo;</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"textColor":"muted","fontSize":"x-small"} -->
<p class="has-muted-color has-text-color has-x-small-font-size"><strong><?php echo esc_html( $tradewell_r[1] ); ?></strong> &middot; <?php echo esc_html( $tradewell_r[2] ); ?></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
<?php endforeach; ?>
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->
