<?php
/**
 * Title: About: our story
 * Slug: tradewell/about-story
 * Categories: tradewell, about
 * Keywords: about, story, history, values
 *
 * @package Tradewell
 */

?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"margin":{"top":"0"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull" style="margin-top:0;padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns">
<!-- wp:column {"width":"55%"} -->
<div class="wp-block-column" style="flex-basis:55%">
<!-- wp:paragraph {"className":"is-style-tw-eyebrow"} -->
<p class="is-style-tw-eyebrow"><?php esc_html_e( 'Our story', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading"><?php esc_html_e( 'Started with one truck and a promise to show up on time', 'tradewell' ); ?></h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p><?php esc_html_e( 'We started as a two-person crew answering emergency calls on nights and weekends, the jobs bigger companies would not take. Word spread because we did something simple: we quoted a price before starting, and we stuck to it.', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph -->
<p><?php esc_html_e( 'Today we are a team of licensed technicians across heating, cooling, plumbing, roofing, electrical and solar. The promise has not changed.', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
<!-- wp:column {"width":"45%"} -->
<div class="wp-block-column" style="flex-basis:45%">
<!-- wp:group {"style":{"border":{"radius":"20px"},"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"backgroundColor":"surface","layout":{"type":"default"}} -->
<div class="wp-block-group has-surface-background-color has-background" style="border-radius:20px;padding:var(--wp--preset--spacing--50)">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><?php esc_html_e( 'What we stand for', 'tradewell' ); ?></h3>
<!-- /wp:heading -->
<!-- wp:list {"className":"is-style-tw-checklist"} -->
<ul class="wp-block-list is-style-tw-checklist">
<!-- wp:list-item --><li><strong><?php esc_html_e( 'Honest pricing.', 'tradewell' ); ?></strong> <?php esc_html_e( 'The price we quote is the price you pay.', 'tradewell' ); ?></li><!-- /wp:list-item -->
<!-- wp:list-item --><li><strong><?php esc_html_e( 'Respect for your home.', 'tradewell' ); ?></strong> <?php esc_html_e( 'Shoe covers, drop cloths, full clean-up.', 'tradewell' ); ?></li><!-- /wp:list-item -->
<!-- wp:list-item --><li><strong><?php esc_html_e( 'Work we stand behind.', 'tradewell' ); ?></strong> <?php esc_html_e( 'Every job guaranteed for a full year.', 'tradewell' ); ?></li><!-- /wp:list-item -->
<!-- wp:list-item --><li><strong><?php esc_html_e( 'Straight answers.', 'tradewell' ); ?></strong> <?php esc_html_e( 'Repair or replace, we tell you what we would do in your shoes.', 'tradewell' ); ?></li><!-- /wp:list-item -->
</ul>
<!-- /wp:list -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->
