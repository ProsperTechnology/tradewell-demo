<?php
/**
 * Title: Service detail
 * Slug: tradewell/service-detail
 * Categories: tradewell, services
 * Keywords: service, detail, landing, repair
 * Description: A complete service landing section: symptoms, what is included, starting price and guarantee.
 *
 * @package Tradewell
 */

?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"margin":{"top":"0"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull" style="margin-top:0;padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns">
<!-- wp:column {"width":"60%"} -->
<div class="wp-block-column" style="flex-basis:60%">
<!-- wp:heading -->
<h2 class="wp-block-heading"><?php esc_html_e( 'Signs you need a repair', 'tradewell' ); ?></h2>
<!-- /wp:heading -->
<!-- wp:list {"className":"is-style-tw-checklist"} -->
<ul class="wp-block-list is-style-tw-checklist">
<!-- wp:list-item --><li><?php esc_html_e( 'Warm air or weak airflow from vents', 'tradewell' ); ?></li><!-- /wp:list-item -->
<!-- wp:list-item --><li><?php esc_html_e( 'Unusual noises, smells or short cycling', 'tradewell' ); ?></li><!-- /wp:list-item -->
<!-- wp:list-item --><li><?php esc_html_e( 'Energy bills climbing for no clear reason', 'tradewell' ); ?></li><!-- /wp:list-item -->
<!-- wp:list-item --><li><?php esc_html_e( 'Water pooling around the indoor unit', 'tradewell' ); ?></li><!-- /wp:list-item -->
</ul>
<!-- /wp:list -->
<!-- wp:heading {"style":{"spacing":{"margin":{"top":"var:preset|spacing|50"}}}} -->
<h2 class="wp-block-heading" style="margin-top:var(--wp--preset--spacing--50)"><?php esc_html_e( 'What every visit includes', 'tradewell' ); ?></h2>
<!-- /wp:heading -->
<!-- wp:paragraph -->
<p><?php esc_html_e( 'A full diagnostic, a written flat-rate price with options, the repair itself, a system test, clean-up and a one-year guarantee on parts and labor.', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
<!-- wp:column {"width":"40%"} -->
<div class="wp-block-column" style="flex-basis:40%">
<!-- wp:group {"className":"is-style-tw-card","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group is-style-tw-card" style="padding:var(--wp--preset--spacing--50)">
<!-- wp:paragraph {"className":"is-style-tw-eyebrow"} -->
<p class="is-style-tw-eyebrow"><?php esc_html_e( 'Starting at', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"tw-plan-price"} -->
<p class="tw-plan-price"><strong>$89</strong> <span><?php esc_html_e( 'diagnostic', 'tradewell' ); ?></span></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"textColor":"muted","fontSize":"small"} -->
<p class="has-muted-color has-text-color has-small-font-size"><?php esc_html_e( 'Waived when you approve the repair.', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"width":100} -->
<div class="wp-block-button has-custom-width wp-block-button__width-100"><a class="wp-block-button__link wp-element-button" href="#quote"><?php esc_html_e( 'Get my estimate', 'tradewell' ); ?></a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
<!-- wp:paragraph {"align":"center","textColor":"muted","fontSize":"x-small"} -->
<p class="has-text-align-center has-muted-color has-text-color has-x-small-font-size"><?php esc_html_e( 'Backed by our 1-year guarantee', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->
