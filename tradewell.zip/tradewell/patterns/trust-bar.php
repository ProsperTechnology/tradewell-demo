<?php
/**
 * Title: Trust bar
 * Slug: tradewell/trust-bar
 * Categories: tradewell
 * Keywords: trust, badges, guarantee
 *
 * @package Tradewell
 */

$tradewell_items = array(
	'shield' => array( __( 'Licensed &amp; insured', 'tradewell' ), __( 'Fully bonded, every tech', 'tradewell' ) ),
	'clock'  => array( __( '60-minute arrival', 'tradewell' ), __( 'For emergency calls', 'tradewell' ) ),
	'tag'    => array( __( 'Upfront pricing', 'tradewell' ), __( 'Approve before we start', 'tradewell' ) ),
	'star'   => array( __( '1-year guarantee', 'tradewell' ), __( 'On parts and labor', 'tradewell' ) ),
);
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40"},"margin":{"top":"0"}},"border":{"bottom":{"color":"var:preset|color|border","width":"1px","style":"solid"}}},"backgroundColor":"surface","layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull has-surface-background-color has-background" style="border-bottom-color:var(--wp--preset--color--border);border-bottom-style:solid;border-bottom-width:1px;margin-top:0;padding-top:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--40)">
<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|40"}},"layout":{"type":"grid","minimumColumnWidth":"14rem"}} -->
<div class="wp-block-group">
<?php foreach ( $tradewell_items as $tradewell_icon => $tradewell_text ) : ?>
<!-- wp:group {"style":{"spacing":{"blockGap":"0.75rem"}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group">
<!-- wp:html -->
<span class="tw-icon" style="color:var(--wp--preset--color--primary);display:inline-flex"><?php echo tradewell_icon( $tradewell_icon, 34 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?></span>
<!-- /wp:html -->
<!-- wp:paragraph {"style":{"typography":{"lineHeight":"1.3"}},"fontSize":"small"} -->
<p class="has-small-font-size" style="line-height:1.3"><strong><?php echo wp_kses_post( $tradewell_text[0] ); ?></strong><br><?php echo wp_kses_post( $tradewell_text[1] ); ?></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<?php endforeach; ?>
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
