<?php
/**
 * Title: Contact details
 * Slug: tradewell/contact-info
 * Categories: tradewell, contact
 * Keywords: contact, address, hours, email, phone
 *
 * @package Tradewell
 */

$tradewell_items = array(
	array( 'phone', __( 'Call or text', 'tradewell' ), __( '(555) 010-0199', 'tradewell' ), __( 'Answered 24/7', 'tradewell' ) ),
	array( 'quote', __( 'Email', 'tradewell' ), __( 'hello@example.com', 'tradewell' ), __( 'Replies within one business day', 'tradewell' ) ),
	array( 'pin', __( 'Visit', 'tradewell' ), __( '123 Main Street, Your City', 'tradewell' ), __( 'Showroom open weekdays', 'tradewell' ) ),
	array( 'clock', __( 'Hours', 'tradewell' ), __( 'Mon&ndash;Fri 7am&ndash;7pm', 'tradewell' ), __( 'Sat 8am&ndash;4pm, emergencies 24/7', 'tradewell' ) ),
);
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"},"margin":{"top":"0"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull" style="margin-top:0;padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">
<!-- wp:heading {"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}}} -->
<h2 class="wp-block-heading" style="margin-bottom:var(--wp--preset--spacing--40)"><?php esc_html_e( 'Get in touch', 'tradewell' ); ?></h2>
<!-- /wp:heading -->
<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|40"}},"layout":{"type":"grid","minimumColumnWidth":"14rem"}} -->
<div class="wp-block-group">
<?php foreach ( $tradewell_items as $tradewell_i ) : ?>
<!-- wp:group {"className":"is-style-tw-card","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"blockGap":"0.4rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group is-style-tw-card" style="padding:var(--wp--preset--spacing--40)">
<!-- wp:html -->
<span class="tw-icon tw-icon-chip" aria-hidden="true"><?php echo tradewell_icon( $tradewell_i[0], 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?></span>
<!-- /wp:html -->
<!-- wp:heading {"level":3,"fontSize":"medium","style":{"spacing":{"margin":{"top":"var:preset|spacing|20"}}}} -->
<h3 class="wp-block-heading has-medium-font-size" style="margin-top:var(--wp--preset--spacing--20)"><?php echo esc_html( $tradewell_i[1] ); ?></h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"style":{"typography":{"fontWeight":"700"}}} -->
<p style="font-weight:700"><?php echo wp_kses_post( $tradewell_i[2] ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"textColor":"muted","fontSize":"small"} -->
<p class="has-muted-color has-text-color has-small-font-size"><?php echo wp_kses_post( $tradewell_i[3] ); ?></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<?php endforeach; ?>
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
