<?php
/**
 * Title: Team / technicians
 * Slug: tradewell/team
 * Categories: tradewell, team
 * Keywords: team, staff, technicians, about
 * Description: Initial avatars by default. Replace each with a photo of your technician.
 *
 * @package Tradewell
 */

$tradewell_team = array(
	array( 'MR', __( 'Maria R.', 'tradewell' ), __( 'Lead HVAC technician', 'tradewell' ), __( '14 years experience', 'tradewell' ) ),
	array( 'DK', __( 'Devon K.', 'tradewell' ), __( 'Master plumber', 'tradewell' ), __( '11 years experience', 'tradewell' ) ),
	array( 'SL', __( 'Sam L.', 'tradewell' ), __( 'Licensed electrician', 'tradewell' ), __( '9 years experience', 'tradewell' ) ),
	array( 'AT', __( 'Ana T.', 'tradewell' ), __( 'Roofing &amp; solar lead', 'tradewell' ), __( '12 years experience', 'tradewell' ) ),
);
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"margin":{"top":"0"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull" style="margin-top:0;padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:paragraph {"className":"is-style-tw-eyebrow"} -->
<p class="is-style-tw-eyebrow"><?php esc_html_e( 'Our team', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:heading {"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|50"}}}} -->
<h2 class="wp-block-heading" style="margin-bottom:var(--wp--preset--spacing--50)"><?php esc_html_e( 'The people who show up at your door', 'tradewell' ); ?></h2>
<!-- /wp:heading -->
<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|40"}},"layout":{"type":"grid","minimumColumnWidth":"14rem"}} -->
<div class="wp-block-group">
<?php foreach ( $tradewell_team as $tradewell_m ) : ?>
<!-- wp:group {"className":"is-style-tw-card","style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"blockGap":"0.35rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group is-style-tw-card" style="padding:var(--wp--preset--spacing--40)">
<!-- wp:html -->
<span class="tw-avatar" aria-hidden="true"><?php echo esc_html( $tradewell_m[0] ); ?></span>
<!-- /wp:html -->
<!-- wp:heading {"level":3,"fontSize":"medium","style":{"spacing":{"margin":{"top":"var:preset|spacing|30"}}}} -->
<h3 class="wp-block-heading has-medium-font-size" style="margin-top:var(--wp--preset--spacing--30)"><?php echo esc_html( $tradewell_m[1] ); ?></h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size"><?php echo wp_kses_post( $tradewell_m[2] ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"textColor":"muted","fontSize":"x-small"} -->
<p class="has-muted-color has-text-color has-x-small-font-size"><?php echo esc_html( $tradewell_m[3] ); ?></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<?php endforeach; ?>
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
