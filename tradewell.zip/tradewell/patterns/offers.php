<?php
/**
 * Title: Special offers (coupons)
 * Slug: tradewell/offers
 * Categories: tradewell, call-to-action
 * Keywords: coupon, offer, deal, discount, promotion
 * Description: Coupon-style offers. Edit amounts and terms to match your promotions.
 *
 * @package Tradewell
 */

$tradewell_offers = array(
	array( '$50', __( 'off any repair over $300', 'tradewell' ), __( 'Heating, cooling, plumbing or electrical.', 'tradewell' ) ),
	array( '$89', __( 'AC or furnace tune-up', 'tradewell' ), __( '21-point safety and efficiency check.', 'tradewell' ) ),
	array( __( 'Free', 'tradewell' ), __( 'second opinion', 'tradewell' ), __( 'Told you need a replacement? Let us take a look.', 'tradewell' ) ),
);
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"margin":{"top":"0"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull" style="margin-top:0;padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:group {"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|50"}}},"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"bottom"}} -->
<div class="wp-block-group" style="margin-bottom:var(--wp--preset--spacing--50)">
<!-- wp:group {"style":{"spacing":{"blockGap":"0.5rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group">
<!-- wp:paragraph {"className":"is-style-tw-eyebrow"} -->
<p class="is-style-tw-eyebrow"><?php esc_html_e( 'Current offers', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading"><?php esc_html_e( 'Save on your next visit', 'tradewell' ); ?></h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
<!-- wp:paragraph {"textColor":"muted","fontSize":"small"} -->
<p class="has-muted-color has-text-color has-small-font-size"><?php esc_html_e( 'Mention the offer when you book. One offer per visit.', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|40"}}}} -->
<div class="wp-block-columns">
<?php foreach ( $tradewell_offers as $tradewell_o ) : ?>
<!-- wp:column {"className":"tw-coupon"} -->
<div class="wp-block-column tw-coupon">
<!-- wp:paragraph {"className":"tw-coupon-amount"} -->
<p class="tw-coupon-amount"><?php echo esc_html( $tradewell_o[0] ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><?php echo esc_html( $tradewell_o[1] ); ?></h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"muted","fontSize":"small"} -->
<p class="has-muted-color has-text-color has-small-font-size"><?php echo esc_html( $tradewell_o[2] ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"style":{"typography":{"fontWeight":"700"}},"fontSize":"small"} -->
<p class="has-small-font-size" style="font-weight:700"><a href="#quote"><?php esc_html_e( 'Claim offer', 'tradewell' ); ?> &rarr;</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
<?php endforeach; ?>
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->
