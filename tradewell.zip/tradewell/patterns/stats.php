<?php
/**
 * Title: Stats band
 * Slug: tradewell/stats
 * Categories: tradewell
 * Keywords: numbers, stats, counter, proof
 *
 * @package Tradewell
 */

$tradewell_stats = array(
	array( '18', __( 'years serving local homes', 'tradewell' ) ),
	array( '24k+', __( 'jobs completed', 'tradewell' ) ),
	array( '4.9', __( 'average customer rating', 'tradewell' ) ),
	array( '60', __( 'minute emergency response', 'tradewell' ) ),
);
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"},"margin":{"top":"0"}}},"backgroundColor":"primary-dark","textColor":"on-primary","layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull has-on-primary-color has-primary-dark-background-color has-text-color has-background" style="margin-top:0;padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">
<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|40"}},"layout":{"type":"grid","minimumColumnWidth":"12rem"}} -->
<div class="wp-block-group">
<?php foreach ( $tradewell_stats as $tradewell_s ) : ?>
<!-- wp:group {"className":"tw-stat","layout":{"type":"default"}} -->
<div class="wp-block-group tw-stat">
<!-- wp:paragraph {"className":"tw-stat-num"} -->
<p class="tw-stat-num"><?php echo esc_html( $tradewell_s[0] ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"style":{"color":{"text":"#ffffffcc"}},"fontSize":"small"} -->
<p class="has-text-color has-small-font-size" style="color:#ffffffcc"><?php echo esc_html( $tradewell_s[1] ); ?></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<?php endforeach; ?>
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
