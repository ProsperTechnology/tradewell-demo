<?php
/**
 * Title: Hero with illustration and trade bar
 * Slug: tradewell/hero
 * Categories: tradewell, banner
 * Keywords: hero, header, banner, intro
 * Viewport width: 1400
 *
 * @package Tradewell
 */

$tradewell_trades = array(
	'hvac'       => __( 'Heating &amp; cooling', 'tradewell' ),
	'plumbing'   => __( 'Plumbing', 'tradewell' ),
	'roofing'    => __( 'Roofing', 'tradewell' ),
	'electrical' => __( 'Electrical', 'tradewell' ),
	'solar'      => __( 'Solar', 'tradewell' ),
	'wrench'     => __( 'Everything else', 'tradewell' ),
);
?>
<!-- wp:group {"align":"full","className":"tw-hero","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"margin":{"top":"0"}},"elements":{"link":{"color":{"text":"var:preset|color|on-primary"}}}},"backgroundColor":"primary","textColor":"on-primary","layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull tw-hero has-on-primary-color has-primary-background-color has-text-color has-background has-link-color" style="margin-top:0;padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center","width":"52%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:52%">
<!-- wp:paragraph {"className":"is-style-tw-eyebrow","style":{"color":{"text":"var:preset|color|highlight"}}} -->
<p class="is-style-tw-eyebrow has-text-color" style="color:var(--wp--preset--color--highlight)"><?php esc_html_e( 'Same-day service across the metro', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":1,"style":{"color":{"text":"var:preset|color|on-primary"},"typography":{"fontSize":"clamp(2.4rem, 4.6vw, 3.9rem)"}}} -->
<h1 class="wp-block-heading has-text-color" style="color:var(--wp--preset--color--on-primary);font-size:clamp(2.4rem, 4.6vw, 3.9rem)"><?php esc_html_e( 'Fixed right the first time. Priced before we start.', 'tradewell' ); ?></h1>
<!-- /wp:heading -->
<!-- wp:paragraph {"fontSize":"large","style":{"color":{"text":"#ffffffd9"}}} -->
<p class="has-text-color has-large-font-size" style="color:#ffffffd9"><?php esc_html_e( 'Licensed technicians for heating, cooling, plumbing, roofing, electrical and solar. Get an instant estimate in under a minute.', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|30","margin":{"top":"var:preset|spacing|40"}}},"layout":{"type":"flex","flexWrap":"wrap"}} -->
<div class="wp-block-group" style="margin-top:var(--wp--preset--spacing--40)">
<!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#quote"><?php esc_html_e( 'Get my free estimate', 'tradewell' ); ?></a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
<!-- wp:twl/phone {"variant":"outline"} /-->
</div>
<!-- /wp:group -->
<!-- wp:list {"className":"is-style-tw-checklist","style":{"spacing":{"margin":{"top":"var:preset|spacing|40"}}},"fontSize":"small"} -->
<ul style="margin-top:var(--wp--preset--spacing--40)" class="wp-block-list is-style-tw-checklist has-small-font-size">
<!-- wp:list-item --><li><?php esc_html_e( 'No overtime charges, nights or weekends', 'tradewell' ); ?></li><!-- /wp:list-item -->
<!-- wp:list-item --><li><?php esc_html_e( 'Background-checked, uniformed technicians', 'tradewell' ); ?></li><!-- /wp:list-item -->
<!-- wp:list-item --><li><?php esc_html_e( '1-year workmanship guarantee on every job', 'tradewell' ); ?></li><!-- /wp:list-item -->
</ul>
<!-- /wp:list -->
</div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center","width":"48%"} -->
<div class="wp-block-column is-vertically-aligned-center" style="flex-basis:48%">
<!-- wp:html -->
<?php echo tradewell_illustration_house(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG with escaped strings. ?>
<!-- /wp:html -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
<!-- wp:group {"className":"tw-trade-strip","style":{"border":{"radius":"16px"},"spacing":{"padding":{"top":"0.75rem","bottom":"0.75rem","left":"0.75rem","right":"0.75rem"},"margin":{"top":"var:preset|spacing|60"}},"shadow":"var:preset|shadow|lifted","elements":{"link":{"color":{"text":"var:preset|color|contrast"}}}},"backgroundColor":"base","textColor":"contrast","layout":{"type":"grid","minimumColumnWidth":"11.5rem"}} -->
<div class="wp-block-group tw-trade-strip has-contrast-color has-base-background-color has-text-color has-background has-link-color" style="border-radius:16px;box-shadow:var(--wp--preset--shadow--lifted);margin-top:var(--wp--preset--spacing--60);padding:0.75rem">
<?php foreach ( $tradewell_trades as $tradewell_icon => $tradewell_label ) : ?>
<!-- wp:html -->
<a class="tw-trade-link" href="#quote"><span class="tw-icon" aria-hidden="true"><?php echo tradewell_icon( $tradewell_icon, 26 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?></span><span><?php echo wp_kses_post( $tradewell_label ); ?></span></a>
<!-- /wp:html -->
<?php endforeach; ?>
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
