<?php
/**
 * Title: Services grid
 * Slug: tradewell/services-grid
 * Categories: tradewell, services
 * Keywords: services, trades, grid
 *
 * @package Tradewell
 */

$tradewell_services = array(
	'hvac'       => array( __( 'Heating &amp; cooling', 'tradewell' ), __( 'AC repair, furnace tune-ups, heat pumps and full system replacements with financing.', 'tradewell' ) ),
	'plumbing'   => array( __( 'Plumbing &amp; drains', 'tradewell' ), __( 'Leaks, clogs, water heaters, repiping and sewer camera inspections.', 'tradewell' ) ),
	'roofing'    => array( __( 'Roofing', 'tradewell' ), __( 'Storm damage, leak repair and full replacements with insurance claim help.', 'tradewell' ) ),
	'electrical' => array( __( 'Electrical', 'tradewell' ), __( 'Panel upgrades, EV chargers, lighting, outlets and safety inspections.', 'tradewell' ) ),
	'solar'      => array( __( 'Solar &amp; batteries', 'tradewell' ), __( 'Custom solar design, battery backup and monitoring with clear payback numbers.', 'tradewell' ) ),
	'wrench'     => array( __( 'Maintenance plans', 'tradewell' ), __( 'Seasonal check-ups, priority scheduling and member discounts on repairs.', 'tradewell' ) ),
);
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"margin":{"top":"0"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull" style="margin-top:0;padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:group {"style":{"spacing":{"blockGap":"0.5rem","margin":{"bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"680px","justifyContent":"left"}} -->
<div class="wp-block-group" style="margin-bottom:var(--wp--preset--spacing--50)">
<!-- wp:paragraph {"className":"is-style-tw-eyebrow"} -->
<p class="is-style-tw-eyebrow"><?php esc_html_e( 'What we do', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading"><?php esc_html_e( 'One call for every system in your home', 'tradewell' ); ?></h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color"><?php esc_html_e( 'Specialist crews for each trade, one team accountable for the whole job.', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|40"}},"layout":{"type":"grid","minimumColumnWidth":"20rem"}} -->
<div class="wp-block-group">
<?php foreach ( $tradewell_services as $tradewell_icon => $tradewell_text ) : ?>
<!-- wp:group {"className":"is-style-tw-card","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"blockGap":"0.75rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group is-style-tw-card" style="padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--40)">
<!-- wp:html -->
<span class="tw-icon" style="color:var(--wp--preset--color--primary);display:inline-flex"><?php echo tradewell_icon( $tradewell_icon, 44 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?></span>
<!-- /wp:html -->
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><?php echo wp_kses_post( $tradewell_text[0] ); ?></h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"muted","fontSize":"small"} -->
<p class="has-muted-color has-text-color has-small-font-size"><?php echo wp_kses_post( $tradewell_text[1] ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"style":{"typography":{"fontWeight":"700"}},"fontSize":"small"} -->
<p class="has-small-font-size" style="font-weight:700"><a href="#quote"><?php esc_html_e( 'Get a price', 'tradewell' ); ?> &rarr;</a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<?php endforeach; ?>
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
