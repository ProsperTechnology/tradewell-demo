<?php
/**
 * Title: Maintenance plans (pricing)
 * Slug: tradewell/plans
 * Categories: tradewell, call-to-action
 * Keywords: pricing, plans, membership, maintenance, subscription
 *
 * @package Tradewell
 */

$tradewell_plans = array(
	array(
		'name'     => __( 'Essential', 'tradewell' ),
		'price'    => '$14',
		'note'     => __( 'One system, peace of mind', 'tradewell' ),
		'features' => array( __( 'Yearly tune-up for one system', 'tradewell' ), __( '10% off repairs', 'tradewell' ), __( 'No overtime fees', 'tradewell' ) ),
		'featured' => false,
	),
	array(
		'name'     => __( 'Priority', 'tradewell' ),
		'price'    => '$24',
		'note'     => __( 'Most popular for families', 'tradewell' ),
		'features' => array( __( 'Heating and cooling tune-ups', 'tradewell' ), __( 'Plumbing safety inspection', 'tradewell' ), __( '15% off repairs', 'tradewell' ), __( 'Front-of-line scheduling', 'tradewell' ) ),
		'featured' => true,
	),
	array(
		'name'     => __( 'Total Home', 'tradewell' ),
		'price'    => '$39',
		'note'     => __( 'Every system, fully covered', 'tradewell' ),
		'features' => array( __( 'All tune-ups and inspections', 'tradewell' ), __( 'Roof and electrical check', 'tradewell' ), __( '20% off repairs', 'tradewell' ), __( 'Waived emergency fee', 'tradewell' ) ),
		'featured' => false,
	),
);
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"margin":{"top":"0"}}},"backgroundColor":"surface","layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull has-surface-background-color has-background" style="margin-top:0;padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:group {"style":{"spacing":{"blockGap":"0.5rem","margin":{"bottom":"var:preset|spacing|50"}}},"layout":{"type":"constrained","contentSize":"640px"}} -->
<div class="wp-block-group" style="margin-bottom:var(--wp--preset--spacing--50)">
<!-- wp:paragraph {"align":"center","className":"is-style-tw-eyebrow"} -->
<p class="has-text-align-center is-style-tw-eyebrow"><?php esc_html_e( 'Maintenance plans', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center"><?php esc_html_e( 'Stop paying for surprises', 'tradewell' ); ?></h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"align":"center","textColor":"muted"} -->
<p class="has-text-align-center has-muted-color has-text-color"><?php esc_html_e( 'Regular check-ups catch small problems before they become expensive ones. Cancel any time.', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:columns {"verticalAlignment":"stretch","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|40"}}}} -->
<div class="wp-block-columns are-vertically-aligned-stretch">
<?php
foreach ( $tradewell_plans as $tradewell_p ) :
	$tradewell_col_class = $tradewell_p['featured'] ? 'tw-plan is-featured' : 'tw-plan';
	$tradewell_btn_class = $tradewell_p['featured'] ? '' : 'is-style-outline';
	?>
<!-- wp:column {"verticalAlignment":"stretch","className":"<?php echo esc_attr( $tradewell_col_class ); ?>"} -->
<div class="wp-block-column is-vertically-aligned-stretch <?php echo esc_attr( $tradewell_col_class ); ?>">
	<?php if ( $tradewell_p['featured'] ) : ?>
<!-- wp:paragraph {"className":"tw-plan-badge"} -->
<p class="tw-plan-badge"><?php esc_html_e( 'Best value', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
<?php endif; ?>
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading"><?php echo esc_html( $tradewell_p['name'] ); ?></h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"muted","fontSize":"small"} -->
<p class="has-muted-color has-text-color has-small-font-size"><?php echo esc_html( $tradewell_p['note'] ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"tw-plan-price"} -->
<p class="tw-plan-price"><strong><?php echo esc_html( $tradewell_p['price'] ); ?></strong> <span><?php esc_html_e( '/ month', 'tradewell' ); ?></span></p>
<!-- /wp:paragraph -->
<!-- wp:list {"className":"is-style-tw-checklist","fontSize":"small"} -->
<ul class="wp-block-list is-style-tw-checklist has-small-font-size">
	<?php foreach ( $tradewell_p['features'] as $tradewell_f ) : ?>
<!-- wp:list-item --><li><?php echo esc_html( $tradewell_f ); ?></li><!-- /wp:list-item -->
<?php endforeach; ?>
</ul>
<!-- /wp:list -->
<!-- wp:buttons {"className":"tw-plan-cta"} -->
<div class="wp-block-buttons tw-plan-cta">
<!-- wp:button {"width":100,"className":"<?php echo esc_attr( $tradewell_btn_class ); ?>"} -->
<div class="wp-block-button has-custom-width wp-block-button__width-100 <?php echo esc_attr( $tradewell_btn_class ); ?>"><a class="wp-block-button__link wp-element-button" href="#quote"><?php esc_html_e( 'Join this plan', 'tradewell' ); ?></a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:column -->
<?php endforeach; ?>
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->
