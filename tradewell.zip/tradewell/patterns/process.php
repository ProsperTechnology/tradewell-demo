<?php
/**
 * Title: How it works
 * Slug: tradewell/process
 * Categories: tradewell
 * Keywords: process, steps, how it works
 *
 * @package Tradewell
 */

$tradewell_steps = array(
	array( __( 'Tell us what is wrong', 'tradewell' ), __( 'Use the estimator or call. Most requests get a reply within 15 minutes during business hours.', 'tradewell' ) ),
	array( __( 'Approve a firm price', 'tradewell' ), __( 'Your technician diagnoses the problem and gives you a written, flat-rate price before any work begins.', 'tradewell' ) ),
	array( __( 'Fixed, cleaned up, guaranteed', 'tradewell' ), __( 'We finish the job, leave the space cleaner than we found it and back the work for a full year.', 'tradewell' ) ),
);
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"margin":{"top":"0"}}},"backgroundColor":"surface","layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull has-surface-background-color has-background" style="margin-top:0;padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:paragraph {"className":"is-style-tw-eyebrow"} -->
<p class="is-style-tw-eyebrow"><?php esc_html_e( 'How it works', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:heading {"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|50"}}}} -->
<h2 class="wp-block-heading" style="margin-bottom:var(--wp--preset--spacing--50)"><?php esc_html_e( 'Three steps. No surprises.', 'tradewell' ); ?></h2>
<!-- /wp:heading -->
<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|50"}}}} -->
<div class="wp-block-columns">
<?php foreach ( $tradewell_steps as $tradewell_i => $tradewell_step ) : ?>
<!-- wp:column -->
<div class="wp-block-column">
<!-- wp:html -->
<span class="tw-step-num"><?php echo esc_html( $tradewell_i + 1 ); ?></span>
<!-- /wp:html -->
<!-- wp:heading {"level":3,"style":{"spacing":{"margin":{"top":"var:preset|spacing|30"}}}} -->
<h3 class="wp-block-heading" style="margin-top:var(--wp--preset--spacing--30)"><?php echo esc_html( $tradewell_step[0] ); ?></h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color"><?php echo esc_html( $tradewell_step[1] ); ?></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
<?php endforeach; ?>
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->
