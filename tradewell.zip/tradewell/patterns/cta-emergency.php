<?php
/**
 * Title: Emergency call to action
 * Slug: tradewell/cta-emergency
 * Categories: tradewell, call-to-action
 * Keywords: cta, emergency, call
 *
 * @package Tradewell
 */

?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60"},"margin":{"top":"0"}}},"backgroundColor":"accent","textColor":"on-accent","layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull has-on-accent-color has-accent-background-color has-text-color has-background" style="margin-top:0;padding-top:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60)">
<!-- wp:group {"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
<div class="wp-block-group">
<!-- wp:group {"style":{"spacing":{"blockGap":"0.25rem"}},"layout":{"type":"default"}} -->
<div class="wp-block-group">
<!-- wp:heading {"style":{"color":{"text":"var:preset|color|on-accent"}}} -->
<h2 class="wp-block-heading has-text-color" style="color:var(--wp--preset--color--on-accent)"><?php esc_html_e( 'Water on the floor? No heat? Sparks?', 'tradewell' ); ?></h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"fontSize":"large"} -->
<p class="has-large-font-size"><?php esc_html_e( 'A real person answers 24/7. Most emergencies get a technician within the hour.', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:twl/phone {"variant":"dark","label":"Call now"} /-->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
