<?php
/**
 * Title: Financing
 * Slug: tradewell/financing
 * Categories: tradewell, call-to-action
 * Keywords: financing, payments, monthly, loan
 *
 * @package Tradewell
 */

?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"margin":{"top":"0"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull" style="margin-top:0;padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center">
<!-- wp:paragraph {"className":"is-style-tw-eyebrow"} -->
<p class="is-style-tw-eyebrow"><?php esc_html_e( 'Financing', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:heading -->
<h2 class="wp-block-heading"><?php esc_html_e( 'A new system now. Small payments later.', 'tradewell' ); ?></h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color"><?php esc_html_e( 'Replace a failing AC, roof or water heater today and spread the cost over affordable monthly payments. Checking your options does not affect your credit score.', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:list {"className":"is-style-tw-checklist"} -->
<ul class="wp-block-list is-style-tw-checklist">
<!-- wp:list-item --><li><?php esc_html_e( 'Decisions in minutes', 'tradewell' ); ?></li><!-- /wp:list-item -->
<!-- wp:list-item --><li><?php esc_html_e( 'Terms from 12 to 120 months', 'tradewell' ); ?></li><!-- /wp:list-item -->
<!-- wp:list-item --><li><?php esc_html_e( 'No prepayment penalty', 'tradewell' ); ?></li><!-- /wp:list-item -->
</ul>
<!-- /wp:list -->
<!-- wp:paragraph {"textColor":"muted","fontSize":"x-small"} -->
<p class="has-muted-color has-text-color has-x-small-font-size"><?php esc_html_e( 'Subject to credit approval. Ask us for current rates and terms.', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center">
<!-- wp:group {"className":"tw-finance-card","style":{"border":{"radius":"20px"},"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"backgroundColor":"primary","textColor":"on-primary","layout":{"type":"default"}} -->
<div class="wp-block-group tw-finance-card has-on-primary-color has-primary-background-color has-text-color has-background" style="border-radius:20px;padding:var(--wp--preset--spacing--50)">
<!-- wp:paragraph {"style":{"color":{"text":"#ffffffcc"}},"fontSize":"small"} -->
<p class="has-text-color has-small-font-size" style="color:#ffffffcc"><?php esc_html_e( 'New high-efficiency AC system', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"tw-finance-amount"} -->
<p class="tw-finance-amount"><?php esc_html_e( 'from $89/mo', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:separator {"style":{"color":{"background":"#ffffff33"}},"className":"is-style-wide"} -->
<hr class="wp-block-separator has-text-color has-alpha-channel-opacity has-background is-style-wide" style="background-color:#ffffff33;color:#ffffff33"/>
<!-- /wp:separator -->
<!-- wp:paragraph {"style":{"color":{"text":"#ffffffcc"}},"fontSize":"small"} -->
<p class="has-text-color has-small-font-size" style="color:#ffffffcc"><?php esc_html_e( 'Example only. Your payment depends on the project, term and credit approval.', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="#quote"><?php esc_html_e( 'Check my options', 'tradewell' ); ?></a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->
