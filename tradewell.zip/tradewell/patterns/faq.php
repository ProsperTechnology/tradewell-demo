<?php
/**
 * Title: FAQ
 * Slug: tradewell/faq
 * Categories: tradewell, text
 * Keywords: faq, questions, accordion
 *
 * @package Tradewell
 */

$tradewell_faq = array(
	array( __( 'Do you charge extra for nights, weekends or holidays?', 'tradewell' ), __( 'No. Our flat-rate prices are the same at 2pm on a Tuesday and 2am on a Sunday.', 'tradewell' ) ),
	array( __( 'How accurate is the online estimate?', 'tradewell' ), __( 'It is based on typical jobs in our area. Your technician confirms a firm, written price on site before any work starts, and you are never charged for work you did not approve.', 'tradewell' ) ),
	array( __( 'Are your technicians licensed and insured?', 'tradewell' ), __( 'Yes. Every technician is licensed for their trade, background-checked, drug-tested and covered by our liability and workers compensation insurance.', 'tradewell' ) ),
	array( __( 'Do you offer financing?', 'tradewell' ), __( 'Yes. Larger projects such as system replacements, roofs and solar can be financed with approved credit. Ask about current offers when you book.', 'tradewell' ) ),
	array( __( 'What areas do you serve?', 'tradewell' ), __( 'Enter your ZIP code in the service-area checker to see instantly whether we cover your address.', 'tradewell' ) ),
);
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"margin":{"top":"0"}}},"layout":{"type":"constrained","contentSize":"820px"}} -->
<div class="wp-block-group alignfull" style="margin-top:0;padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:paragraph {"align":"center","className":"is-style-tw-eyebrow"} -->
<p class="has-text-align-center is-style-tw-eyebrow"><?php esc_html_e( 'FAQ', 'tradewell' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:heading {"textAlign":"center","style":{"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}}} -->
<h2 class="wp-block-heading has-text-align-center" style="margin-bottom:var(--wp--preset--spacing--40)"><?php esc_html_e( 'Questions we hear every day', 'tradewell' ); ?></h2>
<!-- /wp:heading -->
<?php foreach ( $tradewell_faq as $tradewell_q ) : ?>
<!-- wp:details -->
<details class="wp-block-details"><summary><?php echo esc_html( $tradewell_q[0] ); ?></summary>
<!-- wp:paragraph {"textColor":"muted"} -->
<p class="has-muted-color has-text-color"><?php echo esc_html( $tradewell_q[1] ); ?></p>
<!-- /wp:paragraph -->
</details>
<!-- /wp:details -->
<?php endforeach; ?>
</div>
<!-- /wp:group -->
