<?php
/**
 * Tradewell functions and definitions.
 *
 * The theme is intentionally light: presentation only. All lead-capture
 * functionality (quotes, bookings, service areas, leads inbox) lives in the
 * companion "Tradewell Leads" plugin so content survives a theme switch.
 *
 * @package Tradewell
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TRADEWELL_VERSION', '2.0.0' );

require_once get_template_directory() . '/inc/icons.php';
require_once get_template_directory() . '/inc/illustrations.php';
require_once get_template_directory() . '/inc/plugins.php';

/**
 * Theme setup.
 */
function tradewell_setup() {
	load_theme_textdomain( 'tradewell', get_template_directory() . '/languages' );
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'style.css' );
	add_theme_support( 'responsive-embeds' );
	add_post_type_support( 'page', 'excerpt' );
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 80,
			'width'       => 240,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);
}
add_action( 'after_setup_theme', 'tradewell_setup' );

/**
 * Front-end stylesheet. One small file, no JavaScript.
 */
function tradewell_enqueue() {
	wp_enqueue_style( 'tradewell-style', get_stylesheet_uri(), array(), TRADEWELL_VERSION );
}
add_action( 'wp_enqueue_scripts', 'tradewell_enqueue' );

/**
 * Preload the single variable font file used for all text.
 */
function tradewell_preload_font() {
	printf(
		'<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n",
		esc_url( get_template_directory_uri() . '/assets/fonts/archivo-wght.woff2' )
	);
}
add_action( 'wp_head', 'tradewell_preload_font', 1 );

/**
 * Block style variations.
 */
function tradewell_block_styles() {
	register_block_style(
		'core/group',
		array(
			'name'  => 'tw-card',
			'label' => __( 'Card', 'tradewell' ),
		)
	);
	register_block_style(
		'core/column',
		array(
			'name'  => 'tw-card',
			'label' => __( 'Card', 'tradewell' ),
		)
	);
	register_block_style(
		'core/list',
		array(
			'name'  => 'tw-checklist',
			'label' => __( 'Checklist', 'tradewell' ),
		)
	);
	register_block_style(
		'core/paragraph',
		array(
			'name'  => 'tw-eyebrow',
			'label' => __( 'Eyebrow', 'tradewell' ),
		)
	);
}
add_action( 'init', 'tradewell_block_styles' );

/**
 * Pattern categories.
 */
function tradewell_pattern_categories() {
	register_block_pattern_category(
		'tradewell',
		array(
			'label'       => __( 'Tradewell', 'tradewell' ),
			'description' => __( 'Sections for home-service websites.', 'tradewell' ),
		)
	);
	register_block_pattern_category(
		'tradewell-pages',
		array(
			'label'       => __( 'Tradewell pages', 'tradewell' ),
			'description' => __( 'Full page layouts.', 'tradewell' ),
		)
	);
}
add_action( 'init', 'tradewell_pattern_categories' );


/**
 * Skip the emoji detection script and styles (modern browsers render emoji natively).
 * Disable with: add_filter( 'tradewell_disable_emoji', '__return_false' );
 */
function tradewell_disable_emoji() {
	if ( ! apply_filters( 'tradewell_disable_emoji', true ) ) {
		return;
	}
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_enqueue_scripts', 'wp_enqueue_emoji_styles' );
}
add_action( 'init', 'tradewell_disable_emoji' );
