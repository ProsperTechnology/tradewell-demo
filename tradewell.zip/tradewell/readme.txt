=== Tradewell ===
Requires at least: 6.6
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 2.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A fast, lead-focused block theme for HVAC, plumbing, roofing, electrical and solar contractors.

== Description ==

Tradewell is a full site editing theme built to turn visitors into phone calls and booked jobs for HVAC, plumbing, roofing, electrical and solar contractors.

* Six one-click starter sites (Multi-trade, Plumbing, HVAC, Roofing, Electrical, Solar) with trade-specific copy, prices, menus and colors.
* Six style variations that also recolor the original illustrations.
* 18 conversion-focused patterns: hero with illustration, trade bar, trust bar, services, coupons, how-it-works, stats, maintenance plan pricing, financing, reviews, team, about, service detail, contact details, FAQ, emergency call to action, and more.
* Templates for pages, full-width pages, landing pages (no navigation), posts, archives, search, 404 and service-area pages.
* No theme JavaScript and one small stylesheet. A single self-hosted variable font.
* Accessible color palettes, keyboard focus styles and reduced-motion support.

The included Tradewell Leads plugin adds the instant quote calculator, booking form, service-area pages with ZIP checker, mobile click-to-call bar, leads inbox and the setup wizard. The theme works without it; plugin sections simply do not appear.

== Installation ==

1. Appearance > Themes > Add New > Upload Theme, choose tradewell.zip, then Activate.
2. Click "Begin installing plugin" in the notice that appears (or Appearance > Install Plugins) and activate Tradewell Leads.
3. The setup wizard opens. Pick your trade, enter your business name, phone and email, and click Build my site.
4. Replace the sample reviews, team and service areas with your own.

Full documentation is in the documentation folder of your download and publicly available at:
https://github.com/ProsperTechnology/tradewell-demo/blob/main/documentation/README.md

== Frequently Asked Questions ==

= The reviews look real. Are they? =
No. They are placeholder text. Replace them with genuine reviews from your customers before launch.

= How do I change the homepage? =
Appearance > Editor > Templates > Front Page. Each section is a pattern you can edit, reorder or remove.

== Changelog ==

= 2.0.1 =
* Prosper Technologies branding and consistent licensing.
* Refined responsive layouts and service navigation.
* Improved child-theme support, form validation and privacy handling.

= 2.0.0 =
* New: one-click starter sites for six trades.
* New: original illustrations that recolor with each style variation.
* New patterns: offers, maintenance plans, stats, financing, team, about, service detail, contact details, page header.
* New: bundled plugin installer (TGM Plugin Activation).
* Improved: accessibility, HTML validity and core block styling.

= 1.0.0 =
* Initial release.

== Copyright ==

Tradewell WordPress Theme, (C) 2026 Prosper Technologies.
Tradewell is distributed under the terms of the GNU GPL v2 or later.

This theme bundles the following third-party resources:

Archivo font, Copyright 2020 The Archivo Project Authors (https://github.com/Omnibus-Type/Archivo)
License: SIL Open Font License, Version 1.1 (see assets/fonts/OFL.txt)

TGM Plugin Activation, Copyright (c) 2011 Thomas Griffin, Gary Jones, Juliette Reinders Folmer
License: GPLv2 or later (http://tgmpluginactivation.com/)

Icons and illustrations are original artwork created for Tradewell and released under GPLv2 or later.
Screenshot contains no third-party images.
