<?php
/**
 * Recommend and install the included Tradewell Leads plugin (TGM Plugin Activation).
 *
 * @package Tradewell
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once get_template_directory() . '/inc/tgmpa/class-tgm-plugin-activation.php';

/**
 * Register the included plugin, hosted separately from the theme ZIP.
 */
function tradewell_register_plugins() {
	$plugins = array(
		array(
			'name'     => 'Tradewell Leads',
			'slug'     => 'tradewell-leads',
			'source'   => 'https://raw.githubusercontent.com/ProsperTechnology/tradewell-demo/main/tradewell-leads.zip',
			'required' => false,
			'version'  => '2.0.1',
		),
	);
	$config  = array(
		'id'           => 'tradewell',
		'menu'         => 'tradewell-install-plugins',
		'parent_slug'  => 'themes.php',
		'capability'   => 'install_plugins',
		'has_notices'  => true,
		'dismissable'  => true,
		'is_automatic' => true,
		'strings'      => array(
			/* translators: 1: plugin name(s). */
			'notice_can_install_recommended' => _n_noop(
				'Tradewell recommends the %1$s plugin. It adds the quote calculator, booking form, service areas, click-to-call bar and one-click starter sites.',
				'Tradewell recommends the following plugins: %1$s.',
				'tradewell'
			),
		),
	);
	tgmpa( $plugins, $config );
}
add_action( 'tgmpa_register', 'tradewell_register_plugins' );
