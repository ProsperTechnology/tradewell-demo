<?php
/**
 * Original SVG illustrations. Colors come from theme.json presets through CSS
 * classes, so every illustration recolors with the active style variation.
 *
 * @package Tradewell
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * House scene for the hero.
 *
 * @return string
 */
function tradewell_illustration_house() {
	$rating = esc_html__( '4.9 rating', 'tradewell' );
	$eta    = esc_html__( 'Tech arriving', 'tradewell' );
	$eta2   = esc_html__( '45 min', 'tradewell' );
	$title  = esc_html__( 'Illustration of a home with solar panels, an air conditioner and a service van', 'tradewell' );

	return <<<SVG
<svg class="tw-ill" viewBox="0 0 600 470" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="{$title}">
<defs>
<filter id="tw-shadow" x="-20%" y="-20%" width="140%" height="160%"><feDropShadow dx="0" dy="6" stdDeviation="8" flood-color="#0f1b2a" flood-opacity=".18"/></filter>
<clipPath id="tw-roof-clip"><path d="M150 232 208 138h184l58 94z"/></clipPath>
</defs>
<circle class="ill-soft" cx="318" cy="236" r="214"/>
<g class="ill-h"><circle cx="506" cy="92" r="30"/></g>
<g class="ill-h-stroke" stroke-width="5" stroke-linecap="round"><path d="M506 44v-14M506 154v-14M458 92h-14M568 92h-14M472 58l-10-10M550 136l-10-10M472 126l-10 10M550 48l-10 10"/></g>
<ellipse class="ill-ground" cx="300" cy="404" rx="282" ry="10"/>
<rect class="ill-pd" x="398" y="148" width="24" height="56" rx="2"/>
<rect class="ill-b ill-line" x="172" y="226" width="256" height="176" rx="4"/>
<path class="ill-pd" d="M150 232 208 138h184l58 94z"/>
<g clip-path="url(#tw-roof-clip)">
<g class="ill-panel">
<rect x="226" y="154" width="34" height="26" rx="2"/><rect x="264" y="154" width="34" height="26" rx="2"/><rect x="302" y="154" width="34" height="26" rx="2"/><rect x="340" y="154" width="34" height="26" rx="2"/>
<rect x="218" y="186" width="36" height="28" rx="2"/><rect x="258" y="186" width="36" height="28" rx="2"/><rect x="298" y="186" width="36" height="28" rx="2"/><rect x="338" y="186" width="36" height="28" rx="2"/>
</g>
<path class="ill-shine" d="M232 158l10 18M270 158l10 18M308 158l10 18M346 158l10 18M224 190l10 20M264 190l10 20M304 190l10 20M344 190l10 20" stroke-width="3" stroke-linecap="round"/>
</g>
<rect class="ill-pd" x="144" y="228" width="312" height="10" rx="5"/>
<rect class="ill-s ill-line" x="196" y="262" width="62" height="56" rx="4"/>
<rect class="ill-s ill-line" x="342" y="262" width="62" height="56" rx="4"/>
<rect class="ill-glow" x="200" y="266" width="54" height="48" rx="2"/>
<rect class="ill-glow" x="346" y="266" width="54" height="48" rx="2"/>
<path class="ill-line" d="M227 262v56M196 290h62M373 262v56M342 290h62" fill="none"/>
<rect class="ill-a ill-line" x="276" y="300" width="48" height="102" rx="4"/>
<circle class="ill-b" cx="314" cy="352" r="4"/>
<rect class="ill-s ill-line" x="396" y="334" width="24" height="32" rx="3"/>
<path class="ill-a" d="M410 338l-8 13h7l-2 11 9-14h-7z"/>
<rect class="ill-b ill-line" x="438" y="344" width="74" height="58" rx="6"/>
<circle class="ill-s ill-line" cx="475" cy="373" r="20"/>
<g class="ill-p"><ellipse cx="475" cy="362" rx="4.5" ry="10"/><ellipse cx="475" cy="362" rx="4.5" ry="10" transform="rotate(120 475 373)"/><ellipse cx="475" cy="362" rx="4.5" ry="10" transform="rotate(240 475 373)"/></g>
<circle class="ill-pd" cx="475" cy="373" r="4"/>
<path class="ill-line" d="M446 352h8M446 360h8M446 368h8M446 376h8M446 384h8M446 392h8" fill="none"/>
<circle class="ill-tree" cx="132" cy="370" r="26"/><circle class="ill-tree" cx="112" cy="384" r="18"/><rect class="ill-pd" x="129" y="384" width="6" height="20" rx="2"/>
<g transform="translate(18 0)">
<path class="ill-b ill-line" d="M30 402v-46a12 12 0 0 1 12-12h104l34 24h16a10 10 0 0 1 10 10v24z"/>
<path class="ill-s ill-line" d="M150 350l24 18h-24z"/>
<rect class="ill-a" x="31" y="378" width="174" height="9"/>
<rect class="ill-pd" x="46" y="334" width="92" height="6" rx="3"/>
<path class="ill-pd" d="M58 334v-6M74 334v-6M90 334v-6M106 334v-6M122 334v-6" stroke-width="4" stroke-linecap="round"/>
<circle class="ill-p" cx="86" cy="362" r="10"/>
<path class="ill-b" d="M82 358a4.5 4.5 0 0 0 6 6l3 3 2-2-3-3a4.5 4.5 0 0 0-6-6l2.5 2.5-1 2-2 1z"/>
<circle class="ill-c" cx="66" cy="402" r="15"/><circle class="ill-b" cx="66" cy="402" r="6"/>
<circle class="ill-c" cx="176" cy="402" r="15"/><circle class="ill-b" cx="176" cy="402" r="6"/>
</g>
<g filter="url(#tw-shadow)">
<rect class="ill-b" x="372" y="22" width="148" height="50" rx="14"/>
<rect class="ill-b" x="18" y="178" width="166" height="56" rx="14"/>
<circle class="ill-b" cx="94" cy="108" r="26"/>
<circle class="ill-b" cx="548" cy="268" r="26"/>
</g>
<path d="M394 39l3.4 6.9 7.6 1.1-5.5 5.4 1.3 7.6-6.8-3.6-6.8 3.6 1.3-7.6-5.5-5.4 7.6-1.1z" fill="#F5A524"/>
<text class="ill-text" x="416" y="53">{$rating}</text>
<circle class="ill-a" cx="46" cy="206" r="14"/>
<path class="ill-on-a" d="M46 199v7l5 3" fill="none" stroke-width="2.5" stroke-linecap="round"/>
<text class="ill-text-sm" x="68" y="200">{$eta}</text>
<text class="ill-text" x="68" y="221">{$eta2}</text>
<path class="ill-p" d="M94 92s11 12 11 20a11 11 0 0 1-22 0c0-8 11-20 11-20z"/>
<path class="ill-a" d="M551 252l-13 18h9l-2 14 13-18h-9z"/>
</svg>
SVG;
}
