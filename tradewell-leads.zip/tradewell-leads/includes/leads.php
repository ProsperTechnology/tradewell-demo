<?php
/**
 * Lead intake: validation, spam checks, storage, notifications.
 *
 * Shared by the REST endpoint (JavaScript forms) and the admin-post
 * fallback (forms submitted with JavaScript disabled).
 *
 * @package TradewellLeads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Lead statuses.
 *
 * @return array
 */
function twleads_lead_statuses() {
	return array(
		'new'       => __( 'New', 'tradewell-leads' ),
		'contacted' => __( 'Contacted', 'tradewell-leads' ),
		'booked'    => __( 'Booked', 'tradewell-leads' ),
		'won'       => __( 'Won', 'tradewell-leads' ),
		'lost'      => __( 'Lost', 'tradewell-leads' ),
	);
}

/**
 * Lead types.
 *
 * @return array
 */
function twleads_lead_types() {
	return array(
		'quote'   => __( 'Quote', 'tradewell-leads' ),
		'booking' => __( 'Booking', 'tradewell-leads' ),
		'area'    => __( 'Outside area', 'tradewell-leads' ),
	);
}

/**
 * Hashed client IP for rate limiting (raw IP is never stored).
 *
 * @return string
 */
function twleads_client_key() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
	return substr( hash_hmac( 'sha256', $ip, wp_salt( 'auth' ) ), 0, 24 );
}

/**
 * Validate, store and dispatch a lead.
 *
 * @param array $raw Unslashed request data.
 * @return int|WP_Error Lead ID.
 */
function twleads_create_lead( array $raw ) {
	foreach ( $raw as $value ) {
		if ( ! is_scalar( $value ) && null !== $value ) {
			return new WP_Error( 'twleads_invalid', __( 'Please check the submitted fields.', 'tradewell-leads' ), array( 'status' => 422 ) );
		}
	}

	// Honeypot: real visitors never see or fill this field.
	if ( ! empty( $raw['company_website'] ) ) {
		return new WP_Error( 'twleads_spam', __( 'Submission rejected.', 'tradewell-leads' ), array( 'status' => 400 ) );
	}

	$token = twleads_check_token( isset( $raw['twleads_token'] ) ? $raw['twleads_token'] : '' );
	if ( is_wp_error( $token ) ) {
		$token->add_data( array( 'status' => 400 ) );
		return $token;
	}

	$limit_key = 'twleads_rl_' . twleads_client_key();
	$count     = (int) get_transient( $limit_key );
	/** Filter the number of submissions allowed per visitor per 10 minutes. */
	if ( $count >= (int) apply_filters( 'twleads_rate_limit', 6 ) ) {
		return new WP_Error( 'twleads_rate', __( 'Too many requests. Please call us instead.', 'tradewell-leads' ), array( 'status' => 429 ) );
	}

	$types = twleads_lead_types();
	$data  = array(
		'type'     => isset( $raw['type'], $types[ $raw['type'] ] ) ? $raw['type'] : 'quote',
		'name'     => isset( $raw['name'] ) ? sanitize_text_field( $raw['name'] ) : '',
		'phone'    => isset( $raw['phone'] ) ? sanitize_text_field( $raw['phone'] ) : '',
		'email'    => isset( $raw['email'] ) ? sanitize_email( $raw['email'] ) : '',
		'zip'      => isset( $raw['zip'] ) ? strtoupper( sanitize_text_field( $raw['zip'] ) ) : '',
		'address'  => isset( $raw['address'] ) ? sanitize_text_field( $raw['address'] ) : '',
		'service'  => isset( $raw['service'] ) ? sanitize_text_field( $raw['service'] ) : '',
		'size'     => isset( $raw['size'] ) ? sanitize_text_field( $raw['size'] ) : '',
		'urgency'  => isset( $raw['urgency'] ) ? sanitize_text_field( $raw['urgency'] ) : '',
		'est_low'  => isset( $raw['est_low'] ) ? max( 0, (float) $raw['est_low'] ) : 0,
		'est_high' => isset( $raw['est_high'] ) ? max( 0, (float) $raw['est_high'] ) : 0,
		'date'     => isset( $raw['date'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $raw['date'] ) ? $raw['date'] : '',
		'window'   => isset( $raw['window'] ) ? sanitize_text_field( $raw['window'] ) : '',
		'notes'    => isset( $raw['notes'] ) ? sanitize_textarea_field( $raw['notes'] ) : '',
		'page'     => isset( $raw['page'] ) ? esc_url_raw( $raw['page'] ) : '',
	);

	foreach ( array( 'name', 'phone', 'address', 'service', 'window' ) as $key ) {
		$data[ $key ] = twleads_trim_text( $data[ $key ], 200 );
	}
	$data['notes'] = twleads_trim_text( $data['notes'], 2000 );

	$errors = array();
	if ( '' === $data['name'] ) {
		$errors['name'] = __( 'Please enter your name.', 'tradewell-leads' );
	}
	$digits = preg_replace( '/\D/', '', $data['phone'] );
	if ( strlen( $digits ) < 7 || strlen( $digits ) > 15 ) {
		$errors['phone'] = __( 'Please enter a valid phone number.', 'tradewell-leads' );
	}
	if ( isset( $raw['email'] ) && '' !== trim( (string) $raw['email'], " \t\n\r\0\x0B" ) && ! is_email( $data['email'] ) ) {
		$errors['email'] = __( 'Please check your email address.', 'tradewell-leads' );
	}
	if ( 'booking' === $data['type'] ) {
		$day = DateTimeImmutable::createFromFormat( '!Y-m-d', $data['date'], wp_timezone() );
		if ( ! $day || $day->format( 'Y-m-d' ) !== $data['date'] || $data['date'] < wp_date( 'Y-m-d' ) ) {
			$errors['date'] = __( 'Please choose a valid day today or later.', 'tradewell-leads' );
		}
	}
	/** Filter validation errors. */
	$errors = apply_filters( 'twleads_lead_errors', $errors, $data );
	if ( $errors ) {
		return new WP_Error(
			'twleads_invalid',
			__( 'Please fix the highlighted fields.', 'tradewell-leads' ),
			array(
				'status' => 422,
				'fields' => $errors,
			)
		);
	}

	/* translators: 1: lead type, 2: name. */
	$title = sprintf( __( '%1$s from %2$s', 'tradewell-leads' ), $types[ $data['type'] ], $data['name'] );
	if ( $data['service'] ) {
		$title .= ' (' . $data['service'] . ')';
	}

	$lead_id = wp_insert_post(
		array(
			'post_type'   => 'twleads_lead',
			'post_status' => 'publish',
			'post_title'  => $title,
		),
		true
	);
	if ( is_wp_error( $lead_id ) ) {
		return $lead_id;
	}

	foreach ( $data as $key => $value ) {
		update_post_meta( $lead_id, '_twl_' . $key, $value );
	}
	update_post_meta( $lead_id, '_twl_status', 'new' );

	set_transient( $limit_key, $count + 1, 10 * MINUTE_IN_SECONDS );

	twleads_notify_lead( $lead_id, $data );
	twleads_send_webhook( $lead_id, $data );

	/** Fires after a lead is stored. */
	do_action( 'twleads_lead_created', $lead_id, $data );

	return $lead_id;
}

/**
 * Format an estimate range.
 *
 * @param array $data Lead data.
 * @return string
 */
function twleads_format_estimate( $data ) {
	if ( empty( $data['est_high'] ) ) {
		return '';
	}
	$cur = twleads_get( 'currency' );
	return $cur . number_format_i18n( $data['est_low'] ) . ' – ' . $cur . number_format_i18n( $data['est_high'] );
}

/**
 * Email the business about a new lead.
 *
 * @param int   $lead_id Lead ID.
 * @param array $data    Lead data.
 */
function twleads_notify_lead( $lead_id, $data ) {
	$to = twleads_get( 'notify_email' );
	if ( ! $to ) {
		$to = get_option( 'admin_email' );
	}
	$types = twleads_lead_types();
	$lines = array(
		__( 'Type', 'tradewell-leads' )     => $types[ $data['type'] ],
		__( 'Name', 'tradewell-leads' )     => $data['name'],
		__( 'Phone', 'tradewell-leads' )    => $data['phone'],
		__( 'Email', 'tradewell-leads' )    => $data['email'],
		__( 'ZIP', 'tradewell-leads' )      => $data['zip'],
		__( 'Address', 'tradewell-leads' )  => $data['address'],
		__( 'Service', 'tradewell-leads' )  => $data['service'],
		__( 'Size', 'tradewell-leads' )     => $data['size'],
		__( 'Urgency', 'tradewell-leads' )  => $data['urgency'],
		__( 'Estimate', 'tradewell-leads' ) => twleads_format_estimate( $data ),
		__( 'Day', 'tradewell-leads' )      => $data['date'],
		__( 'Window', 'tradewell-leads' )   => $data['window'],
		__( 'Notes', 'tradewell-leads' )    => $data['notes'],
		__( 'Page', 'tradewell-leads' )     => $data['page'],
	);
	$body  = '';
	foreach ( $lines as $label => $value ) {
		if ( '' !== (string) $value ) {
			$body .= $label . ': ' . $value . "\n";
		}
	}
	$body .= "\n" . __( 'Manage this lead:', 'tradewell-leads' ) . ' ' . admin_url( 'post.php?post=' . $lead_id . '&action=edit' ) . "\n";

	$headers = array();
	if ( $data['email'] ) {
		$headers[] = 'Reply-To: ' . $data['name'] . ' <' . $data['email'] . '>';
	}
	/* translators: 1: lead type, 2: name, 3: phone. */
	$subject = sprintf( __( 'New %1$s lead: %2$s, %3$s', 'tradewell-leads' ), strtolower( $types[ $data['type'] ] ), $data['name'], $data['phone'] );
	wp_mail( $to, $subject, $body, $headers );
}

/**
 * POST the lead to an optional webhook (non-blocking).
 *
 * @param int   $lead_id Lead ID.
 * @param array $data    Lead data.
 */
function twleads_send_webhook( $lead_id, $data ) {
	$url = twleads_get( 'webhook_url' );
	if ( ! $url ) {
		return;
	}
	$payload = array_merge(
		array(
			'id'      => $lead_id,
			'site'    => home_url( '/' ),
			'created' => gmdate( 'c' ),
		),
		$data
	);
	wp_safe_remote_post(
		$url,
		array(
			'timeout'  => 3,
			'blocking' => false,
			'headers'  => array( 'Content-Type' => 'application/json' ),
			'body'     => wp_json_encode( apply_filters( 'twleads_webhook_payload', $payload, $lead_id ) ),
		)
	);
}

/**
 * No-JavaScript fallback: forms post to admin-post.php.
 */
function twleads_handle_form_post() {
	$raw    = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- public form protected by signed token, honeypot and rate limit.
	$result = twleads_create_lead( is_array( $raw ) ? $raw : array() );
	$back   = wp_get_referer() ? wp_get_referer() : home_url( '/' );
	$back   = remove_query_arg( array( 'twl' ), $back );
	$status = is_wp_error( $result ) ? 'error' : 'sent';
	wp_safe_redirect( add_query_arg( 'twl', $status, $back ) . '#twl-msg' );
	exit;
}
add_action( 'admin_post_nopriv_twleads_lead', 'twleads_handle_form_post' );
add_action( 'admin_post_twleads_lead', 'twleads_handle_form_post' );
