<?php
/**
 * Demo data for the six trade starter sites.
 *
 * @package TradewellLeads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Shorthand for a flat-price calculator service.
 *
 * @param string $label Label.
 * @param float  $base  Price.
 * @return array
 */
function twleads_svc( $label, $base ) {
	return array(
		'label'     => $label,
		'base'      => $base,
		'unit'      => '',
		'unitPrice' => 0,
		'min'       => 0,
		'max'       => 0,
		'step'      => 1,
		'def'       => 0,
	);
}

/**
 * Shorthand for a sized calculator service.
 *
 * @param string $label Label.
 * @param float  $base  Fixed part.
 * @param string $unit  Unit label.
 * @param float  $per   Price per unit.
 * @param float  $min   Minimum.
 * @param float  $max   Maximum.
 * @param float  $step  Step.
 * @param float  $def   Default.
 * @return array
 */
function twleads_svc_sized( $label, $base, $unit, $per, $min, $max, $step, $def ) {
	return array(
		'label'     => $label,
		'base'      => $base,
		'unit'      => $unit,
		'unitPrice' => $per,
		'min'       => $min,
		'max'       => $max,
		'step'      => $step,
		'def'       => $def,
	);
}

/**
 * All starter sites.
 *
 * @return array
 */
function twleads_demo_trades() {
	return array(
		'multi'      => array(
			'label'    => __( 'Multi-trade', 'tradewell-leads' ),
			'desc'     => __( 'Heating, cooling, plumbing, roofing, electrical and solar under one roof.', 'tradewell-leads' ),
			'style'    => '',
			'eyebrow'  => __( 'Same-day service across the metro', 'tradewell-leads' ),
			'headline' => __( 'Fixed right the first time. Priced before we start.', 'tradewell-leads' ),
			'lead'     => __( 'Licensed technicians for heating, cooling, plumbing, roofing, electrical and solar. Get an instant estimate in under a minute.', 'tradewell-leads' ),
			'calc'     => array(
				twleads_svc( __( 'AC repair', 'tradewell-leads' ), 189 ),
				twleads_svc_sized( __( 'New AC / heat pump', 'tradewell-leads' ), 2400, __( 'tons', 'tradewell-leads' ), 1350, 1.5, 5, 0.5, 3 ),
				twleads_svc( __( 'Water heater replacement', 'tradewell-leads' ), 1650 ),
				twleads_svc( __( 'Drain cleaning', 'tradewell-leads' ), 179 ),
				twleads_svc_sized( __( 'Roof repair', 'tradewell-leads' ), 350, __( 'sq ft damaged', 'tradewell-leads' ), 9, 10, 400, 10, 100 ),
				twleads_svc_sized( __( 'Roof replacement', 'tradewell-leads' ), 2500, __( 'sq ft of roof', 'tradewell-leads' ), 4.75, 800, 5000, 100, 2000 ),
				twleads_svc( __( 'Panel upgrade', 'tradewell-leads' ), 2400 ),
				twleads_svc( __( 'EV charger install', 'tradewell-leads' ), 950 ),
				twleads_svc_sized( __( 'Solar system', 'tradewell-leads' ), 2500, __( 'kW', 'tradewell-leads' ), 2650, 3, 15, 0.5, 7 ),
			),
			'booking'  => array( __( 'Heating & cooling', 'tradewell-leads' ), __( 'Plumbing', 'tradewell-leads' ), __( 'Roofing', 'tradewell-leads' ), __( 'Electrical', 'tradewell-leads' ), __( 'Solar', 'tradewell-leads' ), __( 'Something else', 'tradewell-leads' ) ),
			'services' => array(
				array( __( 'Heating & Cooling', 'tradewell-leads' ), __( 'AC and furnace repair, tune-ups and high-efficiency replacements.', 'tradewell-leads' ), array( __( 'Warm air or weak airflow', 'tradewell-leads' ), __( 'Strange noises or smells', 'tradewell-leads' ), __( 'Rising energy bills', 'tradewell-leads' ), __( 'System older than 12 years', 'tradewell-leads' ) ), '$89', __( 'diagnostic', 'tradewell-leads' ) ),
				array( __( 'Plumbing', 'tradewell-leads' ), __( 'Leaks, drains, water heaters and repiping by licensed plumbers.', 'tradewell-leads' ), array( __( 'Slow or gurgling drains', 'tradewell-leads' ), __( 'Low water pressure', 'tradewell-leads' ), __( 'No hot water', 'tradewell-leads' ), __( 'Water stains on ceilings or walls', 'tradewell-leads' ) ), '$179', __( 'drain cleaning', 'tradewell-leads' ) ),
				array( __( 'Roofing', 'tradewell-leads' ), __( 'Leak repair, storm damage and full roof replacement.', 'tradewell-leads' ), array( __( 'Missing or curling shingles', 'tradewell-leads' ), __( 'Leaks after heavy rain', 'tradewell-leads' ), __( 'Granules in the gutters', 'tradewell-leads' ), __( 'Sagging roof deck', 'tradewell-leads' ) ), __( 'Free', 'tradewell-leads' ), __( 'inspection', 'tradewell-leads' ) ),
			),
		),
		'plumbing'   => array(
			'label'    => __( 'Plumbing', 'tradewell-leads' ),
			'desc'     => __( 'Drains, leaks, water heaters, sewer and repiping.', 'tradewell-leads' ),
			'style'    => 'plumbing',
			'eyebrow'  => __( 'Licensed plumbers, 24/7', 'tradewell-leads' ),
			'headline' => __( 'Leaks fixed fast. Prices set before we start.', 'tradewell-leads' ),
			'lead'     => __( 'Drains, water heaters, repiping and emergency repairs from licensed plumbers who show up on time and clean up after.', 'tradewell-leads' ),
			'calc'     => array(
				twleads_svc( __( 'Drain cleaning', 'tradewell-leads' ), 179 ),
				twleads_svc( __( 'Leak repair', 'tradewell-leads' ), 225 ),
				twleads_svc( __( 'Toilet repair or replace', 'tradewell-leads' ), 295 ),
				twleads_svc( __( 'Water heater replacement', 'tradewell-leads' ), 1650 ),
				twleads_svc( __( 'Tankless water heater', 'tradewell-leads' ), 3200 ),
				twleads_svc_sized( __( 'Sewer line repair', 'tradewell-leads' ), 1200, __( 'feet of pipe', 'tradewell-leads' ), 95, 10, 150, 5, 40 ),
				twleads_svc_sized( __( 'Whole-home repipe', 'tradewell-leads' ), 2500, __( 'bathrooms', 'tradewell-leads' ), 1800, 1, 5, 1, 2 ),
			),
			'booking'  => array( __( 'Clogged drain', 'tradewell-leads' ), __( 'Leak', 'tradewell-leads' ), __( 'Water heater', 'tradewell-leads' ), __( 'Toilet or fixture', 'tradewell-leads' ), __( 'Sewer line', 'tradewell-leads' ), __( 'Something else', 'tradewell-leads' ) ),
			'services' => array(
				array( __( 'Drain Cleaning', 'tradewell-leads' ), __( 'Clogs cleared for good with camera inspection and hydro-jetting.', 'tradewell-leads' ), array( __( 'Slow or gurgling drains', 'tradewell-leads' ), __( 'Recurring clogs', 'tradewell-leads' ), __( 'Sewer smell inside', 'tradewell-leads' ), __( 'Water backing up in tubs', 'tradewell-leads' ) ), '$179', __( 'per drain', 'tradewell-leads' ) ),
				array( __( 'Water Heaters', 'tradewell-leads' ), __( 'Same-day repair and replacement for tank and tankless heaters.', 'tradewell-leads' ), array( __( 'No hot water', 'tradewell-leads' ), __( 'Rusty or cloudy water', 'tradewell-leads' ), __( 'Popping or rumbling noises', 'tradewell-leads' ), __( 'Water around the tank', 'tradewell-leads' ) ), '$1,650', __( 'installed', 'tradewell-leads' ) ),
				array( __( 'Leak Repair', 'tradewell-leads' ), __( 'Fast leak detection without tearing up your home.', 'tradewell-leads' ), array( __( 'Unexplained high water bill', 'tradewell-leads' ), __( 'Damp walls or ceilings', 'tradewell-leads' ), __( 'Sound of running water', 'tradewell-leads' ), __( 'Mold or musty smell', 'tradewell-leads' ) ), '$225', __( 'typical repair', 'tradewell-leads' ) ),
			),
		),
		'hvac'       => array(
			'label'    => __( 'HVAC', 'tradewell-leads' ),
			'desc'     => __( 'Air conditioning, furnaces, heat pumps and ductwork.', 'tradewell-leads' ),
			'style'    => 'hvac',
			'eyebrow'  => __( 'Heating & cooling experts', 'tradewell-leads' ),
			'headline' => __( 'Cool in summer. Warm in winter. No surprise bills.', 'tradewell-leads' ),
			'lead'     => __( 'AC repair, furnace service, heat pumps and new systems with upfront pricing and easy financing.', 'tradewell-leads' ),
			'calc'     => array(
				twleads_svc( __( 'AC repair', 'tradewell-leads' ), 189 ),
				twleads_svc( __( 'Furnace repair', 'tradewell-leads' ), 179 ),
				twleads_svc( __( 'Seasonal tune-up', 'tradewell-leads' ), 89 ),
				twleads_svc_sized( __( 'New AC system', 'tradewell-leads' ), 2400, __( 'tons', 'tradewell-leads' ), 1350, 1.5, 5, 0.5, 3 ),
				twleads_svc_sized( __( 'Heat pump', 'tradewell-leads' ), 3200, __( 'tons', 'tradewell-leads' ), 1500, 1.5, 5, 0.5, 3 ),
				twleads_svc_sized( __( 'Duct cleaning', 'tradewell-leads' ), 299, __( 'vents', 'tradewell-leads' ), 35, 5, 40, 1, 12 ),
				twleads_svc( __( 'Smart thermostat install', 'tradewell-leads' ), 249 ),
			),
			'booking'  => array( __( 'AC not cooling', 'tradewell-leads' ), __( 'No heat', 'tradewell-leads' ), __( 'Tune-up', 'tradewell-leads' ), __( 'New system quote', 'tradewell-leads' ), __( 'Indoor air quality', 'tradewell-leads' ), __( 'Something else', 'tradewell-leads' ) ),
			'services' => array(
				array( __( 'AC Repair', 'tradewell-leads' ), __( 'Fast air-conditioning repair for every make and model.', 'tradewell-leads' ), array( __( 'Warm air from vents', 'tradewell-leads' ), __( 'Short cycling', 'tradewell-leads' ), __( 'Ice on the lines', 'tradewell-leads' ), __( 'Water pooling indoors', 'tradewell-leads' ) ), '$89', __( 'diagnostic', 'tradewell-leads' ) ),
				array( __( 'Furnace Service', 'tradewell-leads' ), __( 'Furnace repair, safety checks and replacement.', 'tradewell-leads' ), array( __( 'No heat or uneven heat', 'tradewell-leads' ), __( 'Yellow pilot flame', 'tradewell-leads' ), __( 'Banging or squealing', 'tradewell-leads' ), __( 'Frequent resets', 'tradewell-leads' ) ), '$89', __( 'diagnostic', 'tradewell-leads' ) ),
				array( __( 'Heat Pumps', 'tradewell-leads' ), __( 'Efficient year-round comfort with available rebates.', 'tradewell-leads' ), array( __( 'High energy bills', 'tradewell-leads' ), __( 'System over 12 years old', 'tradewell-leads' ), __( 'Rooms too hot or cold', 'tradewell-leads' ), __( 'Replacing gas heat', 'tradewell-leads' ) ), '$6,500', __( 'installed', 'tradewell-leads' ) ),
			),
		),
		'roofing'    => array(
			'label'    => __( 'Roofing', 'tradewell-leads' ),
			'desc'     => __( 'Repairs, replacements, storm damage and gutters.', 'tradewell-leads' ),
			'style'    => 'roofing',
			'eyebrow'  => __( 'Roof repair & replacement', 'tradewell-leads' ),
			'headline' => __( 'A roof you never have to think about again.', 'tradewell-leads' ),
			'lead'     => __( 'Leak repair, storm damage, full replacements and gutters, with free inspections and insurance claim help.', 'tradewell-leads' ),
			'calc'     => array(
				twleads_svc( __( 'Roof inspection', 'tradewell-leads' ), 149 ),
				twleads_svc_sized( __( 'Leak repair', 'tradewell-leads' ), 350, __( 'sq ft damaged', 'tradewell-leads' ), 9, 10, 400, 10, 100 ),
				twleads_svc_sized( __( 'Shingle roof replacement', 'tradewell-leads' ), 2500, __( 'sq ft of roof', 'tradewell-leads' ), 4.75, 800, 5000, 100, 2000 ),
				twleads_svc_sized( __( 'Metal roof', 'tradewell-leads' ), 5000, __( 'sq ft of roof', 'tradewell-leads' ), 9.5, 800, 5000, 100, 2000 ),
				twleads_svc_sized( __( 'New gutters', 'tradewell-leads' ), 300, __( 'linear feet', 'tradewell-leads' ), 12, 40, 400, 10, 150 ),
			),
			'booking'  => array( __( 'Free inspection', 'tradewell-leads' ), __( 'Active leak', 'tradewell-leads' ), __( 'Storm damage', 'tradewell-leads' ), __( 'Replacement quote', 'tradewell-leads' ), __( 'Gutters', 'tradewell-leads' ) ),
			'services' => array(
				array( __( 'Roof Repair', 'tradewell-leads' ), __( 'Leaks stopped and damage repaired, often the same week.', 'tradewell-leads' ), array( __( 'Drips or ceiling stains', 'tradewell-leads' ), __( 'Missing shingles', 'tradewell-leads' ), __( 'Damaged flashing', 'tradewell-leads' ), __( 'Daylight in the attic', 'tradewell-leads' ) ), '$350', __( 'typical repair', 'tradewell-leads' ) ),
				array( __( 'Roof Replacement', 'tradewell-leads' ), __( 'Asphalt, metal and tile roofs with a 25-year workmanship warranty.', 'tradewell-leads' ), array( __( 'Roof older than 20 years', 'tradewell-leads' ), __( 'Curling or cracked shingles', 'tradewell-leads' ), __( 'Repeated leaks', 'tradewell-leads' ), __( 'Sagging sections', 'tradewell-leads' ) ), '$9,500', __( 'average roof', 'tradewell-leads' ) ),
				array( __( 'Storm Damage', 'tradewell-leads' ), __( 'Emergency tarping and help with your insurance claim.', 'tradewell-leads' ), array( __( 'Hail dents or bruising', 'tradewell-leads' ), __( 'Wind-lifted shingles', 'tradewell-leads' ), __( 'Fallen branches', 'tradewell-leads' ), __( 'Dented gutters', 'tradewell-leads' ) ), __( 'Free', 'tradewell-leads' ), __( 'inspection', 'tradewell-leads' ) ),
			),
		),
		'electrical' => array(
			'label'    => __( 'Electrical', 'tradewell-leads' ),
			'desc'     => __( 'Panels, EV chargers, lighting, generators and repairs.', 'tradewell-leads' ),
			'style'    => 'electrical',
			'eyebrow'  => __( 'Licensed electricians', 'tradewell-leads' ),
			'headline' => __( 'Safe, code-compliant electrical work, done in a day.', 'tradewell-leads' ),
			'lead'     => __( 'Panel upgrades, EV chargers, lighting, generators and repairs from licensed electricians who pull the permits for you.', 'tradewell-leads' ),
			'calc'     => array(
				twleads_svc( __( 'Outlet or switch repair', 'tradewell-leads' ), 149 ),
				twleads_svc( __( 'Ceiling fan install', 'tradewell-leads' ), 225 ),
				twleads_svc_sized( __( 'Lighting install', 'tradewell-leads' ), 120, __( 'fixtures', 'tradewell-leads' ), 85, 1, 30, 1, 6 ),
				twleads_svc( __( 'Panel upgrade', 'tradewell-leads' ), 2400 ),
				twleads_svc( __( 'EV charger install', 'tradewell-leads' ), 950 ),
				twleads_svc( __( 'Whole-home generator', 'tradewell-leads' ), 6500 ),
				twleads_svc_sized( __( 'Home rewiring', 'tradewell-leads' ), 1500, __( 'sq ft of home', 'tradewell-leads' ), 2.8, 800, 4000, 100, 1800 ),
			),
			'booking'  => array( __( 'Repair', 'tradewell-leads' ), __( 'Panel upgrade', 'tradewell-leads' ), __( 'EV charger', 'tradewell-leads' ), __( 'Lighting', 'tradewell-leads' ), __( 'Generator', 'tradewell-leads' ), __( 'Inspection', 'tradewell-leads' ) ),
			'services' => array(
				array( __( 'Panel Upgrades', 'tradewell-leads' ), __( 'More power and safer circuits for modern homes.', 'tradewell-leads' ), array( __( 'Breakers tripping often', 'tradewell-leads' ), __( 'Flickering lights', 'tradewell-leads' ), __( 'Fuse box or 100-amp panel', 'tradewell-leads' ), __( 'Adding an EV or AC', 'tradewell-leads' ) ), '$2,400', __( 'installed', 'tradewell-leads' ) ),
				array( __( 'EV Chargers', 'tradewell-leads' ), __( 'Level 2 home charging installed and permitted.', 'tradewell-leads' ), array( __( 'New electric vehicle', 'tradewell-leads' ), __( 'Slow wall-outlet charging', 'tradewell-leads' ), __( 'Need a dedicated circuit', 'tradewell-leads' ), __( 'Want utility rebates', 'tradewell-leads' ) ), '$950', __( 'installed', 'tradewell-leads' ) ),
				array( __( 'Electrical Repair', 'tradewell-leads' ), __( 'Troubleshooting and repair for outlets, switches and wiring.', 'tradewell-leads' ), array( __( 'Dead outlets', 'tradewell-leads' ), __( 'Warm switch plates', 'tradewell-leads' ), __( 'Burning smell', 'tradewell-leads' ), __( 'Buzzing sounds', 'tradewell-leads' ) ), '$149', __( 'typical repair', 'tradewell-leads' ) ),
			),
		),
		'solar'      => array(
			'label'    => __( 'Solar', 'tradewell-leads' ),
			'desc'     => __( 'Solar panels, battery backup and EV charging.', 'tradewell-leads' ),
			'style'    => 'solar',
			'eyebrow'  => __( 'Solar & battery installers', 'tradewell-leads' ),
			'headline' => __( 'Cut your power bill with solar that pays for itself.', 'tradewell-leads' ),
			'lead'     => __( 'Custom solar design, battery backup and EV charging, with clear payback numbers before you sign anything.', 'tradewell-leads' ),
			'calc'     => array(
				twleads_svc_sized( __( 'Solar panel system', 'tradewell-leads' ), 2500, __( 'kW', 'tradewell-leads' ), 2650, 3, 15, 0.5, 7 ),
				twleads_svc_sized( __( 'Battery backup', 'tradewell-leads' ), 1500, __( 'kWh of storage', 'tradewell-leads' ), 900, 5, 40, 5, 13 ),
				twleads_svc( __( 'EV charger install', 'tradewell-leads' ), 950 ),
				twleads_svc_sized( __( 'Panel cleaning', 'tradewell-leads' ), 99, __( 'panels', 'tradewell-leads' ), 8, 8, 60, 2, 20 ),
				twleads_svc( __( 'Solar system repair', 'tradewell-leads' ), 249 ),
			),
			'booking'  => array( __( 'Free solar consultation', 'tradewell-leads' ), __( 'Battery backup', 'tradewell-leads' ), __( 'EV charger', 'tradewell-leads' ), __( 'Repair or monitoring', 'tradewell-leads' ), __( 'Panel cleaning', 'tradewell-leads' ) ),
			'services' => array(
				array( __( 'Solar Panels', 'tradewell-leads' ), __( 'Custom-designed systems with production guarantees.', 'tradewell-leads' ), array( __( 'Power bills over $150 a month', 'tradewell-leads' ), __( 'South or west-facing roof', 'tradewell-leads' ), __( 'Planning to stay 5+ years', 'tradewell-leads' ), __( 'Want to lock in energy costs', 'tradewell-leads' ) ), '$2.65', __( 'per watt', 'tradewell-leads' ) ),
				array( __( 'Battery Backup', 'tradewell-leads' ), __( 'Keep the lights on during outages and store cheap solar power.', 'tradewell-leads' ), array( __( 'Frequent power outages', 'tradewell-leads' ), __( 'Time-of-use rates', 'tradewell-leads' ), __( 'Medical equipment at home', 'tradewell-leads' ), __( 'Existing solar system', 'tradewell-leads' ) ), '$13,200', __( '13 kWh installed', 'tradewell-leads' ) ),
				array( __( 'EV Charging', 'tradewell-leads' ), __( 'Charge your car on sunshine with a Level 2 charger.', 'tradewell-leads' ), array( __( 'New electric vehicle', 'tradewell-leads' ), __( 'Slow overnight charging', 'tradewell-leads' ), __( 'Solar already installed', 'tradewell-leads' ), __( 'Utility EV rebates', 'tradewell-leads' ) ), '$950', __( 'installed', 'tradewell-leads' ) ),
			),
		),
	);
}

/**
 * Trade-specific reviews, emergency banner and footer copy.
 *
 * @return array
 */
function twleads_demo_trade_extras() {
	return array(
		'plumbing'   => array(
			'reviews' => array(
				array( __( 'Our water heater burst on a Sunday morning. They had a new one installed by lunch, at exactly the price they quoted on the phone.', 'tradewell-leads' ), __( 'Water heater', 'tradewell-leads' ) ),
				array( __( 'Two other plumbers wanted to dig up the yard. These folks ran a camera, found the root clog and cleared it the same afternoon.', 'tradewell-leads' ), __( 'Sewer line', 'tradewell-leads' ) ),
				array( __( 'Found a slab leak nobody else could find, fixed it without tearing up the floor and showed us the video afterwards.', 'tradewell-leads' ), __( 'Leak repair', 'tradewell-leads' ) ),
			),
			'cta'     => array( __( 'Burst pipe? Backed-up drain? No hot water?', 'tradewell-leads' ), __( 'A licensed plumber answers 24/7. Most emergencies get help within the hour.', 'tradewell-leads' ) ),
			'footer'  => array( __( 'Drain cleaning', 'tradewell-leads' ), __( 'Water heaters', 'tradewell-leads' ), __( 'Leak detection & repair', 'tradewell-leads' ), __( 'Sewer lines', 'tradewell-leads' ), __( 'Repiping', 'tradewell-leads' ) ),
			'about'   => __( 'Licensed plumbers for drains, leaks, water heaters and repiping. Fast response, honest pricing and work that is guaranteed.', 'tradewell-leads' ),
		),
		'hvac'       => array(
			'reviews' => array(
				array( __( 'Our AC quit on the hottest day of the year. They were here in under an hour, quoted a price before starting and had it running by dinner.', 'tradewell-leads' ), __( 'AC repair', 'tradewell-leads' ) ),
				array( __( 'They talked us out of a full replacement we did not need. A $300 repair and our furnace runs better than it has in years.', 'tradewell-leads' ), __( 'Furnace repair', 'tradewell-leads' ) ),
				array( __( 'The new heat pump cut our energy bill by a third, and they handled every rebate form for us.', 'tradewell-leads' ), __( 'Heat pump', 'tradewell-leads' ) ),
			),
			'cta'     => array( __( 'No heat? No cooling? Strange smell?', 'tradewell-leads' ), __( 'A real person answers 24/7. Most emergencies get a technician within the hour.', 'tradewell-leads' ) ),
			'footer'  => array( __( 'AC repair', 'tradewell-leads' ), __( 'Furnace service', 'tradewell-leads' ), __( 'Heat pumps', 'tradewell-leads' ), __( 'Duct cleaning', 'tradewell-leads' ), __( 'Indoor air quality', 'tradewell-leads' ) ),
			'about'   => __( 'Heating and cooling repair, maintenance and installation. Fast response, honest pricing and work that is guaranteed.', 'tradewell-leads' ),
		),
		'roofing'    => array(
			'reviews' => array(
				array( __( 'Three companies told us we needed a new roof. These folks found the actual leak, fixed it for a fraction of the cost and sent photos of everything.', 'tradewell-leads' ), __( 'Roof repair', 'tradewell-leads' ) ),
				array( __( 'After the hailstorm they tarped our roof the same night and walked us through the whole insurance claim.', 'tradewell-leads' ), __( 'Storm damage', 'tradewell-leads' ) ),
				array( __( 'New roof done in two days, magnets swept the yard for nails, and the crew was polite the entire time.', 'tradewell-leads' ), __( 'Roof replacement', 'tradewell-leads' ) ),
			),
			'cta'     => array( __( 'Active leak? Storm damage?', 'tradewell-leads' ), __( 'Emergency tarping 24/7. Free inspections and help with your insurance claim.', 'tradewell-leads' ) ),
			'footer'  => array( __( 'Roof repair', 'tradewell-leads' ), __( 'Roof replacement', 'tradewell-leads' ), __( 'Storm damage', 'tradewell-leads' ), __( 'Metal roofing', 'tradewell-leads' ), __( 'Gutters', 'tradewell-leads' ) ),
			'about'   => __( 'Roof repair, replacement and storm restoration. Free inspections, honest pricing and workmanship that is guaranteed.', 'tradewell-leads' ),
		),
		'electrical' => array(
			'reviews' => array(
				array( __( 'The panel upgrade and EV charger were done in one day. The electrician explained every step and pulled the permit for us.', 'tradewell-leads' ), __( 'Panel upgrade', 'tradewell-leads' ) ),
				array( __( 'Half our outlets went dead. They traced it to a loose connection in under an hour and checked the rest of the house for free.', 'tradewell-leads' ), __( 'Electrical repair', 'tradewell-leads' ) ),
				array( __( 'They installed a whole-home generator before storm season. The power went out twice and we never noticed.', 'tradewell-leads' ), __( 'Generator', 'tradewell-leads' ) ),
			),
			'cta'     => array( __( 'Sparks? Burning smell? Power out?', 'tradewell-leads' ), __( 'A licensed electrician answers 24/7. Most emergencies get help within the hour.', 'tradewell-leads' ) ),
			'footer'  => array( __( 'Panel upgrades', 'tradewell-leads' ), __( 'EV chargers', 'tradewell-leads' ), __( 'Lighting', 'tradewell-leads' ), __( 'Generators', 'tradewell-leads' ), __( 'Electrical repair', 'tradewell-leads' ) ),
			'about'   => __( 'Licensed electricians for repairs, upgrades, EV chargers and generators. Permits handled, work guaranteed.', 'tradewell-leads' ),
		),
		'solar'      => array(
			'reviews' => array(
				array( __( 'They showed us the payback math before we signed anything. Our first summer bill was $11.', 'tradewell-leads' ), __( 'Solar panels', 'tradewell-leads' ) ),
				array( __( 'The battery kicked in during a three-day outage and our fridge, lights and internet never went down.', 'tradewell-leads' ), __( 'Battery backup', 'tradewell-leads' ) ),
				array( __( 'Permits, utility paperwork and installation all handled. We just watched the app.', 'tradewell-leads' ), __( 'Solar installation', 'tradewell-leads' ) ),
			),
			'cta'     => array( __( 'See what solar could save you', 'tradewell-leads' ), __( 'Free consultation with real payback numbers. No pressure, no obligation.', 'tradewell-leads' ) ),
			'footer'  => array( __( 'Solar panels', 'tradewell-leads' ), __( 'Battery backup', 'tradewell-leads' ), __( 'EV charging', 'tradewell-leads' ), __( 'Solar repair', 'tradewell-leads' ), __( 'Panel cleaning', 'tradewell-leads' ) ),
			'about'   => __( 'Solar, battery and EV charging installers. Clear payback numbers, permits handled, production guaranteed.', 'tradewell-leads' ),
		),
	);
}
