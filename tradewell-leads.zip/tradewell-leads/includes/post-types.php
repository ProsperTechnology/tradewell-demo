<?php
/**
 * Post types: leads (private) and service areas (public).
 *
 * @package TradewellLeads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register post types.
 */
function twleads_register_post_types() {
	register_post_type(
		'twleads_lead',
		array(
			'labels'          => array(
				'name'          => __( 'Leads', 'tradewell-leads' ),
				'singular_name' => __( 'Lead', 'tradewell-leads' ),
				'menu_name'     => __( 'Leads', 'tradewell-leads' ),
				'all_items'     => __( 'All leads', 'tradewell-leads' ),
				'edit_item'     => __( 'Lead details', 'tradewell-leads' ),
				'search_items'  => __( 'Search leads', 'tradewell-leads' ),
				'not_found'     => __( 'No leads yet. They will appear here as soon as a visitor submits a form.', 'tradewell-leads' ),
			),
			'public'          => false,
			'show_ui'         => true,
			'show_in_menu'    => true,
			'show_in_rest'    => false,
			'menu_icon'       => 'dashicons-megaphone',
			'menu_position'   => 26,
			'supports'        => array( 'title' ),
			'capability_type' => 'post',
			'capabilities'    => array( 'create_posts' => 'do_not_allow' ),
			'map_meta_cap'    => true,
		)
	);

	register_post_type(
		'twleads_area',
		array(
			'labels'       => array(
				'name'          => __( 'Service areas', 'tradewell-leads' ),
				'singular_name' => __( 'Service area', 'tradewell-leads' ),
				'add_new_item'  => __( 'Add service area', 'tradewell-leads' ),
				'edit_item'     => __( 'Edit service area', 'tradewell-leads' ),
				'all_items'     => __( 'Service areas', 'tradewell-leads' ),
			),
			'public'       => true,
			'has_archive'  => true,
			'rewrite'      => array(
				'slug'       => 'service-areas',
				'with_front' => false,
			),
			'show_in_rest' => true,
			'show_in_menu' => 'edit.php?post_type=twleads_lead',
			'supports'     => array( 'title', 'editor', 'excerpt', 'thumbnail', 'custom-fields', 'revisions' ),
			'menu_icon'    => 'dashicons-location',
		)
	);

	register_post_meta(
		'twleads_area',
		'_twl_zips',
		array(
			'type'              => 'string',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => function ( $value ) {
				return implode( ', ', twleads_parse_zips( $value ) );
			},
			'auth_callback'     => function () {
				return current_user_can( 'edit_posts' );
			},
		)
	);
}
add_action( 'init', 'twleads_register_post_types' );

/**
 * ZIP codes meta box on service areas (works in both editors).
 */
function twleads_area_meta_box() {
	add_meta_box( 'twleads_area_zips', __( 'ZIP codes covered', 'tradewell-leads' ), 'twleads_render_area_meta_box', 'twleads_area', 'side' );
}
add_action( 'add_meta_boxes', 'twleads_area_meta_box' );

/**
 * Render meta box.
 *
 * @param WP_Post $post Post.
 */
function twleads_render_area_meta_box( $post ) {
	wp_nonce_field( 'twleads_area_zips', 'twleads_area_zips_nonce' );
	$zips = get_post_meta( $post->ID, '_twl_zips', true );
	echo '<p><label for="twleads_zips">' . esc_html__( 'Comma separated. Used by the ZIP checker.', 'tradewell-leads' ) . '</label></p>';
	echo '<textarea id="twleads_zips" name="twleads_zips" rows="4" style="width:100%">' . esc_textarea( $zips ) . '</textarea>';
}

/**
 * Save ZIP codes.
 *
 * @param int $post_id Post ID.
 */
function twleads_save_area_meta( $post_id ) {
	if ( ! isset( $_POST['twleads_area_zips_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['twleads_area_zips_nonce'] ) ), 'twleads_area_zips' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$zips = isset( $_POST['twleads_zips'] ) ? sanitize_textarea_field( wp_unslash( $_POST['twleads_zips'] ) ) : '';
	update_post_meta( $post_id, '_twl_zips', implode( ', ', twleads_parse_zips( $zips ) ) );
	delete_transient( 'twleads_zip_map' );
}
add_action( 'save_post_twleads_area', 'twleads_save_area_meta' );

/**
 * Map of ZIP => area post ID (0 when listed only in settings). Cached.
 *
 * @return array
 */
function twleads_zip_map() {
	$map = get_transient( 'twleads_zip_map' );
	if ( is_array( $map ) ) {
		return $map;
	}
	$map = array();
	foreach ( twleads_parse_zips( twleads_get( 'zips' ) ) as $zip ) {
		$map[ $zip ] = 0;
	}
	$areas = get_posts(
		array(
			'post_type'      => 'twleads_area',
			'post_status'    => 'publish',
			'posts_per_page' => 500, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- bounded, admin/cached lookup.
			'fields'         => 'ids',
			'no_found_rows'  => true,
		)
	);
	foreach ( $areas as $area_id ) {
		foreach ( twleads_parse_zips( get_post_meta( $area_id, '_twl_zips', true ) ) as $zip ) {
			$map[ $zip ] = (int) $area_id;
		}
	}
	set_transient( 'twleads_zip_map', $map, DAY_IN_SECONDS );
	return $map;
}

/**
 * Clear the ZIP cache when areas or settings change.
 */
function twleads_flush_zip_map() {
	delete_transient( 'twleads_zip_map' );
}
add_action( 'save_post_twleads_area', 'twleads_flush_zip_map', 20 );
add_action( 'deleted_post', 'twleads_flush_zip_map' );
add_action( 'trashed_post', 'twleads_flush_zip_map' );
add_action( 'update_option_twleads_settings', 'twleads_flush_zip_map' );
add_action(
	'updated_post_meta',
	function ( $meta_id, $post_id, $key ) {
		if ( '_twl_zips' === $key ) {
			twleads_flush_zip_map();
		}
	},
	10,
	3
);
