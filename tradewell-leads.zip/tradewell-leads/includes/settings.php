<?php
/**
 * Settings screen: Leads > Settings.
 *
 * @package TradewellLeads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings fields definition.
 *
 * @return array
 */
function twleads_settings_fields() {
	return array(
		'business' => array(
			'title'  => __( 'Business details', 'tradewell-leads' ),
			'fields' => array(
				'business_name' => array(
					'label' => __( 'Business name', 'tradewell-leads' ),
					'type'  => 'text',
					'help'  => __( 'Leave empty to use the site title.', 'tradewell-leads' ),
				),
				'phone'         => array(
					'label' => __( 'Phone number', 'tradewell-leads' ),
					'type'  => 'text',
					'help'  => __( 'Shown in the header, call buttons and click-to-call bar.', 'tradewell-leads' ),
				),
				'street'        => array(
					'label' => __( 'Street address', 'tradewell-leads' ),
					'type'  => 'text',
				),
				'city'          => array(
					'label' => __( 'City', 'tradewell-leads' ),
					'type'  => 'text',
				),
				'region'        => array(
					'label' => __( 'State / region', 'tradewell-leads' ),
					'type'  => 'text',
				),
				'postal'        => array(
					'label' => __( 'ZIP / postal code', 'tradewell-leads' ),
					'type'  => 'text',
				),
				'country'       => array(
					'label' => __( 'Country code', 'tradewell-leads' ),
					'type'  => 'text',
					'help'  => __( 'Two letters, e.g. US.', 'tradewell-leads' ),
				),
				'hours'         => array(
					'label' => __( 'Opening hours', 'tradewell-leads' ),
					'type'  => 'text',
					'help'  => __( 'Schema.org format, e.g. Mo-Fr 07:00-19:00, Sa 08:00-16:00', 'tradewell-leads' ),
				),
				'price_range'   => array(
					'label' => __( 'Price range', 'tradewell-leads' ),
					'type'  => 'text',
					'help'  => __( 'Used in search-engine markup, e.g. $$', 'tradewell-leads' ),
				),
				'currency'      => array(
					'label' => __( 'Currency symbol', 'tradewell-leads' ),
					'type'  => 'text',
				),
			),
		),
		'leads'    => array(
			'title'  => __( 'Lead delivery', 'tradewell-leads' ),
			'fields' => array(
				'notify_email' => array(
					'label' => __( 'Send new leads to', 'tradewell-leads' ),
					'type'  => 'text',
					'help'  => __( 'One or more emails, comma separated. Defaults to the site admin email.', 'tradewell-leads' ),
				),
				'webhook_url'  => array(
					'label' => __( 'Webhook URL', 'tradewell-leads' ),
					'type'  => 'url',
					'help'  => __( 'Optional. Each new lead is POSTed here as JSON (Zapier, Make, your CRM).', 'tradewell-leads' ),
				),
				'success_msg'  => array(
					'label' => __( 'Thank-you message', 'tradewell-leads' ),
					'type'  => 'textarea',
				),
				'consent'      => array(
					'label' => __( 'Consent text under forms', 'tradewell-leads' ),
					'type'  => 'textarea',
				),
			),
		),
		'areas'    => array(
			'title'  => __( 'Service area', 'tradewell-leads' ),
			'fields' => array(
				'zips' => array(
					'label' => __( 'Extra ZIP codes you serve', 'tradewell-leads' ),
					'type'  => 'textarea',
					'help'  => __( 'ZIPs listed on individual Service Area pages are included automatically. Add any others here.', 'tradewell-leads' ),
				),
			),
		),
		'callbar'  => array(
			'title'  => __( 'Mobile click-to-call bar', 'tradewell-leads' ),
			'fields' => array(
				'callbar'       => array(
					'label' => __( 'Show the bar on phones', 'tradewell-leads' ),
					'type'  => 'checkbox',
				),
				'callbar_quote' => array(
					'label' => __( 'Quote button link', 'tradewell-leads' ),
					'type'  => 'text',
					'help'  => __( 'Where the "Free quote" button goes. Default: #quote', 'tradewell-leads' ),
				),
			),
		),
	);
}

/**
 * Register the option.
 */
function twleads_register_settings() {
	register_setting(
		'twleads_settings_group',
		'twleads_settings',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'twleads_sanitize_settings',
			'default'           => array(),
		)
	);
}
add_action( 'admin_init', 'twleads_register_settings' );

/**
 * Sanitize settings.
 *
 * @param array $input Raw input.
 * @return array
 */
function twleads_sanitize_settings( $input ) {
	$input = (array) $input;
	$out   = array();
	foreach ( twleads_settings_fields() as $section ) {
		foreach ( $section['fields'] as $key => $field ) {
			$value = isset( $input[ $key ] ) ? $input[ $key ] : '';
			switch ( $field['type'] ) {
				case 'checkbox':
					$out[ $key ] = empty( $value ) ? 0 : 1;
					break;
				case 'url':
					$out[ $key ] = esc_url_raw( trim( $value, " \t\n\r\0\x0B" ) );
					break;
				case 'textarea':
					$out[ $key ] = sanitize_textarea_field( $value );
					break;
				default:
					$out[ $key ] = sanitize_text_field( $value );
			}
		}
	}
	if ( ! empty( $out['notify_email'] ) ) {
		$emails              = array_filter( array_map( 'sanitize_email', explode( ',', $out['notify_email'] ) ) );
		$out['notify_email'] = implode( ', ', $emails );
	}
	$out['zips'] = implode( ', ', twleads_parse_zips( $out['zips'] ) );
	return $out;
}

/**
 * Admin menu.
 */
function twleads_admin_menu() {
	add_submenu_page(
		'edit.php?post_type=twleads_lead',
		__( 'Tradewell Leads settings', 'tradewell-leads' ),
		__( 'Settings', 'tradewell-leads' ),
		'manage_options',
		'twl-settings',
		'twleads_render_settings_page'
	);
}
add_action( 'admin_menu', 'twleads_admin_menu' );

/**
 * Render the settings page.
 */
function twleads_render_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$values = twleads_get();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Tradewell Leads settings', 'tradewell-leads' ); ?></h1>
		<?php settings_errors(); ?>
		<form method="post" action="options.php">
			<?php settings_fields( 'twleads_settings_group' ); ?>
			<?php foreach ( twleads_settings_fields() as $section ) : ?>
				<h2 class="title"><?php echo esc_html( $section['title'] ); ?></h2>
				<table class="form-table" role="presentation">
					<?php foreach ( $section['fields'] as $key => $field ) : ?>
						<?php $id = 'twleads_' . $key; ?>
						<tr>
							<th scope="row"><label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $field['label'] ); ?></label></th>
							<td>
								<?php if ( 'checkbox' === $field['type'] ) : ?>
									<input type="checkbox" id="<?php echo esc_attr( $id ); ?>" name="twleads_settings[<?php echo esc_attr( $key ); ?>]" value="1" <?php checked( ! empty( $values[ $key ] ) ); ?> />
								<?php elseif ( 'textarea' === $field['type'] ) : ?>
									<textarea class="large-text" rows="3" id="<?php echo esc_attr( $id ); ?>" name="twleads_settings[<?php echo esc_attr( $key ); ?>]"><?php echo esc_textarea( $values[ $key ] ); ?></textarea>
								<?php else : ?>
									<input class="regular-text" type="<?php echo 'url' === $field['type'] ? 'url' : 'text'; ?>" id="<?php echo esc_attr( $id ); ?>" name="twleads_settings[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $values[ $key ] ); ?>" />
								<?php endif; ?>
								<?php if ( ! empty( $field['help'] ) ) : ?>
									<p class="description"><?php echo esc_html( $field['help'] ); ?></p>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</table>
			<?php endforeach; ?>
			<?php submit_button(); ?>
		</form>

		<hr />
		<p><a class="button" href="<?php echo esc_url( admin_url( 'edit.php?post_type=twleads_lead&page=twl-setup' ) ); ?>"><?php esc_html_e( 'Open the setup wizard', 'tradewell-leads' ); ?></a></p>
	</div>
	<?php
}
