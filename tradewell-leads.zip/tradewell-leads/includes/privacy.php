<?php
/**
 * Privacy: suggested policy text, personal data export and erasure.
 *
 * @package TradewellLeads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Suggested privacy policy text.
 */
function twleads_privacy_policy_content() {
	if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
		return;
	}
	$content = '<p>' . esc_html__( 'When you request a quote, book a visit or check our service area, we store the details you enter (such as name, phone, email, ZIP code, address and notes) so we can contact you about your request. These details are emailed to our team and may be sent to our customer management system. We do not sell your information. You can ask us to export or erase your data at any time.', 'tradewell-leads' ) . '</p>';
	wp_add_privacy_policy_content( 'Tradewell Leads', wp_kses_post( $content ) );
}
add_action( 'admin_init', 'twleads_privacy_policy_content' );

/**
 * Leads that belong to an email address.
 *
 * @param string $email Email.
 * @return int[]
 */
function twleads_leads_for_email( $email ) {
	return get_posts(
		array(
			'post_type'      => 'twleads_lead',
			'post_status'    => 'any',
			'posts_per_page' => 500, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- bounded, admin/cached lookup.
			'fields'         => 'ids',
			'meta_key'       => '_twl_email', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
		'meta_value'         => $email, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
		)
	);
}

/**
 * Register exporter.
 *
 * @param array $exporters Exporters.
 * @return array
 */
function twleads_register_exporter( $exporters ) {
	$exporters['tradewell-leads'] = array(
		'exporter_friendly_name' => __( 'Tradewell leads', 'tradewell-leads' ),
		'callback'               => function ( $email ) {
			$items = array();
			foreach ( twleads_leads_for_email( $email ) as $id ) {
				$data = array();
				foreach ( array( 'name', 'phone', 'email', 'zip', 'address', 'service', 'date', 'window', 'notes' ) as $key ) {
					$value = get_post_meta( $id, '_twl_' . $key, true );
					if ( '' !== (string) $value ) {
						$data[] = array(
							'name'  => ucfirst( $key ),
							'value' => $value,
						);
					}
				}
				$items[] = array(
					'group_id'    => 'twl-leads',
					'group_label' => __( 'Service requests', 'tradewell-leads' ),
					'item_id'     => 'twl-lead-' . $id,
					'data'        => $data,
				);
			}
			return array(
				'data' => $items,
				'done' => true,
			);
		},
	);
	return $exporters;
}
add_filter( 'wp_privacy_personal_data_exporters', 'twleads_register_exporter' );

/**
 * Register eraser.
 *
 * @param array $erasers Erasers.
 * @return array
 */
function twleads_register_eraser( $erasers ) {
	$erasers['tradewell-leads'] = array(
		'eraser_friendly_name' => __( 'Tradewell leads', 'tradewell-leads' ),
		'callback'             => function ( $email ) {
			$ids = twleads_leads_for_email( $email );
			foreach ( $ids as $id ) {
				wp_delete_post( $id, true );
			}
			return array(
				'items_removed'  => count( $ids ),
				'items_retained' => false,
				'messages'       => array(),
				'done'           => true,
			);
		},
	);
	return $erasers;
}
add_filter( 'wp_privacy_personal_data_erasers', 'twleads_register_eraser' );
