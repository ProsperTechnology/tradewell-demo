<?php
/**
 * Section patterns that use the plugin's blocks. Registered by the plugin so
 * they only exist when the blocks do.
 *
 * @package TradewellLeads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register patterns.
 */
function twleads_register_patterns() {
	register_block_pattern_category( 'twl', array( 'label' => __( 'Lead capture', 'tradewell-leads' ) ) );

	$check = '<!-- wp:list {"className":"is-style-tw-checklist"} --><ul class="wp-block-list is-style-tw-checklist">'
		. '<!-- wp:list-item --><li>' . esc_html__( 'Free, no-obligation estimates', 'tradewell-leads' ) . '</li><!-- /wp:list-item -->'
		. '<!-- wp:list-item --><li>' . esc_html__( 'Firm written price before work starts', 'tradewell-leads' ) . '</li><!-- /wp:list-item -->'
		. '<!-- wp:list-item --><li>' . esc_html__( 'Financing available on larger jobs', 'tradewell-leads' ) . '</li><!-- /wp:list-item -->'
		. '</ul><!-- /wp:list -->';

	register_block_pattern(
		'twl/quote-section',
		array(
			'title'      => __( 'Quote calculator section', 'tradewell-leads' ),
			'categories' => array( 'twl', 'call-to-action' ),
			'content'    => '<!-- wp:group {"anchor":"quote","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"margin":{"top":"0"}}},"backgroundColor":"surface","layout":{"type":"constrained","contentSize":"1240px"}} -->
<div id="quote" class="wp-block-group alignfull has-surface-background-color has-background" style="margin-top:0;padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:columns {"verticalAlignment":"top","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns are-vertically-aligned-top">
<!-- wp:column {"verticalAlignment":"top","width":"40%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:40%">
<!-- wp:paragraph {"className":"is-style-tw-eyebrow"} --><p class="is-style-tw-eyebrow">' . esc_html__( 'Instant estimate', 'tradewell-leads' ) . '</p><!-- /wp:paragraph -->
<!-- wp:heading --><h2 class="wp-block-heading">' . esc_html__( 'Know the price before we show up', 'tradewell-leads' ) . '</h2><!-- /wp:heading -->
<!-- wp:paragraph --><p>' . esc_html__( 'Most homeowners hesitate to call because they fear the bill. Our estimator gives you an honest price range in seconds, based on real jobs in your area.', 'tradewell-leads' ) . '</p><!-- /wp:paragraph -->
' . $check . '
<!-- wp:twl/phone {"variant":"text","label":"' . esc_attr__( 'Rather talk?', 'tradewell-leads' ) . '"} /-->
</div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"top","width":"60%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:60%">
<!-- wp:twl/quote-calculator /-->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->',
		)
	);

	register_block_pattern(
		'twl/booking-section',
		array(
			'title'      => __( 'Booking section', 'tradewell-leads' ),
			'categories' => array( 'twl', 'call-to-action' ),
			'content'    => '<!-- wp:group {"anchor":"book","align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"margin":{"top":"0"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->
<div id="book" class="wp-block-group alignfull" style="margin-top:0;padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:columns {"style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns">
<!-- wp:column {"width":"38%"} -->
<div class="wp-block-column" style="flex-basis:38%">
<!-- wp:paragraph {"className":"is-style-tw-eyebrow"} --><p class="is-style-tw-eyebrow">' . esc_html__( 'Online booking', 'tradewell-leads' ) . '</p><!-- /wp:paragraph -->
<!-- wp:heading --><h2 class="wp-block-heading">' . esc_html__( 'Pick a time that works for you', 'tradewell-leads' ) . '</h2><!-- /wp:heading -->
<!-- wp:paragraph --><p>' . esc_html__( 'Choose a day and a three-hour arrival window. Your technician texts you when they are on the way.', 'tradewell-leads' ) . '</p><!-- /wp:paragraph -->
<!-- wp:twl/phone {"variant":"button"} /-->
</div>
<!-- /wp:column -->
<!-- wp:column {"width":"62%"} -->
<div class="wp-block-column" style="flex-basis:62%">
<!-- wp:twl/booking-form /-->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->',
		)
	);

	register_block_pattern(
		'twl/area-section',
		array(
			'title'      => __( 'Service area section', 'tradewell-leads' ),
			'categories' => array( 'twl' ),
			'content'    => '<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"margin":{"top":"0"}},"elements":{"link":{"color":{"text":"var:preset|color|on-primary"}}}},"backgroundColor":"primary","textColor":"on-primary","layout":{"type":"constrained","contentSize":"1240px"}} -->
<div class="wp-block-group alignfull has-on-primary-color has-primary-background-color has-text-color has-background has-link-color" style="margin-top:0;padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">
<!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|60"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center">
<!-- wp:paragraph {"className":"is-style-tw-eyebrow","style":{"color":{"text":"var:preset|color|highlight"}}} --><p class="is-style-tw-eyebrow has-text-color" style="color:var(--wp--preset--color--highlight)">' . esc_html__( 'Local crews', 'tradewell-leads' ) . '</p><!-- /wp:paragraph -->
<!-- wp:heading {"style":{"color":{"text":"var:preset|color|on-primary"}}} --><h2 class="wp-block-heading has-text-color" style="color:var(--wp--preset--color--on-primary)">' . esc_html__( 'Trucks stocked and nearby', 'tradewell-leads' ) . '</h2><!-- /wp:heading -->
<!-- wp:paragraph {"style":{"color":{"text":"#ffffffd9"}}} --><p class="has-text-color" style="color:#ffffffd9">' . esc_html__( 'Our technicians live in the neighborhoods they serve, so help is minutes away, not hours.', 'tradewell-leads' ) . '</p><!-- /wp:paragraph -->
<!-- wp:twl/service-areas {"columns":2} /-->
</div>
<!-- /wp:column -->
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center">
<!-- wp:twl/area-checker /-->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->',
		)
	);
}
add_action( 'init', 'twleads_register_patterns' );
