<?php
/**
 * Block registration and shared form markup.
 *
 * @package TradewellLeads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register asset handles and blocks.
 */
function twleads_register_blocks() {
	wp_register_script(
		'twl-editor',
		TWLEADS_URL . 'assets/editor.js',
		array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-server-side-render', 'wp-i18n' ),
		TWLEADS_VERSION,
		true
	);
	wp_set_script_translations( 'twl-editor', 'tradewell-leads', TWLEADS_PATH . 'languages' );

	wp_register_script(
		'twl-front',
		TWLEADS_URL . 'assets/front.js',
		array(),
		TWLEADS_VERSION,
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);
	wp_add_inline_script(
		'twl-front',
		'window.twlI18n=' . wp_json_encode(
			array(
				'name'    => __( 'Please enter your name.', 'tradewell-leads' ),
				'phone'   => __( 'Please enter a valid phone number.', 'tradewell-leads' ),
				'email'   => __( 'Please check your email address.', 'tradewell-leads' ),
				'date'    => __( 'Please choose a day.', 'tradewell-leads' ),
				'sending' => __( 'Sending…', 'tradewell-leads' ),
				'error'   => __( 'Something went wrong. Please call us instead.', 'tradewell-leads' ),
				'offline' => __( 'Connection problem. Please try again or call us.', 'tradewell-leads' ),
				'size'    => __( 'Size:', 'tradewell-leads' ),
			)
		) . ';',
		'before'
	);
	wp_register_style( 'twl-front', TWLEADS_URL . 'assets/front.css', array(), TWLEADS_VERSION );

	foreach ( array( 'quote-calculator', 'booking-form', 'area-checker', 'service-areas', 'phone' ) as $block ) {
		if ( function_exists( 'register_block_type' ) ) {
			register_block_type( TWLEADS_PATH . 'blocks/' . $block );
		}
	}
}
add_action( 'init', 'twleads_register_blocks' );

/**
 * Block category.
 *
 * @param array $categories Categories.
 * @return array
 */
function twleads_block_category( $categories ) {
	array_unshift(
		$categories,
		array(
			'slug'  => 'twl',
			'title' => __( 'Tradewell Leads', 'tradewell-leads' ),
		)
	);
	return $categories;
}
add_filter( 'block_categories_all', 'twleads_block_category' );

/**
 * Attach blocks to our category (block.json uses a core category as fallback).
 *
 * @param array $args Block args.
 * @param string $name Block name.
 * @return array
 */
function twleads_block_args( $args, $name ) {
	if ( 0 === strpos( $name, 'twl/' ) ) {
		$args['category'] = 'twl';
	}
	return $args;
}
add_filter( 'register_block_type_args', 'twleads_block_args', 10, 2 );

/**
 * Opening <form> markup shared by all lead forms.
 *
 * @param string $type Lead type.
 * @param array  $extra_attrs Extra data attributes.
 * @return string
 */
function twleads_form_open( $type, $extra_attrs = array() ) {
	$attrs = array_merge(
		array(
			'class'         => 'twl-form',
			'method'        => 'post',
			'action'        => admin_url( 'admin-post.php' ),
			'data-endpoint' => rest_url( 'twl/v1/leads' ),
			'novalidate'    => 'novalidate',
		),
		$extra_attrs
	);
	$html  = '<form';
	foreach ( $attrs as $key => $value ) {
		$html .= ' ' . esc_attr( $key ) . '="' . esc_attr( $value ) . '"';
	}
	$html .= '>';
	$html .= '<input type="hidden" name="action" value="twleads_lead">';
	$html .= '<input type="hidden" name="type" value="' . esc_attr( $type ) . '">';
	$html .= '<input type="hidden" name="twleads_token" value="' . esc_attr( twleads_form_token() ) . '">';
	$html .= '<input type="hidden" name="page" value="">';
	// Honeypot field, hidden from people and assistive tech.
	$html .= '<div class="twl-hp" aria-hidden="true"><label>Website<input type="text" name="company_website" tabindex="-1" autocomplete="off"></label></div>';
	return $html;
}

/**
 * A labelled input.
 *
 * @param string $name  Field name.
 * @param string $label Label.
 * @param array  $args  type, required, autocomplete, placeholder, inputmode, full.
 * @return string
 */
function twleads_field( $name, $label, $args = array() ) {
	$args  = wp_parse_args(
		$args,
		array(
			'type'         => 'text',
			'required'     => false,
			'autocomplete' => '',
			'inputmode'    => '',
			'full'         => false,
			'uid'          => '',
		)
	);
	$id    = 'twl-' . $name . '-' . ( $args['uid'] ? $args['uid'] : wp_unique_id() );
	$html  = '<div class="twl-field' . ( $args['full'] ? ' twl-field--full' : '' ) . '">';
	$html .= '<label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . ( $args['required'] ? ' <span class="twl-req" aria-hidden="true">*</span>' : '' ) . '</label>';
	if ( 'textarea' === $args['type'] ) {
		$html .= '<textarea id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" rows="3"></textarea>';
	} else {
		$html .= '<input id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" type="' . esc_attr( $args['type'] ) . '"';
		if ( $args['required'] ) {
			$html .= ' required aria-required="true"';
		}
		if ( $args['autocomplete'] ) {
			$html .= ' autocomplete="' . esc_attr( $args['autocomplete'] ) . '"';
		}
		if ( $args['inputmode'] ) {
			$html .= ' inputmode="' . esc_attr( $args['inputmode'] ) . '"';
		}
		$html .= '>';
	}
	$html .= '<span class="twl-error" role="alert"></span></div>';
	return $html;
}

/**
 * Contact fields shared by quote and booking forms.
 *
 * @param bool $with_address Include street address.
 * @return string
 */
function twleads_contact_fields( $with_address = false ) {
	$uid   = wp_unique_id();
	$html  = '<div class="twl-grid">';
	$html .= twleads_field(
		'name',
		__( 'Your name', 'tradewell-leads' ),
		array(
			'required'     => true,
			'autocomplete' => 'name',
			'uid'          => $uid,
		)
	);
	$html .= twleads_field(
		'phone',
		__( 'Mobile phone', 'tradewell-leads' ),
		array(
			'type'         => 'tel',
			'required'     => true,
			'autocomplete' => 'tel',
			'inputmode'    => 'tel',
			'uid'          => $uid,
		)
	);
	$html .= twleads_field(
		'email',
		__( 'Email (optional)', 'tradewell-leads' ),
		array(
			'type'         => 'email',
			'autocomplete' => 'email',
			'uid'          => $uid,
		)
	);
	$html .= twleads_field(
		'zip',
		__( 'ZIP code', 'tradewell-leads' ),
		array(
			'autocomplete' => 'postal-code',
			'inputmode'    => 'numeric',
			'uid'          => $uid,
		)
	);
	if ( $with_address ) {
		$html .= twleads_field(
			'address',
			__( 'Street address', 'tradewell-leads' ),
			array(
				'autocomplete' => 'address-line1',
				'full'         => true,
				'uid'          => $uid,
			)
		);
	}
	$html .= twleads_field(
		'notes',
		__( 'Anything we should know? (optional)', 'tradewell-leads' ),
		array(
			'type' => 'textarea',
			'full' => true,
			'uid'  => $uid,
		)
	);
	$html .= '</div>';
	return $html;
}

/**
 * Submit button, consent line and status region (caller closes the form).
 *
 * @param string $label Button label.
 * @return string
 */
function twleads_form_submit( $label ) {
	$html  = '<button type="submit" class="twl-btn wp-element-button">' . esc_html( $label ) . '</button>';
	$html .= '<p class="twl-consent">' . esc_html( twleads_get( 'consent' ) ) . '</p>';
	$html .= '<div class="twl-status" role="status" aria-live="polite"></div>';
	return $html;
}

/**
 * Success / error message after a no-JavaScript submit.
 *
 * @return string
 */
function twleads_fallback_notice() {
	static $shown = false;
	if ( $shown ) {
		return '';
	}
	$state = isset( $_GET['twl'] ) ? sanitize_key( $_GET['twl'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( $state ) {
		$shown = true;
	}
	if ( 'sent' === $state ) {
		return '<div id="twl-msg" class="twl-done">' . twleads_icon( 'check' ) . '<p>' . esc_html( twleads_get( 'success_msg' ) ) . '</p></div>';
	}
	if ( 'error' === $state ) {
		return '<div id="twl-msg" class="twl-status is-error"><p>' . esc_html__( 'Something was missing. Please check the form and try again, or call us.', 'tradewell-leads' ) . '</p></div>';
	}
	return '';
}
