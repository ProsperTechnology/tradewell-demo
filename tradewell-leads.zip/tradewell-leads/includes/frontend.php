<?php
/**
 * Front end: mobile click-to-call bar and LocalBusiness structured data.
 *
 * @package TradewellLeads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Whether the call bar shows on this request.
 *
 * @return bool
 */
function twleads_callbar_enabled() {
	if ( is_admin() || ! twleads_get( 'callbar' ) || ! twleads_get( 'phone' ) ) {
		return false;
	}
	/** Filter whether to show the call bar on this request. */
	return (bool) apply_filters( 'twleads_show_callbar', true );
}

/**
 * Call bar stylesheet (about 1 KB).
 */
function twleads_callbar_style() {
	if ( twleads_callbar_enabled() ) {
		wp_enqueue_style( 'twl-callbar', TWLEADS_URL . 'assets/callbar.css', array(), TWLEADS_VERSION );
	}
}
add_action( 'wp_enqueue_scripts', 'twleads_callbar_style' );

/**
 * Mobile call bar markup. No JavaScript.
 */
function twleads_render_callbar() {
	if ( ! twleads_callbar_enabled() ) {
		return;
	}
	$phone = twleads_get( 'phone' );
	$quote = twleads_get( 'callbar_quote' ) ? twleads_get( 'callbar_quote' ) : '#quote';
	?>
	<nav class="twl-callbar" aria-label="<?php esc_attr_e( 'Quick contact', 'tradewell-leads' ); ?>">
		<a class="twl-callbar__call" href="tel:<?php echo esc_attr( twleads_tel( $phone ) ); ?>"><?php echo twleads_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php esc_html_e( 'Call now', 'tradewell-leads' ); ?></a>
		<a class="twl-callbar__quote" href="<?php echo esc_url( $quote ); ?>"><?php echo twleads_icon( 'quote' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php esc_html_e( 'Free quote', 'tradewell-leads' ); ?></a>
	</nav>
	<?php
}
add_action( 'wp_footer', 'twleads_render_callbar', 5 );

/**
 * LocalBusiness JSON-LD on the front page and service-area pages.
 */
function twleads_schema() {
	if ( ! is_front_page() && ! is_singular( 'twleads_area' ) ) {
		return;
	}
	/** Let SEO plugins disable our markup if they already output it. */
	if ( ! apply_filters( 'twleads_output_schema', true ) ) {
		return;
	}
	$schema  = array(
		'@context'   => 'https://schema.org',
		'@type'      => 'HomeAndConstructionBusiness',
		'@id'        => home_url( '/#business' ),
		'name'       => twleads_business_name(),
		'url'        => home_url( '/' ),
		'telephone'  => twleads_get( 'phone' ),
		'priceRange' => twleads_get( 'price_range' ),
	);
	$logo_id = get_theme_mod( 'custom_logo' );
	if ( $logo_id ) {
		$schema['image'] = wp_get_attachment_image_url( $logo_id, 'full' );
	}
	if ( twleads_get( 'street' ) || twleads_get( 'city' ) ) {
		$schema['address'] = array_filter(
			array(
				'@type'           => 'PostalAddress',
				'streetAddress'   => twleads_get( 'street' ),
				'addressLocality' => twleads_get( 'city' ),
				'addressRegion'   => twleads_get( 'region' ),
				'postalCode'      => twleads_get( 'postal' ),
				'addressCountry'  => twleads_get( 'country' ),
			)
		);
	}
	if ( twleads_get( 'hours' ) ) {
		$schema['openingHours'] = array_map( 'trim', explode( ',', twleads_get( 'hours' ) ) );
	}
	if ( is_singular( 'twleads_area' ) ) {
		$schema['areaServed'] = array(
			'@type' => 'Place',
			'name'  => get_the_title(),
		);
	} else {
		$areas = get_posts(
			array(
				'post_type'      => 'twleads_area',
				'posts_per_page' => 50,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		if ( $areas ) {
			$schema['areaServed'] = array_map(
				function ( $id ) {
					return array(
						'@type' => 'Place',
						'name'  => get_the_title( $id ),
					);
				},
				$areas
			);
		}
	}
	$schema = apply_filters( 'twleads_schema', array_filter( $schema ) );
	echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
}
add_action( 'wp_head', 'twleads_schema', 20 );
