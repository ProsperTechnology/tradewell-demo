<?php
/**
 * Shared helpers.
 *
 * @package TradewellLeads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Default settings.
 *
 * @return array
 */
function twleads_default_settings() {
	return array(
		'business_name' => '',
		'phone'         => '(555) 010-0199',
		'notify_email'  => '',
		'street'        => '',
		'city'          => '',
		'region'        => '',
		'postal'        => '',
		'country'       => 'US',
		'price_range'   => '$$',
		'hours'         => 'Mo-Fr 07:00-19:00, Sa 08:00-16:00',
		'currency'      => '$',
		'zips'          => '',
		'callbar'       => 1,
		'callbar_quote' => '#quote',
		'webhook_url'   => '',
		'success_msg'   => __( 'Thanks! We got your request and will call you shortly. Need help right now? Call us.', 'tradewell-leads' ),
		'consent'       => __( 'By submitting you agree to be contacted about your request. We never sell your information.', 'tradewell-leads' ),
	);
}

/**
 * Get a setting (or all settings).
 *
 * @param string|null $key Setting key.
 * @return mixed
 */
function twleads_get( $key = null ) {
	$settings = wp_parse_args( (array) get_option( 'twleads_settings', array() ), twleads_default_settings() );
	if ( null === $key ) {
		return $settings;
	}
	return isset( $settings[ $key ] ) ? $settings[ $key ] : null;
}

/**
 * Business name, falling back to the site title.
 *
 * @return string
 */
function twleads_business_name() {
	$name = twleads_get( 'business_name' );
	return $name ? $name : get_bloginfo( 'name' );
}

/**
 * Phone number formatted for a tel: link.
 *
 * @param string $phone Display phone.
 * @return string
 */
function twleads_tel( $phone ) {
	$digits = preg_replace( '/[^0-9+]/', '', (string) $phone );
	return $digits;
}

/**
 * Normalise a list of ZIP / postal codes from free text.
 *
 * @param string $text Comma, space or newline separated codes.
 * @return string[]
 */
function twleads_parse_zips( $text ) {
	$parts = preg_split( '/[\s,;]+/', strtoupper( (string) $text ) );
	$parts = array_map( 'trim', (array) $parts );
	$parts = array_filter(
		$parts,
		function ( $z ) {
			return '' !== $z && strlen( $z ) <= 10;
		}
	);
	return array_values( array_unique( $parts ) );
}

/**
 * Signed form token: timestamp plus HMAC. Lets us reject instant bot posts
 * without nonces, so forms keep working behind full-page caches.
 *
 * @return string
 */
function twleads_form_token() {
	$time = time();
	return $time . '.' . substr( hash_hmac( 'sha256', (string) $time, wp_salt( 'nonce' ) ), 0, 20 );
}

/**
 * Validate a form token.
 *
 * @param string $token Token.
 * @return true|WP_Error
 */
function twleads_check_token( $token ) {
	$parts = explode( '.', (string) $token );
	if ( 2 !== count( $parts ) || ! ctype_digit( $parts[0] ) ) {
		return new WP_Error( 'twleads_token', __( 'Please reload the page and try again.', 'tradewell-leads' ) );
	}
	$expected = substr( hash_hmac( 'sha256', $parts[0], wp_salt( 'nonce' ) ), 0, 20 );
	if ( ! hash_equals( $expected, $parts[1] ) ) {
		return new WP_Error( 'twleads_token', __( 'Please reload the page and try again.', 'tradewell-leads' ) );
	}
	$age = time() - (int) $parts[0];
	if ( $age < 3 ) {
		return new WP_Error( 'twleads_fast', __( 'That was quick! Please wait a moment and submit again.', 'tradewell-leads' ) );
	}
	if ( $age > 14 * DAY_IN_SECONDS ) {
		return new WP_Error( 'twleads_token', __( 'This form has expired. Please reload the page and try again.', 'tradewell-leads' ) );
	}
	return true;
}

/**
 * Inline SVG icons for the plugin UI.
 *
 * @param string $name Icon.
 * @return string
 */
function twleads_icon( $name ) {
	$icons = array(
		'phone' => '<path d="M5 3h3.5l1.5 4.5-2.2 1.4a12 12 0 0 0 7.3 7.3l1.4-2.2L21 15.5V19a2 2 0 0 1-2 2A17 17 0 0 1 3 5a2 2 0 0 1 2-2z"/>',
		'pin'   => '<path d="M12 21s-7-6.2-7-11.5a7 7 0 0 1 14 0C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
		'check' => '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
		'quote' => '<path d="M4 4h16v12H8l-4 4V4z"/><path d="M8 9h8M8 12h5"/>',
	);
	if ( ! isset( $icons[ $name ] ) ) {
		return '';
	}
	return '<svg class="twl-ico" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $icons[ $name ] . '</svg>';
}

/**
 * Limit submitted text without requiring the optional mbstring extension.
 *
 * @param string $text Text to limit.
 * @param int    $limit Maximum length.
 * @return string
 */
function twleads_trim_text( $text, $limit ) {
	return function_exists( 'mb_substr' ) ? mb_substr( $text, 0, $limit ) : substr( $text, 0, $limit );
}

/**
 * Resolve the default quote anchor from any page or subdirectory install.
 *
 * @return string
 */
function twleads_quote_url() {
	$url = twleads_get( 'callbar_quote' );
	return ! $url || '#quote' === $url ? home_url( '/#quote' ) : $url;
}
