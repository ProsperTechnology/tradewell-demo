<?php
/**
 * Setup wizard: one-click starter sites for each trade.
 *
 * Builds pages from the Tradewell theme's patterns, applies the matching
 * style variation, fills the quote calculator and booking form with trade
 * presets, creates the menu and sets the homepage. Everything it creates is
 * tagged so it can be removed again with one click.
 *
 * @package TradewellLeads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin page.
 */
function twleads_setup_menu() {
	add_submenu_page(
		'edit.php?post_type=twleads_lead',
		__( 'Setup wizard', 'tradewell-leads' ),
		__( 'Setup wizard', 'tradewell-leads' ),
		'manage_options',
		'twl-setup',
		'twleads_render_setup_page',
		0
	);
}
add_action( 'admin_menu', 'twleads_setup_menu' );

/**
 * Send the user to the wizard once after activation.
 */
function twleads_setup_redirect() {
	if ( ! get_transient( 'twleads_activation_redirect' ) ) {
		return;
	}
	delete_transient( 'twleads_activation_redirect' );
	if ( wp_doing_ajax() || is_network_admin() || isset( $_GET['activate-multi'] ) || ! current_user_can( 'manage_options' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return;
	}
	wp_safe_redirect( admin_url( 'edit.php?post_type=twleads_lead&page=twl-setup' ) );
	exit;
}
add_action( 'admin_init', 'twleads_setup_redirect' );

/**
 * Registered pattern content.
 *
 * @param string $slug Pattern slug.
 * @return string
 */
function twleads_pattern( $slug ) {
	$pattern = WP_Block_Patterns_Registry::get_instance()->get_registered( $slug );
	return $pattern ? $pattern['content'] : '';
}

/**
 * A theme string as it appears in rendered pattern markup.
 *
 * @param string $text English source text from the Tradewell theme.
 * @return string
 */
function twleads_theme_str( $text ) {
	return esc_html( translate( $text, 'tradewell' ) ); // phpcs:ignore WordPress.WP.I18n.LowLevelTranslationFunction, WordPress.WP.I18n.NonSingularStringLiteralText, WordPress.WP.I18n.TextDomainMismatch -- matching the theme's own translated pattern text.
}

/**
 * Serialize a dynamic block.
 *
 * @param string $name  Block name.
 * @param array  $attrs Attributes.
 * @return string
 */
function twleads_block( $name, $attrs = array() ) {
	return get_comment_delimited_block_content( $name, $attrs, '' );
}

/**
 * Hero section for a trade.
 *
 * @param array  $trade Trade data.
 * @param string $slug  Trade slug.
 * @return string
 */
function twleads_build_hero( $trade, $slug ) {
	$html = twleads_pattern( 'tradewell/hero' );
	if ( ! $html ) {
		return '';
	}
	$html = str_replace(
		array(
			twleads_theme_str( 'Same-day service across the metro' ),
			twleads_theme_str( 'Fixed right the first time. Priced before we start.' ),
			twleads_theme_str( 'Licensed technicians for heating, cooling, plumbing, roofing, electrical and solar. Get an instant estimate in under a minute.' ),
		),
		array( esc_html( $trade['eyebrow'] ), esc_html( $trade['headline'] ), esc_html( $trade['lead'] ) ),
		$html
	);
	if ( 'multi' !== $slug && function_exists( 'tradewell_icon' ) ) {
		$start = strpos( $html, '<!-- wp:group {"className":"tw-trade-strip"' );
		if ( false !== $start ) {
			$open_end = strpos( $html, '-->', $start ) + 3;
			$div_end  = strpos( $html, '>', $open_end ) + 1;
			$close    = strpos( $html, '</div>' . "\n" . '<!-- /wp:group -->', $div_end );
			if ( false !== $close ) {
				$links = '';
				foreach ( array_slice( $trade['calc'], 0, 6 ) as $svc ) {
					$links .= "<!-- wp:html -->\n<a class=\"tw-trade-link\" href=\"#quote\"><span class=\"tw-icon\" aria-hidden=\"true\">" . tradewell_icon( $slug, 26 ) . '</span><span>' . esc_html( $svc['label'] ) . "</span></a>\n<!-- /wp:html -->\n";
				}
				$html = substr( $html, 0, $div_end ) . "\n" . $links . substr( $html, $close );
			}
		}
	}
	return $html;
}

/**
 * Services grid linking to the trade's service pages.
 *
 * @param array  $trade    Trade data.
 * @param string $slug     Trade slug.
 * @param array  $page_ids Service page IDs, in the same order as $trade['services'].
 * @return string
 */
function twleads_build_services( $trade, $slug, $page_ids ) {
	$icons = array( 'multi' => array( 'hvac', 'plumbing', 'roofing' ) );
	$out   = '<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"},"margin":{"top":"0"}}},"layout":{"type":"constrained","contentSize":"1240px"}} -->' . "\n";
	$out  .= '<div class="wp-block-group alignfull" style="margin-top:0;padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)">' . "\n";
	$out  .= '<!-- wp:paragraph {"className":"is-style-tw-eyebrow"} --><p class="is-style-tw-eyebrow">' . esc_html__( 'What we do', 'tradewell-leads' ) . '</p><!-- /wp:paragraph -->' . "\n";
	/* translators: %s: trade name, e.g. Plumbing. */
	$heading = 'multi' === $slug ? __( 'One call for every system in your home', 'tradewell-leads' ) : sprintf( __( '%s services, done properly', 'tradewell-leads' ), $trade['label'] );
	$out    .= '<!-- wp:heading {"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|50"}}}} --><h2 class="wp-block-heading" style="margin-bottom:var(--wp--preset--spacing--50)">' . esc_html( $heading ) . '</h2><!-- /wp:heading -->' . "\n";
	$out    .= '<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|40"}},"layout":{"type":"grid","minimumColumnWidth":"20rem"}} -->' . "\n" . '<div class="wp-block-group">' . "\n";
	foreach ( $trade['services'] as $i => $svc ) {
		$icon = isset( $icons[ $slug ][ $i ] ) ? $icons[ $slug ][ $i ] : $slug;
		$url  = isset( $page_ids[ $i ] ) ? get_permalink( $page_ids[ $i ] ) : '#quote';
		$out .= '<!-- wp:group {"className":"is-style-tw-card","style":{"spacing":{"padding":{"top":"var:preset|spacing|50","bottom":"var:preset|spacing|50","left":"var:preset|spacing|40","right":"var:preset|spacing|40"},"blockGap":"0.75rem"}},"layout":{"type":"default"}} -->' . "\n";
		$out .= '<div class="wp-block-group is-style-tw-card" style="padding-top:var(--wp--preset--spacing--50);padding-right:var(--wp--preset--spacing--40);padding-bottom:var(--wp--preset--spacing--50);padding-left:var(--wp--preset--spacing--40)">' . "\n";
		if ( function_exists( 'tradewell_icon' ) ) {
			$out .= "<!-- wp:html -->\n<span class=\"tw-icon tw-icon-chip\" aria-hidden=\"true\">" . tradewell_icon( $icon, 24 ) . "</span>\n<!-- /wp:html -->\n";
		}
		$out .= '<!-- wp:heading {"level":3} --><h3 class="wp-block-heading">' . esc_html( $svc[0] ) . '</h3><!-- /wp:heading -->' . "\n";
		$out .= '<!-- wp:paragraph {"textColor":"muted","fontSize":"small"} --><p class="has-muted-color has-text-color has-small-font-size">' . esc_html( $svc[1] ) . '</p><!-- /wp:paragraph -->' . "\n";
		/* translators: 1: price, 2: price note. */
		$out .= '<!-- wp:paragraph {"fontSize":"small"} --><p class="has-small-font-size">' . sprintf( esc_html__( 'From %1$s %2$s', 'tradewell-leads' ), '<strong>' . esc_html( $svc[3] ) . '</strong>', esc_html( $svc[4] ) ) . '</p><!-- /wp:paragraph -->' . "\n";
		$out .= '<!-- wp:paragraph {"style":{"typography":{"fontWeight":"700"}},"fontSize":"small"} --><p class="has-small-font-size" style="font-weight:700"><a href="' . esc_url( $url ) . '">' . esc_html__( 'Learn more', 'tradewell-leads' ) . ' &rarr;</a></p><!-- /wp:paragraph -->' . "\n";
		$out .= "</div>\n<!-- /wp:group -->\n";
	}
	$out .= "</div>\n<!-- /wp:group -->\n</div>\n<!-- /wp:group -->\n";
	return $out;
}

/**
 * Quote section with the trade's calculator presets.
 *
 * @param array $trade Trade data.
 * @return string
 */
function twleads_build_quote( $trade ) {
	return str_replace( '<!-- wp:twl/quote-calculator /-->', twleads_block( 'twl/quote-calculator', array( 'services' => $trade['calc'] ) ), twleads_pattern( 'twl/quote-section' ) );
}

/**
 * Booking section with the trade's services.
 *
 * @param array $trade Trade data.
 * @return string
 */
function twleads_build_booking( $trade ) {
	return str_replace( '<!-- wp:twl/booking-form /-->', twleads_block( 'twl/booking-form', array( 'services' => implode( "\n", $trade['booking'] ) ) ), twleads_pattern( 'twl/booking-section' ) );
}

/**
 * Service detail section.
 *
 * @param array $svc Service row.
 * @return string
 */
function twleads_build_service_detail( $svc ) {
	$html     = twleads_pattern( 'tradewell/service-detail' );
	$defaults = array( 'Warm air or weak airflow from vents', 'Unusual noises, smells or short cycling', 'Energy bills climbing for no clear reason', 'Water pooling around the indoor unit' );
	foreach ( $defaults as $i => $text ) {
		if ( isset( $svc[2][ $i ] ) ) {
			$html = str_replace( twleads_theme_str( $text ), esc_html( $svc[2][ $i ] ), $html );
		}
	}
	$html = str_replace(
		array( '<strong>$89</strong>', '<span>' . twleads_theme_str( 'diagnostic' ) . '</span>', twleads_theme_str( 'Waived when you approve the repair.' ) ),
		array( '<strong>' . esc_html( $svc[3] ) . '</strong>', '<span>' . esc_html( $svc[4] ) . '</span>', esc_html__( 'Firm written price before any work begins.', 'tradewell-leads' ) ),
		$html
	);
	return $html;
}

/**
 * Reviews section with trade-specific reviews.
 *
 * @param array $extra Trade extras.
 * @return string
 */
function twleads_build_reviews( $extra ) {
	$html = twleads_pattern( 'tradewell/reviews' );
	if ( empty( $extra['reviews'] ) ) {
		return $html;
	}
	$defaults = array(
		array( 'Our AC quit on the hottest day of the year. They were here in under an hour, quoted a price before starting and had it running by dinner.', 'AC repair' ),
		array( 'Three companies told us we needed a new roof. These folks found the actual leak, fixed it for a fraction of the cost and sent photos of everything.', 'Roof repair' ),
		array( 'The panel upgrade and EV charger were done in one day. The electrician explained every step and pulled the permit for us.', 'Electrical' ),
	);
	foreach ( $defaults as $i => $d ) {
		$html = str_replace( twleads_theme_str( $d[0] ), esc_html( $extra['reviews'][ $i ][0] ), $html );
		$html = str_replace( '&middot; ' . twleads_theme_str( $d[1] ) . '</p>', '&middot; ' . esc_html( $extra['reviews'][ $i ][1] ) . '</p>', $html );
	}
	return $html;
}

/**
 * Emergency call to action with trade copy.
 *
 * @param array $extra Trade extras.
 * @return string
 */
function twleads_build_cta( $extra ) {
	$html = twleads_pattern( 'tradewell/cta-emergency' );
	if ( empty( $extra['cta'] ) ) {
		return $html;
	}
	return str_replace(
		array( twleads_theme_str( 'Water on the floor? No heat? Sparks?' ), twleads_theme_str( 'A real person answers 24/7. Most emergencies get a technician within the hour.' ) ),
		array( esc_html( $extra['cta'][0] ), esc_html( $extra['cta'][1] ) ),
		$html
	);
}

/**
 * Footer template part override with trade services.
 *
 * @param array $extra Trade extras.
 * @param array $ids   Page IDs.
 */
function twleads_build_footer( $extra, $ids ) {
	$file = get_theme_file_path( 'parts/footer.html' );
	if ( empty( $extra['footer'] ) || ! file_exists( $file ) ) {
		return;
	}
	$html     = (string) file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local theme file.
	$defaults = array( 'Heating &amp; cooling', 'Plumbing &amp; drains', 'Roof repair &amp; replacement', 'Electrical', 'Solar installation' );
	foreach ( $defaults as $i => $d ) {
		$url  = ! empty( $ids['services'] ) ? get_permalink( $ids['services'] ) : '';
		$item = $url ? '<a href="' . esc_url( $url ) . '">' . esc_html( $extra['footer'][ $i ] ) . '</a>' : esc_html( $extra['footer'][ $i ] );
		$html = str_replace( '<li>' . $d . '</li>', '<li>' . $item . '</li>', $html );
	}
	$html = str_replace( 'Heating, cooling, plumbing, roofing, electrical and solar for homes and businesses. Fast response, honest pricing and work that is guaranteed.', esc_html( $extra['about'] ), $html );
	$html = str_replace( '&copy; Your Company.', '&copy; ' . esc_html( twleads_business_name() ) . '.', $html );
	$id   = twleads_demo_insert(
		array(
			'post_type'    => 'wp_template_part',
			'post_name'    => 'footer',
			'post_title'   => __( 'Footer', 'tradewell-leads' ),
			'post_content' => $html,
		)
	);
	if ( $id ) {
		wp_set_post_terms( $id, array( get_stylesheet() ), 'wp_theme' );
		wp_set_post_terms( $id, array( 'footer' ), 'wp_template_part_area' );
	}
}

/**
 * Create a demo post and tag it.
 *
 * @param array $args wp_insert_post args.
 * @return int
 */
function twleads_demo_insert( $args ) {
	$args = wp_parse_args(
		$args,
		array(
			'post_status' => 'publish',
			'post_type'   => 'page',
		)
	);
	$id   = wp_insert_post( wp_slash( $args ) );
	if ( $id && ! is_wp_error( $id ) ) {
		update_post_meta( $id, '_twl_demo', 1 );
		return (int) $id;
	}
	return 0;
}

/**
 * Remove everything a previous setup created.
 *
 * @return int Number of items removed.
 */
function twleads_remove_demo() {
	$ids = get_posts(
		array(
			'post_type'      => array( 'page', 'twleads_area', 'wp_navigation', 'wp_template', 'wp_template_part' ),
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'meta_key'       => '_twl_demo', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
		)
	);
	foreach ( $ids as $id ) {
		wp_delete_post( $id, true );
	}
	if ( get_option( 'twleads_demo_front' ) ) {
		update_option( 'show_on_front', 'posts' );
		delete_option( 'page_on_front' );
		delete_option( 'page_for_posts' );
		delete_option( 'twleads_demo_front' );
	}
	delete_transient( 'twleads_zip_map' );
	return count( $ids );
}

/**
 * Apply a theme style variation to the site's global styles.
 *
 * @param string $style Variation file slug, or '' for the default.
 */
function twleads_apply_style( $style ) {
	if ( ! class_exists( 'WP_Theme_JSON_Resolver' ) ) {
		return;
	}
	$data = array(
		'version'                     => 3,
		'isGlobalStylesUserThemeJSON' => true,
	);
	if ( $style ) {
		$file = get_theme_file_path( 'styles/' . sanitize_file_name( $style ) . '.json' );
		if ( file_exists( $file ) ) {
			$json = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local theme file.
			if ( is_array( $json ) ) {
				$data['settings'] = isset( $json['settings'] ) ? $json['settings'] : array();
				$data['styles']   = isset( $json['styles'] ) ? $json['styles'] : array();
				$data['title']    = isset( $json['title'] ) ? $json['title'] : '';
			}
		}
	}
	$post_id = WP_Theme_JSON_Resolver::get_user_global_styles_post_id();
	if ( $post_id ) {
		wp_update_post(
			wp_slash(
				array(
					'ID'           => $post_id,
					'post_content' => wp_json_encode( $data ),
				)
			)
		);
		WP_Theme_JSON_Resolver::clean_cached_data();
		if ( function_exists( 'wp_clean_theme_json_cache' ) ) {
			wp_clean_theme_json_cache();
		}
	}
}

/**
 * Run the setup.
 *
 * @param string $slug   Trade slug.
 * @param array  $fields Business fields.
 * @return array Created page IDs keyed by role.
 */
function twleads_run_setup( $slug, $fields ) {
	$trades = twleads_demo_trades();
	$trade  = isset( $trades[ $slug ] ) ? $trades[ $slug ] : $trades['multi'];

	twleads_remove_demo();

	$settings = (array) get_option( 'twleads_settings', array() );
	foreach ( array( 'business_name', 'phone', 'notify_email', 'city' ) as $key ) {
		if ( ! empty( $fields[ $key ] ) ) {
			$settings[ $key ] = $fields[ $key ];
		}
	}
	update_option( 'twleads_settings', twleads_sanitize_settings( wp_parse_args( $settings, twleads_default_settings() ) ) );
	if ( ! empty( $fields['business_name'] ) ) {
		update_option( 'blogname', $fields['business_name'] );
	}

	twleads_apply_style( $trade['style'] );

	$extras = twleads_demo_trade_extras();
	$extra  = isset( $extras[ $slug ] ) ? $extras[ $slug ] : array();
	$p      = 'twleads_pattern';
	$cta    = twleads_build_cta( $extra );
	$rev    = twleads_build_reviews( $extra );
	$ids    = array();

	$ids['services'] = twleads_demo_insert(
		array(
			'post_title'   => __( 'Services', 'tradewell-leads' ),
			'post_name'    => 'services',
			'post_excerpt' => $trade['desc'],
			'menu_order'   => 1,
		)
	);
	$service_ids     = array();
	foreach ( $trade['services'] as $i => $svc ) {
		$service_ids[] = twleads_demo_insert(
			array(
				'post_title'   => $svc[0],
				'post_parent'  => $ids['services'],
				'post_excerpt' => $svc[1],
				'menu_order'   => $i,
				'post_content' => twleads_build_service_detail( $svc ) . twleads_build_quote( $trade ) . $p( 'tradewell/faq' ) . $cta,
				'meta_input'   => array( '_wp_page_template' => 'page-wide' ),
			)
		);
	}
	$services_grid = twleads_build_services( $trade, $slug, $service_ids );
	wp_update_post(
		array(
			'ID'           => $ids['services'],
			'post_content' => wp_slash( $services_grid . $p( 'tradewell/offers' ) . $p( 'tradewell/process' ) . $cta ),
			'meta_input'   => array( '_wp_page_template' => 'page-wide' ),
		)
	);

	$pages = array(
		'plans'     => array( __( 'Maintenance Plans', 'tradewell-leads' ), 'plans', __( 'Tune-ups, priority service and member discounts for one low monthly price.', 'tradewell-leads' ), $p( 'tradewell/plans' ) . $p( 'tradewell/faq' ) ),
		'financing' => array( __( 'Financing', 'tradewell-leads' ), 'financing', __( 'Affordable monthly payments on repairs and replacements.', 'tradewell-leads' ), $p( 'tradewell/financing' ) . $p( 'tradewell/offers' ) . $cta ),
		'about'     => array( __( 'About', 'tradewell-leads' ), 'about', __( 'Local, licensed and on time since day one.', 'tradewell-leads' ), $p( 'tradewell/about-story' ) . $p( 'tradewell/stats' ) . $p( 'tradewell/team' ) . $rev ),
		'book'      => array( __( 'Book Online', 'tradewell-leads' ), 'book', __( 'Pick a day and arrival window. We confirm by text.', 'tradewell-leads' ), twleads_build_booking( $trade ) . $p( 'tradewell/faq' ) ),
		'contact'   => array( __( 'Contact', 'tradewell-leads' ), 'contact', __( 'Call, text, email or book online. A real person answers 24/7.', 'tradewell-leads' ), $p( 'tradewell/contact-info' ) . twleads_build_booking( $trade ) . $p( 'twl/area-section' ) ),
	);
	$order = 2;
	foreach ( $pages as $key => $page ) {
		$ids[ $key ] = twleads_demo_insert(
			array(
				'post_title'   => $page[0],
				'post_name'    => $page[1],
				'post_excerpt' => $page[2],
				'post_content' => $page[3],
				'menu_order'   => $order++,
				'meta_input'   => array( '_wp_page_template' => 'page-wide' ),
			)
		);
	}

	$home_content = twleads_build_hero( $trade, $slug ) . $p( 'tradewell/trust-bar' ) . $services_grid . twleads_build_quote( $trade )
		. $p( 'tradewell/offers' ) . $p( 'tradewell/process' ) . $p( 'twl/area-section' ) . $rev
		. $p( 'tradewell/stats' ) . $p( 'tradewell/plans' ) . $p( 'tradewell/faq' ) . $cta;
	$ids['home']  = twleads_demo_insert(
		array(
			'post_title'   => __( 'Home', 'tradewell-leads' ),
			'post_name'    => 'home',
			'post_content' => $home_content,
			'menu_order'   => 0,
		)
	);
	$ids['news']  = twleads_demo_insert(
		array(
			'post_title' => __( 'News & Tips', 'tradewell-leads' ),
			'post_name'  => 'news',
			'menu_order' => 9,
		)
	);

	twleads_build_footer( $extra, $ids );

	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $ids['home'] );
	update_option( 'page_for_posts', $ids['news'] );
	update_option( 'twleads_demo_front', 1 );

	// Front page template that renders the Home page content.
	$template_id = twleads_demo_insert(
		array(
			'post_type'    => 'wp_template',
			'post_name'    => 'front-page',
			'post_title'   => __( 'Front Page', 'tradewell-leads' ),
			'post_content' => '<!-- wp:template-part {"slug":"header","area":"header","tagName":"header"} /-->' . "\n"
				. '<!-- wp:group {"tagName":"main","style":{"spacing":{"blockGap":"0","margin":{"top":"0"}}},"layout":{"type":"default"}} -->' . "\n"
				. '<main class="wp-block-group" style="margin-top:0"><!-- wp:post-content {"layout":{"type":"default"}} /--></main>' . "\n"
				. '<!-- /wp:group -->' . "\n"
				. '<!-- wp:template-part {"slug":"footer","area":"footer","tagName":"div"} /-->',
		)
	);
	if ( $template_id ) {
		wp_set_post_terms( $template_id, array( get_stylesheet() ), 'wp_theme' );
	}

	// Navigation menu.
	$link = function ( $id, $label = '' ) {
		return get_comment_delimited_block_content(
			'core/navigation-link',
			array(
				'label' => $label ? $label : get_the_title( $id ),
				'type'  => 'page',
				'id'    => $id,
				'url'   => get_permalink( $id ),
				'kind'  => 'post-type',
			),
			''
		);
	};
	$sub  = '';
	foreach ( $service_ids as $sid ) {
		$sub .= $link( $sid );
	}
	$nav  = get_comment_delimited_block_content(
		'core/navigation-submenu',
		array(
			'label' => __( 'Services', 'tradewell-leads' ),
			'type'  => 'page',
			'id'    => $ids['services'],
			'url'   => get_permalink( $ids['services'] ),
			'kind'  => 'post-type',
		),
		$sub
	);
	$nav .= $link( $ids['plans'], __( 'Plans', 'tradewell-leads' ) ) . $link( $ids['financing'] ) . $link( $ids['about'] ) . $link( $ids['contact'] );
	twleads_demo_insert(
		array(
			'post_type'    => 'wp_navigation',
			'post_title'   => __( 'Main menu', 'tradewell-leads' ),
			'post_content' => $nav,
		)
	);

	// Sample service areas.
	$city  = ! empty( $fields['city'] ) ? $fields['city'] : '';
	$areas = array(
		array( __( 'Northside', 'tradewell-leads' ), '90001, 90002, 90003' ),
		array( __( 'Riverside', 'tradewell-leads' ), '90011, 90012' ),
		array( __( 'Oak Hills', 'tradewell-leads' ), '90021, 90022, 90023' ),
		array( __( 'Downtown', 'tradewell-leads' ), '90031, 90032' ),
	);
	foreach ( $areas as $area ) {
		$name = $city ? $area[0] . ', ' . $city : $area[0];
		$body = '<!-- wp:paragraph --><p>' . sprintf(
			/* translators: 1: area name, 2: trade services. */
			esc_html__( 'Looking for a reliable contractor in %1$s? Our local crews handle %2$s, with flat-rate pricing approved by you before any work begins.', 'tradewell-leads' ),
			esc_html( $name ),
			esc_html( strtolower( $trade['desc'] ) )
		) . '</p><!-- /wp:paragraph -->';
		$body .= '<!-- wp:twl/area-checker {"headingLevel":2} /-->';
		$aid   = twleads_demo_insert(
			array(
				'post_type'    => 'twleads_area',
				'post_title'   => $name,
				/* translators: 1: trade label, 2: area name. */
				'post_excerpt' => sprintf( __( 'Trusted %1$s service in %2$s, with technicians based minutes away.', 'tradewell-leads' ), strtolower( $trade['label'] ), $name ),
				'post_content' => $body,
			)
		);
		if ( $aid ) {
			update_post_meta( $aid, '_twl_zips', $area[1] );
		}
	}

	delete_transient( 'twleads_zip_map' );
	flush_rewrite_rules();
	update_option( 'twleads_setup_trade', $slug );
	return $ids;
}

/**
 * Handle the wizard form.
 */
function twleads_handle_setup() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Not allowed.', 'tradewell-leads' ) );
	}
	check_admin_referer( 'twleads_setup' );
	$back = admin_url( 'edit.php?post_type=twleads_lead&page=twl-setup' );

	if ( isset( $_POST['twleads_remove'] ) ) {
		$count = twleads_remove_demo();
		delete_option( 'twleads_setup_trade' );
		wp_safe_redirect( add_query_arg( 'twleads_removed', $count, $back ) );
		exit;
	}

	$trade  = isset( $_POST['twleads_trade'] ) ? sanitize_key( wp_unslash( $_POST['twleads_trade'] ) ) : 'multi';
	$fields = array(
		'business_name' => isset( $_POST['twleads_business'] ) ? sanitize_text_field( wp_unslash( $_POST['twleads_business'] ) ) : '',
		'phone'         => isset( $_POST['twleads_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['twleads_phone'] ) ) : '',
		'notify_email'  => isset( $_POST['twleads_email'] ) ? sanitize_email( wp_unslash( $_POST['twleads_email'] ) ) : '',
		'city'          => isset( $_POST['twleads_city'] ) ? sanitize_text_field( wp_unslash( $_POST['twleads_city'] ) ) : '',
	);
	twleads_run_setup( $trade, $fields );
	wp_safe_redirect( add_query_arg( 'twleads_done', 1, $back ) );
	exit;
}
add_action( 'admin_post_twleads_setup', 'twleads_handle_setup' );

/**
 * Wizard screen.
 */
function twleads_render_setup_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$trades   = twleads_demo_trades();
	$current  = get_option( 'twleads_setup_trade', '' );
	$settings = twleads_get();
	$theme_ok = function_exists( 'tradewell_icon' );
	?>
	<div class="wrap twl-setup">
		<h1><?php esc_html_e( 'Set up your website', 'tradewell-leads' ); ?></h1>
		<p class="twl-setup-lead"><?php esc_html_e( 'Choose your trade and we will build a complete starter site: homepage, service pages, plans, financing, about, booking and contact pages, menu, colors, quote calculator prices and booking options. You can change everything afterwards.', 'tradewell-leads' ); ?></p>

		<?php if ( ! $theme_ok ) : ?>
			<div class="notice notice-warning inline"><p><?php esc_html_e( 'Activate the Tradewell theme first. The starter sites are built from its patterns.', 'tradewell-leads' ); ?></p></div>
		<?php endif; ?>

		<?php if ( isset( $_GET['twleads_done'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
			<div class="notice notice-success inline twl-done-box">
				<p><strong><?php esc_html_e( 'Your site is ready.', 'tradewell-leads' ); ?></strong> <?php esc_html_e( 'Next: replace the sample reviews, team and service areas with your own.', 'tradewell-leads' ); ?></p>
				<p>
					<a class="button button-primary" href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'View your site', 'tradewell-leads' ); ?></a>
					<a class="button" href="<?php echo esc_url( admin_url( 'post.php?post=' . (int) get_option( 'page_on_front' ) . '&action=edit' ) ); ?>"><?php esc_html_e( 'Edit homepage', 'tradewell-leads' ); ?></a>
					<a class="button" href="<?php echo esc_url( admin_url( 'site-editor.php?p=%2Fstyles' ) ); ?>"><?php esc_html_e( 'Change colors and fonts', 'tradewell-leads' ); ?></a>
					<a class="button" href="<?php echo esc_url( admin_url( 'edit.php?post_type=twleads_area' ) ); ?>"><?php esc_html_e( 'Edit service areas', 'tradewell-leads' ); ?></a>
				</p>
			</div>
		<?php endif; ?>
		<?php if ( isset( $_GET['twleads_removed'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
			<div class="notice notice-info inline"><p><?php esc_html_e( 'Starter content removed.', 'tradewell-leads' ); ?></p></div>
		<?php endif; ?>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="twleads_setup" />
			<?php wp_nonce_field( 'twleads_setup' ); ?>
			<h2><?php esc_html_e( '1. Your trade', 'tradewell-leads' ); ?></h2>
			<div class="twl-trades" role="radiogroup" aria-label="<?php esc_attr_e( 'Trade', 'tradewell-leads' ); ?>">
				<?php foreach ( $trades as $slug => $trade ) : ?>
					<?php
					$colors = twleads_style_swatches( $trade['style'] );
					$check  = $current ? $current === $slug : 'multi' === $slug;
					?>
					<label class="twl-trade">
						<input type="radio" name="twleads_trade" value="<?php echo esc_attr( $slug ); ?>" <?php checked( $check ); ?> />
						<span class="twl-trade-card">
							<span class="twl-swatch" style="background:<?php echo esc_attr( $colors[0] ); ?>">
								<?php if ( $theme_ok ) : ?>
									<span class="twl-swatch-icon" style="color:<?php echo esc_attr( $colors[1] ); ?>"><?php echo tradewell_icon( 'multi' === $slug ? 'wrench' : $slug, 34 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?></span>
								<?php endif; ?>
							</span>
							<strong><?php echo esc_html( $trade['label'] ); ?></strong>
							<small><?php echo esc_html( $trade['desc'] ); ?></small>
						</span>
					</label>
				<?php endforeach; ?>
			</div>

			<h2><?php esc_html_e( '2. Your business', 'tradewell-leads' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr><th scope="row"><label for="twleads_business"><?php esc_html_e( 'Business name', 'tradewell-leads' ); ?></label></th><td><input class="regular-text" type="text" id="twleads_business" name="twleads_business" value="<?php echo esc_attr( twleads_business_name() ); ?>" /></td></tr>
				<tr><th scope="row"><label for="twleads_phone"><?php esc_html_e( 'Phone number', 'tradewell-leads' ); ?></label></th><td><input class="regular-text" id="twleads_phone" name="twleads_phone" type="tel" value="<?php echo esc_attr( $settings['phone'] ); ?>" /></td></tr>
				<tr><th scope="row"><label for="twleads_email"><?php esc_html_e( 'Send leads to', 'tradewell-leads' ); ?></label></th><td><input class="regular-text" id="twleads_email" name="twleads_email" type="email" value="<?php echo esc_attr( $settings['notify_email'] ? $settings['notify_email'] : get_option( 'admin_email' ) ); ?>" /></td></tr>
				<tr><th scope="row"><label for="twleads_city"><?php esc_html_e( 'Main city', 'tradewell-leads' ); ?></label></th><td><input class="regular-text" type="text" id="twleads_city" name="twleads_city" value="<?php echo esc_attr( $settings['city'] ); ?>" /><p class="description"><?php esc_html_e( 'Used to name the sample service-area pages.', 'tradewell-leads' ); ?></p></td></tr>
			</table>

			<h2><?php esc_html_e( '3. Build', 'tradewell-leads' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Running setup again replaces the starter pages it created earlier. Pages and posts you created yourself are never touched.', 'tradewell-leads' ); ?></p>
			<p>
				<?php submit_button( $current ? __( 'Rebuild starter site', 'tradewell-leads' ) : __( 'Build my site', 'tradewell-leads' ), 'primary large', 'twleads_build', false, $theme_ok ? array() : array( 'disabled' => 'disabled' ) ); ?>
				<?php if ( $current ) : ?>
					<?php submit_button( __( 'Remove starter content', 'tradewell-leads' ), 'link-delete', 'twleads_remove', false ); ?>
				<?php endif; ?>
			</p>
		</form>
	</div>
	<style>
		.twl-setup-lead{font-size:15px;max-width:760px}
		.twl-trades{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:12px;max-width:1100px}
		.twl-trade{position:relative;cursor:pointer}
		.twl-trade input{position:absolute;opacity:0}
		.twl-trade-card{display:flex;flex-direction:column;gap:6px;height:100%;padding:12px;border:2px solid #dcdcde;border-radius:10px;background:#fff;box-sizing:border-box}
		.twl-trade input:checked+.twl-trade-card{border-color:#2271b1;box-shadow:0 0 0 1px #2271b1}
		.twl-trade input:focus-visible+.twl-trade-card{outline:2px solid #2271b1;outline-offset:2px}
		.twl-swatch{display:grid;place-items:center;height:84px;border-radius:6px;margin-bottom:4px}
		.twl-swatch-icon svg{display:block}
		.twl-trade small{color:#50575e;line-height:1.4}
		.twl-done-box .button{margin:0 6px 6px 0}
	</style>
	<?php
}

/**
 * Primary and accent colors of a style variation for the wizard swatches.
 *
 * @param string $style Variation slug.
 * @return string[]
 */
function twleads_style_swatches( $style ) {
	$file = $style ? get_theme_file_path( 'styles/' . sanitize_file_name( $style ) . '.json' ) : get_theme_file_path( 'theme.json' );
	$out  = array( '#12304F', '#F26B1D' );
	if ( file_exists( $file ) ) {
		$json = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local theme file.
		foreach ( (array) ( $json['settings']['color']['palette'] ?? array() ) as $color ) {
			if ( 'primary' === $color['slug'] ) {
				$out[0] = $color['color'];
			}
			if ( 'accent' === $color['slug'] ) {
				$out[1] = $color['color'];
			}
		}
	}
	return $out;
}
