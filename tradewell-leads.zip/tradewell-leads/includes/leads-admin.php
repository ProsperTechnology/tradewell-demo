<?php
/**
 * Leads inbox: list columns, detail view, status, CSV export.
 *
 * @package TradewellLeads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * List table columns.
 *
 * @return array
 */
function twleads_lead_columns() {
	return array(
		'cb'               => '<input type="checkbox" />',
		'title'            => __( 'Lead', 'tradewell-leads' ),
		'twleads_status'   => __( 'Status', 'tradewell-leads' ),
		'twleads_phone'    => __( 'Phone', 'tradewell-leads' ),
		'twleads_zip'      => __( 'ZIP', 'tradewell-leads' ),
		'twleads_estimate' => __( 'Estimate / day', 'tradewell-leads' ),
		'date'             => __( 'Received', 'tradewell-leads' ),
	);
}
add_filter( 'manage_twleads_lead_posts_columns', 'twleads_lead_columns' );

/**
 * Column content.
 *
 * @param string $column  Column.
 * @param int    $post_id Post.
 */
function twleads_lead_column_content( $column, $post_id ) {
	switch ( $column ) {
		case 'twleads_status':
			$statuses = twleads_lead_statuses();
			$status   = get_post_meta( $post_id, '_twl_status', true );
			$status   = isset( $statuses[ $status ] ) ? $status : 'new';
			printf( '<span class="twl-badge twl-badge--%1$s">%2$s</span>', esc_attr( $status ), esc_html( $statuses[ $status ] ) );
			break;
		case 'twleads_phone':
			$phone = get_post_meta( $post_id, '_twl_phone', true );
			printf( '<a href="tel:%1$s">%2$s</a>', esc_attr( twleads_tel( $phone ) ), esc_html( $phone ) );
			break;
		case 'twleads_zip':
			echo esc_html( get_post_meta( $post_id, '_twl_zip', true ) );
			break;
		case 'twleads_estimate':
			$est = twleads_format_estimate(
				array(
					'est_low'  => (float) get_post_meta( $post_id, '_twl_est_low', true ),
					'est_high' => (float) get_post_meta( $post_id, '_twl_est_high', true ),
				)
			);
			$day = get_post_meta( $post_id, '_twl_date', true );
			$win = get_post_meta( $post_id, '_twl_window', true );
			echo esc_html( $est ? $est : trim( $day . ' ' . $win, " \t\n\r\0\x0B" ) );
			break;
	}
}
add_action( 'manage_twleads_lead_posts_custom_column', 'twleads_lead_column_content', 10, 2 );

/**
 * Status filter dropdown and export button.
 *
 * @param string $post_type Post type.
 */
function twleads_lead_filters( $post_type ) {
	if ( 'twleads_lead' !== $post_type ) {
		return;
	}
	$current = isset( $_GET['twleads_status'] ) ? sanitize_key( $_GET['twleads_status'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	echo '<select name="twleads_status"><option value="">' . esc_html__( 'All statuses', 'tradewell-leads' ) . '</option>';
	foreach ( twleads_lead_statuses() as $key => $label ) {
		printf( '<option value="%1$s" %2$s>%3$s</option>', esc_attr( $key ), selected( $current, $key, false ), esc_html( $label ) );
	}
	echo '</select>';
}
add_action( 'restrict_manage_posts', 'twleads_lead_filters' );

/**
 * Apply status filter.
 *
 * @param WP_Query $query Query.
 */
function twleads_lead_filter_query( $query ) {
	if ( ! is_admin() || ! $query->is_main_query() || 'twleads_lead' !== $query->get( 'post_type' ) ) {
		return;
	}
	$status = isset( $_GET['twleads_status'] ) ? sanitize_key( $_GET['twleads_status'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( $status ) {
		$query->set( 'meta_key', '_twl_status' );
		$query->set( 'meta_value', $status );
	}
}
add_action( 'pre_get_posts', 'twleads_lead_filter_query' );

/**
 * Export button above the list.
 */
function twleads_lead_export_button() {
	$screen = get_current_screen();
	if ( ! $screen || 'edit-twleads_lead' !== $screen->id ) {
		return;
	}
	$url = wp_nonce_url( admin_url( 'admin-post.php?action=twleads_export' ), 'twleads_export' );
	echo '<div class="notice notice-info inline" style="display:flex;align-items:center;gap:12px;padding:8px 12px"><span>' . esc_html__( 'Every form submission lands here and is emailed to you.', 'tradewell-leads' ) . '</span><a class="button" href="' . esc_url( $url ) . '">' . esc_html__( 'Export CSV', 'tradewell-leads' ) . '</a></div>';
}
add_action( 'admin_notices', 'twleads_lead_export_button' );

/**
 * Stream CSV export.
 */
function twleads_export_csv() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Not allowed.', 'tradewell-leads' ) );
	}
	check_admin_referer( 'twleads_export' );
	$keys = array( 'type', 'status', 'name', 'phone', 'email', 'zip', 'address', 'service', 'size', 'urgency', 'est_low', 'est_high', 'date', 'window', 'notes', 'page' );
	nocache_headers();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename=leads-' . gmdate( 'Y-m-d' ) . '.csv' );
	$out = fopen( 'php://output', 'w' );
	fputcsv( $out, array_merge( array( 'id', 'received' ), $keys ), ',', '"', '\\' );
	$paged = 1;
	do {
		$leads = get_posts(
			array(
				'post_type'      => 'twleads_lead',
				'post_status'    => 'any',
				'posts_per_page' => 100,
				'paged'          => $paged,
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);
		foreach ( $leads as $lead ) {
			$row = array( $lead->ID, $lead->post_date );
			foreach ( $keys as $key ) {
				$value = (string) get_post_meta( $lead->ID, '_twl_' . $key, true );
				// Prevent spreadsheet formula injection.
				if ( '' !== $value && in_array( $value[0], array( '=', '+', '-', '@' ), true ) && ! is_numeric( $value ) ) {
					$value = "'" . $value;
				}
				$row[] = $value;
			}
			fputcsv( $out, $row, ',', '"', '\\' );
		}
		++$paged;
		$batch = count( $leads );
	} while ( 100 === $batch );
	fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
	exit;
}
add_action( 'admin_post_twleads_export', 'twleads_export_csv' );

/**
 * Lead detail meta boxes.
 */
function twleads_lead_meta_boxes() {
	add_meta_box( 'twleads_lead_details', __( 'Request', 'tradewell-leads' ), 'twleads_render_lead_details', 'twleads_lead', 'normal', 'high' );
	add_meta_box( 'twleads_lead_status', __( 'Status', 'tradewell-leads' ), 'twleads_render_lead_status', 'twleads_lead', 'side', 'high' );
}
add_action( 'add_meta_boxes', 'twleads_lead_meta_boxes' );

/**
 * Render details table.
 *
 * @param WP_Post $post Post.
 */
function twleads_render_lead_details( $post ) {
	$types  = twleads_lead_types();
	$fields = array(
		'type'    => __( 'Type', 'tradewell-leads' ),
		'name'    => __( 'Name', 'tradewell-leads' ),
		'phone'   => __( 'Phone', 'tradewell-leads' ),
		'email'   => __( 'Email', 'tradewell-leads' ),
		'zip'     => __( 'ZIP', 'tradewell-leads' ),
		'address' => __( 'Address', 'tradewell-leads' ),
		'service' => __( 'Service', 'tradewell-leads' ),
		'size'    => __( 'Size', 'tradewell-leads' ),
		'urgency' => __( 'Urgency', 'tradewell-leads' ),
		'date'    => __( 'Preferred day', 'tradewell-leads' ),
		'window'  => __( 'Time window', 'tradewell-leads' ),
		'notes'   => __( 'Notes', 'tradewell-leads' ),
		'page'    => __( 'Submitted from', 'tradewell-leads' ),
	);
	echo '<table class="widefat striped"><tbody>';
	foreach ( $fields as $key => $label ) {
		$value = get_post_meta( $post->ID, '_twl_' . $key, true );
		if ( 'type' === $key ) {
			$value = isset( $types[ $value ] ) ? $types[ $value ] : $value;
		}
		if ( '' === (string) $value ) {
			continue;
		}
		echo '<tr><th style="width:160px">' . esc_html( $label ) . '</th><td>';
		if ( 'phone' === $key ) {
			printf( '<a href="tel:%1$s">%2$s</a>', esc_attr( twleads_tel( $value ) ), esc_html( $value ) );
		} elseif ( 'email' === $key ) {
			printf( '<a href="mailto:%1$s">%1$s</a>', esc_attr( $value ) );
		} elseif ( 'page' === $key ) {
			printf( '<a href="%1$s" target="_blank" rel="noopener">%1$s</a>', esc_url( $value ) );
		} else {
			echo nl2br( esc_html( $value ) );
		}
		echo '</td></tr>';
	}
	$est = twleads_format_estimate(
		array(
			'est_low'  => (float) get_post_meta( $post->ID, '_twl_est_low', true ),
			'est_high' => (float) get_post_meta( $post->ID, '_twl_est_high', true ),
		)
	);
	if ( $est ) {
		echo '<tr><th>' . esc_html__( 'Estimate shown', 'tradewell-leads' ) . '</th><td><strong>' . esc_html( $est ) . '</strong></td></tr>';
	}
	echo '</tbody></table>';
}

/**
 * Render status selector.
 *
 * @param WP_Post $post Post.
 */
function twleads_render_lead_status( $post ) {
	wp_nonce_field( 'twleads_lead_status', 'twleads_lead_status_nonce' );
	$current = get_post_meta( $post->ID, '_twl_status', true );
	echo '<select name="twleads_status_field" style="width:100%">';
	foreach ( twleads_lead_statuses() as $key => $label ) {
		printf( '<option value="%1$s" %2$s>%3$s</option>', esc_attr( $key ), selected( $current, $key, false ), esc_html( $label ) );
	}
	echo '</select>';
	echo '<p class="description">' . esc_html__( 'Click Update to save.', 'tradewell-leads' ) . '</p>';
}

/**
 * Save status.
 *
 * @param int $post_id Post.
 */
function twleads_save_lead_status( $post_id ) {
	if ( ! isset( $_POST['twleads_lead_status_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['twleads_lead_status_nonce'] ) ), 'twleads_lead_status' ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$status = isset( $_POST['twleads_status_field'] ) ? sanitize_key( $_POST['twleads_status_field'] ) : 'new';
	if ( array_key_exists( $status, twleads_lead_statuses() ) ) {
		update_post_meta( $post_id, '_twl_status', $status );
	}
}
add_action( 'save_post_twleads_lead', 'twleads_save_lead_status' );

/**
 * Show new-lead count on the menu.
 */
function twleads_menu_badge() {
	global $menu;
	$count = (int) get_transient( 'twleads_new_count' );
	if ( false === get_transient( 'twleads_new_count' ) ) {
		$q     = new WP_Query(
			array(
				'post_type'   => 'twleads_lead',
				'post_status' => 'publish',
				'meta_key'    => '_twl_status', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'meta_value'      => 'new', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			'fields'          => 'ids',
			'posts_per_page'  => 1,
			)
		);
		$count = (int) $q->found_posts;
		set_transient( 'twleads_new_count', $count, 5 * MINUTE_IN_SECONDS );
	}
	if ( ! $count || ! is_array( $menu ) ) {
		return;
	}
	foreach ( $menu as $i => $item ) {
		if ( isset( $item[2] ) && 'edit.php?post_type=twleads_lead' === $item[2] ) {
			$menu[ $i ][0] .= ' <span class="awaiting-mod"><span class="pending-count">' . absint( $count ) . '</span></span>'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		}
	}
}
add_action( 'admin_menu', 'twleads_menu_badge', 99 );

/**
 * Reset badge cache.
 */
function twleads_reset_badge() {
	delete_transient( 'twleads_new_count' );
}
add_action( 'twleads_lead_created', 'twleads_reset_badge' );
add_action( 'save_post_twleads_lead', 'twleads_reset_badge', 20 );

/**
 * Admin badge styles.
 */
function twleads_admin_styles() {
	$screen = get_current_screen();
	if ( ! $screen || 'twleads_lead' !== $screen->post_type ) {
		return;
	}
	echo '<style>.twl-badge{display:inline-block;padding:2px 8px;border-radius:99px;font-size:12px;font-weight:600;background:#e5e7eb;color:#111}.twl-badge--new{background:#fde68a}.twl-badge--contacted{background:#bfdbfe}.twl-badge--booked{background:#c7d2fe}.twl-badge--won{background:#bbf7d0}.twl-badge--lost{background:#fecaca}</style>';
}
add_action( 'admin_head', 'twleads_admin_styles' );
