<?php
/**
 * REST endpoints used by the front-end forms.
 *
 * POST /twl/v1/leads        Submit a lead.
 * GET  /twl/v1/areas?zip=   Check whether a ZIP is served.
 *
 * No nonce is required so forms keep working behind page caches; requests
 * are protected by a signed timestamp token, a honeypot and a rate limit.
 *
 * @package TradewellLeads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register routes.
 */
function twleads_register_routes() {
	register_rest_route(
		'twl/v1',
		'/leads',
		array(
			'methods'             => WP_REST_Server::CREATABLE,
			'permission_callback' => '__return_true',
			'callback'            => 'twleads_rest_create_lead',
		)
	);
	register_rest_route(
		'twl/v1',
		'/areas',
		array(
			'methods'             => WP_REST_Server::READABLE,
			'permission_callback' => '__return_true',
			'callback'            => 'twleads_rest_check_area',
			'args'                => array(
				'zip' => array(
					'required'          => true,
					'sanitize_callback' => 'sanitize_text_field',
				),
			),
		)
	);
}
add_action( 'rest_api_init', 'twleads_register_routes' );

/**
 * Create lead.
 *
 * @param WP_REST_Request $request Request.
 * @return WP_REST_Response|WP_Error
 */
function twleads_rest_create_lead( WP_REST_Request $request ) {
	$params = $request->get_json_params();
	if ( empty( $params ) ) {
		$params = $request->get_body_params();
	}
	$result = twleads_create_lead( is_array( $params ) ? $params : array() );
	if ( is_wp_error( $result ) ) {
		return $result;
	}
	return rest_ensure_response(
		array(
			'ok'      => true,
			'message' => twleads_get( 'success_msg' ),
		)
	);
}

/**
 * Check a ZIP.
 *
 * @param WP_REST_Request $request Request.
 * @return WP_REST_Response
 */
function twleads_rest_check_area( WP_REST_Request $request ) {
	$zip = strtoupper( trim( (string) $request->get_param( 'zip' ), " \t\n\r\0\x0B" ) );
	$map = twleads_zip_map();
	if ( ! isset( $map[ $zip ] ) ) {
		return rest_ensure_response(
			array(
				'served' => false,
				'zip'    => $zip,
			)
		);
	}
	$area = null;
	if ( $map[ $zip ] ) {
		$area = array(
			'title' => get_the_title( $map[ $zip ] ),
			'url'   => get_permalink( $map[ $zip ] ),
		);
	}
	return rest_ensure_response(
		array(
			'served' => true,
			'zip'    => $zip,
			'area'   => $area,
		)
	);
}
