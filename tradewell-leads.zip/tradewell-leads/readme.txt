=== Tradewell Leads ===
Contributors: tradewellthemes
Requires at least: 6.6
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 2.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Lead capture for home-service websites: instant quote calculator, booking form, service areas, click-to-call bar and a leads inbox.

== Description ==

Blocks:

* Quote calculator: visitors pick a service, set a size (sq ft, tons, kW) and urgency, and see a price range instantly, then leave their details to lock it in. Services and prices are edited in the block sidebar.
* Booking form: day picker (skips your closed days), arrival windows, contact details.
* Service area checker: ZIP lookup with a waitlist form for areas you do not cover.
* Service area list: links to every Service Area page (good for local SEO).
* Phone button: tap-to-call using the number in settings.

Also included:

* Setup wizard (Leads > Setup wizard): six one-click starter sites with trade-specific pages, menus, colors, calculator prices and booking options. Removable with one click.

* Leads inbox (Leads menu) with status tracking, CSV export and a "new" counter.
* Email notification for every lead, plus optional webhook (Zapier, Make, any CRM).
* Service Areas post type at /service-areas/ with ZIP codes per area.
* Mobile click-to-call bar.
* LocalBusiness (HomeAndConstructionBusiness) structured data on the homepage and area pages. Disable with the twleads_output_schema filter if your SEO plugin already outputs it.
* Spam protection without CAPTCHAs: signed time token, honeypot and per-visitor rate limit. Works behind full-page caches.
* Forms work with JavaScript disabled.
* Privacy tools: personal data export and erasure, suggested privacy policy text.
* Analytics events pushed to dataLayer: tradewell_lead, tradewell_call, tradewell_quote_step, tradewell_area_check.

Developer hooks: twleads_lead_created (action), twleads_lead_errors, twleads_webhook_payload, twleads_rate_limit, twleads_show_callbar, twleads_schema, twleads_output_schema (filters).

== Changelog ==

= 2.0.0 =
* New: setup wizard with six trade starter sites.
* New: heading level option for form blocks.
* Improved: coding standards (WordPress-Extra), HTML validity, accessibility.
* Changed: PHP prefix twl_ is now twleads_; analytics events are now tradewell_*.

= 1.0.0 =
* Initial release.
