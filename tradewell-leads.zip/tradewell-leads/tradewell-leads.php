<?php
/**
 * Plugin Name:       Tradewell Leads
 * Plugin URI:        https://example.com/tradewell
 * Description:       Lead capture for home-service websites: instant quote calculator, booking form, service-area pages with ZIP checker, click-to-call bar and a leads inbox with CSV export and webhook.
 * Version:           2.0.0
 * Requires at least: 6.6
 * Requires PHP:      7.4
 * Author:            Tradewell Themes
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       tradewell-leads
 *
 * @package TradewellLeads
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TWLEADS_VERSION', '2.0.0' );
define( 'TWLEADS_FILE', __FILE__ );
define( 'TWLEADS_PATH', plugin_dir_path( __FILE__ ) );
define( 'TWLEADS_URL', plugin_dir_url( __FILE__ ) );

require_once TWLEADS_PATH . 'includes/helpers.php';
require_once TWLEADS_PATH . 'includes/settings.php';
require_once TWLEADS_PATH . 'includes/post-types.php';
require_once TWLEADS_PATH . 'includes/leads.php';
require_once TWLEADS_PATH . 'includes/leads-admin.php';
require_once TWLEADS_PATH . 'includes/rest.php';
require_once TWLEADS_PATH . 'includes/blocks.php';
require_once TWLEADS_PATH . 'includes/patterns.php';
require_once TWLEADS_PATH . 'includes/frontend.php';
require_once TWLEADS_PATH . 'includes/privacy.php';
require_once TWLEADS_PATH . 'includes/demo-data.php';
require_once TWLEADS_PATH . 'includes/setup.php';

/**
 * Load translations.
 */
function twleads_load_textdomain() {
	load_plugin_textdomain( 'tradewell-leads', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}
add_action( 'init', 'twleads_load_textdomain' );

/**
 * Activation: register post types then flush rewrite rules so /service-areas/ works.
 */
function twleads_activate() {
	twleads_register_post_types();
	flush_rewrite_rules();
	set_transient( 'twleads_activation_redirect', 1, 60 );
}
register_activation_hook( __FILE__, 'twleads_activate' );

/**
 * Deactivation: clean rewrite rules. Data is kept.
 */
function twleads_deactivate() {
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'twleads_deactivate' );
