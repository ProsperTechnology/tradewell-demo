/**
 * Tradewell Leads editor UI. Plain JS (no build step): server-rendered previews
 * with sidebar controls.
 */
( function ( wp ) {
	'use strict';

	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var __ = wp.i18n.__;
	var be = wp.blockEditor;
	var c = wp.components;
	var SSR = wp.serverSideRender;

	function preview( name, props ) {
		return el( 'div', be.useBlockProps(),
			el( c.Disabled, null, el( SSR, { block: name, attributes: props.attributes } ) )
		);
	}

	function text( props, key, label, multiline ) {
		var Ctrl = multiline ? c.TextareaControl : c.TextControl;
		return el( Ctrl, {
			label: label,
			value: props.attributes[ key ] || '',
			__nextHasNoMarginBottom: true,
			onChange: function ( v ) { var o = {}; o[ key ] = v; props.setAttributes( o ); }
		} );
	}

	function headingCtrl( props ) {
		return el( c.SelectControl, {
			label: __( 'Heading level', 'tradewell-leads' ),
			value: String( props.attributes.headingLevel || 3 ),
			options: [ 2, 3, 4 ].map( function ( n ) { return { value: String( n ), label: 'H' + n }; } ),
			__nextHasNoMarginBottom: true,
			onChange: function ( v ) { props.setAttributes( { headingLevel: Number( v ) } ); }
		} );
	}

	/* ---------- Quote calculator ---------- */

	function serviceEditor( props ) {
		var services = props.attributes.services || [];
		function update( i, key, value ) {
			var next = services.map( function ( s, j ) {
				if ( j !== i ) { return s; }
				var copy = Object.assign( {}, s );
				copy[ key ] = value;
				return copy;
			} );
			props.setAttributes( { services: next } );
		}
		function num( i, key, label, help ) {
			return el( c.TextControl, {
				type: 'number',
				label: label,
				help: help,
				value: services[ i ][ key ],
				__nextHasNoMarginBottom: true,
				onChange: function ( v ) { update( i, key, v === '' ? 0 : Number( v ) ); }
			} );
		}
		function move( i, dir ) {
			var next = services.slice();
			var j = i + dir;
			if ( j < 0 || j >= next.length ) { return; }
			var t = next[ i ]; next[ i ] = next[ j ]; next[ j ] = t;
			props.setAttributes( { services: next } );
		}
		var panels = services.map( function ( s, i ) {
			return el( c.PanelBody, { key: i, title: s.label || __( '(untitled service)', 'tradewell-leads' ), initialOpen: false },
				el( c.TextControl, { label: __( 'Service name', 'tradewell-leads' ), value: s.label, __nextHasNoMarginBottom: true, onChange: function ( v ) { update( i, 'label', v ); } } ),
				num( i, 'base', __( 'Base price', 'tradewell-leads' ), __( 'Typical price, or the fixed part when priced by size.', 'tradewell-leads' ) ),
				el( c.TextControl, { label: __( 'Size unit (optional)', 'tradewell-leads' ), help: __( 'e.g. sq ft, tons, kW. Leave empty for a flat price.', 'tradewell-leads' ), value: s.unit, __nextHasNoMarginBottom: true, onChange: function ( v ) { update( i, 'unit', v ); } } ),
				s.unit ? el( Fragment, null,
					num( i, 'unitPrice', __( 'Price per unit', 'tradewell-leads' ) ),
					num( i, 'min', __( 'Minimum size', 'tradewell-leads' ) ),
					num( i, 'max', __( 'Maximum size', 'tradewell-leads' ) ),
					num( i, 'step', __( 'Slider step', 'tradewell-leads' ) ),
					num( i, 'def', __( 'Starting size', 'tradewell-leads' ) )
				) : null,
				el( c.Flex, { justify: 'flex-start', style: { marginTop: 12 } },
					el( c.Button, { variant: 'secondary', size: 'small', disabled: i === 0, onClick: function () { move( i, -1 ); } }, __( 'Move up', 'tradewell-leads' ) ),
					el( c.Button, { variant: 'secondary', size: 'small', disabled: i === services.length - 1, onClick: function () { move( i, 1 ); } }, __( 'Move down', 'tradewell-leads' ) ),
					el( c.Button, { variant: 'tertiary', isDestructive: true, size: 'small', onClick: function () {
						props.setAttributes( { services: services.filter( function ( x, j ) { return j !== i; } ) } );
					} }, __( 'Remove', 'tradewell-leads' ) )
				)
			);
		} );
		panels.push( el( c.PanelBody, { key: 'add', title: __( 'Add a service', 'tradewell-leads' ), initialOpen: false },
			el( c.Button, { variant: 'primary', onClick: function () {
				props.setAttributes( { services: services.concat( [ { label: __( 'New service', 'tradewell-leads' ), base: 200, unit: '', unitPrice: 0, min: 0, max: 0, step: 1, def: 0 } ] ) } );
			} }, __( 'Add service', 'tradewell-leads' ) )
		) );
		return panels;
	}

	wp.blocks.registerBlockType( 'twl/quote-calculator', {
		edit: function ( props ) {
			return el( Fragment, null,
				el( be.InspectorControls, null,
					el( c.PanelBody, { title: __( 'Text', 'tradewell-leads' ) },
						text( props, 'heading', __( 'Heading', 'tradewell-leads' ) ),
						headingCtrl( props ),
						text( props, 'intro', __( 'Intro', 'tradewell-leads' ), true ),
						text( props, 'buttonText', __( 'Submit button', 'tradewell-leads' ) ),
						text( props, 'disclaimer', __( 'Disclaimer under price', 'tradewell-leads' ), true )
					),
					el( c.PanelBody, { title: __( 'Pricing', 'tradewell-leads' ) },
						el( c.RangeControl, {
							label: __( 'Range spread (+/- %)', 'tradewell-leads' ),
							help: __( 'How wide the estimate range is around the calculated price.', 'tradewell-leads' ),
							min: 0, max: 50, value: props.attributes.spread,
							onChange: function ( v ) { props.setAttributes( { spread: v } ); }
						} ),
						el( c.ToggleControl, {
							label: __( 'Ask how soon (adds next-day and emergency pricing)', 'tradewell-leads' ),
							checked: props.attributes.showUrgency,
							__nextHasNoMarginBottom: true,
							onChange: function ( v ) { props.setAttributes( { showUrgency: v } ); }
						} )
					),
					serviceEditor( props )
				),
				preview( 'twl/quote-calculator', props )
			);
		},
		save: function () { return null; }
	} );

	/* ---------- Booking ---------- */

	var DAYS = [ __( 'Sun', 'tradewell-leads' ), __( 'Mon', 'tradewell-leads' ), __( 'Tue', 'tradewell-leads' ), __( 'Wed', 'tradewell-leads' ), __( 'Thu', 'tradewell-leads' ), __( 'Fri', 'tradewell-leads' ), __( 'Sat', 'tradewell-leads' ) ];

	wp.blocks.registerBlockType( 'twl/booking-form', {
		edit: function ( props ) {
			var closed = props.attributes.closedDays || [];
			return el( Fragment, null,
				el( be.InspectorControls, null,
					el( c.PanelBody, { title: __( 'Text', 'tradewell-leads' ) },
						text( props, 'heading', __( 'Heading', 'tradewell-leads' ) ),
						headingCtrl( props ),
						text( props, 'intro', __( 'Intro', 'tradewell-leads' ), true ),
						text( props, 'buttonText', __( 'Submit button', 'tradewell-leads' ) )
					),
					el( c.PanelBody, { title: __( 'Scheduling', 'tradewell-leads' ) },
						text( props, 'services', __( 'Services (one per line)', 'tradewell-leads' ), true ),
						text( props, 'windows', __( 'Arrival windows (one per line)', 'tradewell-leads' ), true ),
						el( c.RangeControl, { label: __( 'Days to offer', 'tradewell-leads' ), min: 1, max: 30, value: props.attributes.daysAhead, onChange: function ( v ) { props.setAttributes( { daysAhead: v } ); } } ),
						el( 'p', null, el( 'strong', null, __( 'Closed on', 'tradewell-leads' ) ) ),
						DAYS.map( function ( label, d ) {
							return el( c.CheckboxControl, {
								key: d, label: label, checked: closed.indexOf( d ) > -1,
								__nextHasNoMarginBottom: true,
								onChange: function ( on ) {
									var next = closed.filter( function ( x ) { return x !== d; } );
									if ( on ) { next.push( d ); }
									props.setAttributes( { closedDays: next } );
								}
							} );
						} )
					)
				),
				preview( 'twl/booking-form', props )
			);
		},
		save: function () { return null; }
	} );

	/* ---------- Area checker ---------- */

	wp.blocks.registerBlockType( 'twl/area-checker', {
		edit: function ( props ) {
			return el( Fragment, null,
				el( be.InspectorControls, null,
					el( c.PanelBody, { title: __( 'Text', 'tradewell-leads' ) },
						text( props, 'heading', __( 'Heading', 'tradewell-leads' ) ),
						headingCtrl( props ),
						text( props, 'placeholder', __( 'Placeholder', 'tradewell-leads' ) ),
						text( props, 'buttonText', __( 'Button', 'tradewell-leads' ) ),
						el( 'p', { className: 'description' }, __( 'ZIP codes come from your Service Area pages and Leads > Settings.', 'tradewell-leads' ) )
					)
				),
				preview( 'twl/area-checker', props )
			);
		},
		save: function () { return null; }
	} );

	/* ---------- Area list ---------- */

	wp.blocks.registerBlockType( 'twl/service-areas', {
		edit: function ( props ) {
			return el( Fragment, null,
				el( be.InspectorControls, null,
					el( c.PanelBody, { title: __( 'Layout', 'tradewell-leads' ) },
						el( c.RangeControl, { label: __( 'Columns', 'tradewell-leads' ), min: 1, max: 6, value: props.attributes.columns, onChange: function ( v ) { props.setAttributes( { columns: v } ); } } ),
						el( c.ToggleControl, { label: __( 'Show ZIP codes', 'tradewell-leads' ), checked: props.attributes.showZips, __nextHasNoMarginBottom: true, onChange: function ( v ) { props.setAttributes( { showZips: v } ); } } )
					)
				),
				preview( 'twl/service-areas', props )
			);
		},
		save: function () { return null; }
	} );

	/* ---------- Phone ---------- */

	wp.blocks.registerBlockType( 'twl/phone', {
		edit: function ( props ) {
			return el( Fragment, null,
				el( be.InspectorControls, null,
					el( c.PanelBody, { title: __( 'Phone button', 'tradewell-leads' ) },
						el( c.SelectControl, {
							label: __( 'Style', 'tradewell-leads' ),
							value: props.attributes.variant,
							__nextHasNoMarginBottom: true,
							options: [
								{ value: 'button', label: __( 'Filled button', 'tradewell-leads' ) },
								{ value: 'outline', label: __( 'Outline button', 'tradewell-leads' ) },
								{ value: 'dark', label: __( 'Dark button', 'tradewell-leads' ) },
								{ value: 'text', label: __( 'Text link', 'tradewell-leads' ) }
							],
							onChange: function ( v ) { props.setAttributes( { variant: v } ); }
						} ),
						text( props, 'label', __( 'Label before number (optional)', 'tradewell-leads' ) ),
						el( 'p', { className: 'description' }, __( 'The number is set in Leads > Settings.', 'tradewell-leads' ) )
					)
				),
				preview( 'twl/phone', props )
			);
		},
		save: function () { return null; }
	} );
}( window.wp ) );
