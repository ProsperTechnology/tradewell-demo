/**
 * Tradewell Leads front-end. Vanilla JS, no dependencies.
 * Progressive enhancement: every form also works without JavaScript.
 */
( function () {
	'use strict';

	var $ = function ( sel, ctx ) { return ( ctx || document ).querySelector( sel ); };
	var $$ = function ( sel, ctx ) { return Array.prototype.slice.call( ( ctx || document ).querySelectorAll( sel ) ); };

	function track( event, detail ) {
		if ( window.dataLayer && typeof window.dataLayer.push === 'function' ) {
			window.dataLayer.push( Object.assign( { event: event }, detail || {} ) );
		}
		document.dispatchEvent( new CustomEvent( event, { detail: detail || {} } ) );
	}

	var STR = window.twlI18n || {};
	function t( key, fallback ) { return STR[ key ] || fallback; }

	function json( el, attr ) {
		try { return JSON.parse( el.getAttribute( attr ) || '{}' ); } catch ( e ) { return {}; }
	}

	function money( n, cur ) {
		return cur + Math.round( n ).toLocaleString();
	}

	function nice( n ) {
		var step = n < 1000 ? 10 : ( n < 10000 ? 50 : 100 );
		return Math.max( step, Math.round( n / step ) * step );
	}

	/* ---------- Validation & submit ---------- */

	function setError( form, name, msg ) {
		var input = form.elements[ name ];
		var field = input && input.closest ? input.closest( '.twl-field' ) : null;
		var slot = field ? $( '.twl-error', field ) : $( '.twl-error[data-for="' + name + '"]', form );
		if ( slot ) { slot.textContent = msg || ''; }
		if ( input && input.setAttribute && ! input.length ) {
			if ( msg ) { input.setAttribute( 'aria-invalid', 'true' ); } else { input.removeAttribute( 'aria-invalid' ); }
		}
	}

	function clearErrors( form ) {
		$$( '.twl-error', form ).forEach( function ( s ) { s.textContent = ''; } );
		$$( '[aria-invalid]', form ).forEach( function ( i ) { i.removeAttribute( 'aria-invalid' ); } );
	}

	function validate( form ) {
		var errors = {};
		var data = new FormData( form );
		var name = ( data.get( 'name' ) || '' ).trim();
		var phone = ( data.get( 'phone' ) || '' ).replace( /\D/g, '' );
		var email = ( data.get( 'email' ) || '' ).trim();
		if ( form.elements.name && ! name ) { errors.name = t( 'name', 'Please enter your name.' ); }
		if ( form.elements.phone && ( phone.length < 7 || phone.length > 15 ) ) { errors.phone = t( 'phone', 'Please enter a valid phone number.' ); }
		if ( email && ! /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test( email ) ) { errors.email = t( 'email', 'Please check your email address.' ); }
		if ( data.get( 'type' ) === 'booking' && ! data.get( 'date' ) ) { errors.date = t( 'date', 'Please choose a day.' ); }
		return errors;
	}

	function showErrors( form, errors ) {
		var first = null;
		Object.keys( errors ).forEach( function ( k ) {
			setError( form, k, errors[ k ] );
			if ( ! first && form.elements[ k ] && form.elements[ k ].focus ) { first = form.elements[ k ]; }
		} );
		if ( first ) { first.focus(); }
	}

	function success( form, message ) {
		var done = document.createElement( 'div' );
		done.className = 'twl-done';
		done.setAttribute( 'tabindex', '-1' );
		done.innerHTML = '<svg class="twl-ico" viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
		var p = document.createElement( 'p' );
		p.textContent = message;
		done.appendChild( p );
		form.parentNode.replaceChild( done, form );
		done.focus();
	}

	function bindSubmit( form ) {
		var page = form.elements.page;
		if ( page ) { page.value = window.location.href; }

		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			clearErrors( form );
			var status = $( '.twl-status', form );
			var errors = validate( form );
			if ( Object.keys( errors ).length ) { showErrors( form, errors ); return; }

			var btn = $( 'button[type="submit"]', form );
			var label = btn ? btn.textContent : '';
			if ( btn ) { btn.disabled = true; btn.textContent = t( 'sending', 'Sending…' ); }
			if ( status ) { status.textContent = ''; status.classList.remove( 'is-error' ); }

			var payload = {};
			new FormData( form ).forEach( function ( v, k ) { payload[ k ] = v; } );

			fetch( form.getAttribute( 'data-endpoint' ), {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify( payload ),
				credentials: 'same-origin'
			} ).then( function ( r ) {
				return r.json().then( function ( body ) { return { ok: r.ok, body: body }; } );
			} ).then( function ( res ) {
				if ( res.ok && res.body && res.body.ok ) {
					track( 'tradewell_lead', { lead_type: payload.type, service: payload.service || '', value: Number( payload.est_high ) || 0 } );
					success( form, res.body.message );
					return;
				}
				var fields = res.body && res.body.data && res.body.data.fields;
				if ( fields ) { showErrors( form, fields ); }
				if ( status ) {
					status.textContent = ( res.body && res.body.message ) || t( 'error', 'Something went wrong. Please call us instead.' );
					status.classList.add( 'is-error' );
				}
			} ).catch( function () {
				if ( status ) {
					status.textContent = t( 'offline', 'Connection problem. Please try again or call us.' );
					status.classList.add( 'is-error' );
				}
			} ).then( function () {
				if ( btn && btn.isConnected ) { btn.disabled = false; btn.textContent = label; }
			} );
		} );
	}

	/* ---------- Quote calculator ---------- */

	function initQuote( form ) {
		var cfg = json( form, 'data-config' );
		var services = cfg.services || [];
		var step1 = $( '[data-step="1"]', form );
		var step2 = $( '[data-step="2"]', form );
		var sizeWrap = $( '.twl-size', form );
		var range = $( 'input[type="range"]', form );
		var out = $( '.twl-size-out', form );
		var sizeLabel = $( '.twl-size-label', form );
		var valueEl = $( '.twl-estimate-value', form );
		var next = $( '.twl-next', form );
		var back = $( '.twl-back', form );
		var recap = $( '.twl-recap', form );
		var current = null;
		var est = null;

		step2.hidden = true;
		next.hidden = false;
		back.hidden = false;

		function compute() {
			if ( ! current ) { return; }
			var units = current.unit ? Number( range.value ) : 0;
			var urgency = form.elements.urgency ? ( $( 'input[name="urgency"]:checked', form ) || {} ).value : 'standard';
			var mult = ( cfg.urgency && cfg.urgency[ urgency ] ) || 1;
			var mid = ( current.base + units * current.unitPrice ) * mult;
			var low = nice( mid * ( 1 - cfg.spread ) );
			var high = nice( mid * ( 1 + cfg.spread ) );
			est = { low: low, high: high };
			valueEl.textContent = money( low, cfg.currency ) + ' – ' + money( high, cfg.currency );
			valueEl.classList.add( 'has-price' );
			form.elements.est_low.value = low;
			form.elements.est_high.value = high;
			if ( current.unit ) { out.textContent = Number( range.value ).toLocaleString() + ' ' + current.unit; }
			next.disabled = false;
		}

		$$( 'input[name="service"]', form ).forEach( function ( radio ) {
			radio.addEventListener( 'change', function () {
				current = services[ Number( radio.getAttribute( 'data-i' ) ) ] || null;
				if ( current && current.unit && current.max > current.min ) {
					range.min = current.min;
					range.max = current.max;
					range.step = current.step || 1;
					range.value = current.def || current.min;
					sizeLabel.textContent = current.unit.charAt( 0 ).toUpperCase() + current.unit.slice( 1 );
					sizeWrap.hidden = false;
				} else {
					sizeWrap.hidden = true;
					range.value = 0;
				}
				compute();
			} );
		} );
		range.addEventListener( 'input', compute );
		$$( 'input[name="urgency"]', form ).forEach( function ( r ) { r.addEventListener( 'change', compute ); } );

		next.addEventListener( 'click', function () {
			if ( ! current || ! est ) { return; }
			recap.innerHTML = '';
			var t = document.createElement( 'span' );
			t.textContent = ( cfg.i18n && cfg.i18n.recap ? cfg.i18n.recap.replace( '%s', current.label ) : current.label ) + ' ';
			var b = document.createElement( 'strong' );
			b.textContent = money( est.low, cfg.currency ) + ' – ' + money( est.high, cfg.currency );
			recap.appendChild( t );
			recap.appendChild( b );
			recap.hidden = false;
			step1.hidden = true;
			step2.hidden = false;
			track( 'tradewell_quote_step', { service: current.label } );
			var first = $( 'input[name="name"]', step2 );
			if ( first ) { first.focus(); }
		} );

		back.addEventListener( 'click', function () {
			step2.hidden = true;
			step1.hidden = false;
			var checked = $( 'input[name="service"]:checked', form );
			if ( checked ) { checked.focus(); }
		} );
	}

	/* ---------- Booking day picker ---------- */

	function pad( n ) { return ( n < 10 ? '0' : '' ) + n; }

	function initBooking( form ) {
		var cfg = json( form, 'data-booking' );
		var wrap = $( '.twl-days', form );
		var fallback = $( '.twl-date-fallback', form );
		if ( ! wrap ) { return; }
		var closed = cfg.closed || [];
		var locale = cfg.locale || undefined;
		var day = new Date();
		if ( day.getHours() >= 15 ) { day.setDate( day.getDate() + 1 ); }
		var made = 0;
		var guard = 0;
		while ( made < ( cfg.days || 10 ) && guard < 90 ) {
			guard++;
			if ( closed.indexOf( day.getDay() ) === -1 ) {
				var value = day.getFullYear() + '-' + pad( day.getMonth() + 1 ) + '-' + pad( day.getDate() );
				var label = document.createElement( 'label' );
				label.className = 'twl-chip twl-day';
				var input = document.createElement( 'input' );
				input.type = 'radio';
				input.name = 'date';
				input.value = value;
				if ( made === 0 ) { input.checked = true; }
				var span = document.createElement( 'span' );
				var wd = document.createElement( 'small' );
				wd.textContent = day.toLocaleDateString( locale, { weekday: 'short' } );
				var dm = document.createElement( 'b' );
				dm.textContent = day.toLocaleDateString( locale, { month: 'short', day: 'numeric' } );
				span.appendChild( wd );
				span.appendChild( dm );
				label.appendChild( input );
				label.appendChild( span );
				wrap.appendChild( label );
				made++;
			}
			day.setDate( day.getDate() + 1 );
		}
		if ( fallback ) { fallback.parentNode.removeChild( fallback ); }
	}

	/* ---------- Service area checker ---------- */

	function initArea( root ) {
		var cfg = json( root, 'data-area' );
		var form = $( '.twl-area-form', root );
		var result = $( '.twl-area-result', root );
		var wait = $( '.twl-area-waitlist', root );
		var i18n = cfg.i18n || {};
		form.addEventListener( 'submit', function ( e ) {
			e.preventDefault();
			var zip = ( form.elements.zip.value || '' ).trim().toUpperCase();
			result.innerHTML = '';
			if ( wait ) { wait.hidden = true; }
			if ( ! /^[A-Z0-9 -]{3,10}$/.test( zip ) ) {
				result.innerHTML = '<p class="is-no"></p>';
				result.firstChild.textContent = i18n.bad;
				return;
			}
			var url = cfg.endpoint + ( cfg.endpoint.indexOf( '?' ) > -1 ? '&' : '?' ) + 'zip=' + encodeURIComponent( zip );
			fetch( url, { credentials: 'same-origin' } ).then( function ( r ) { return r.json(); } ).then( function ( res ) {
				var p = document.createElement( 'p' );
				if ( res.served ) {
					p.className = 'is-yes';
					p.textContent = res.area ? i18n.yesArea.replace( '%s', res.area.title ) : i18n.yes;
					result.appendChild( p );
					var links = document.createElement( 'p' );
					links.className = 'twl-area-links';
					var q = document.createElement( 'a' );
					q.href = cfg.quote || '#quote';
					q.className = 'twl-btn wp-element-button';
					q.textContent = i18n.quote;
					links.appendChild( q );
					if ( res.area ) {
						var a = document.createElement( 'a' );
						a.href = res.area.url;
						a.textContent = i18n.see + ' →';
						links.appendChild( a );
					}
					result.appendChild( links );
					track( 'tradewell_area_check', { served: true, zip: zip } );
				} else {
					p.className = 'is-no';
					p.textContent = i18n.no.replace( '%s', zip );
					result.appendChild( p );
					if ( wait ) {
						wait.hidden = false;
						var hidden = $( 'input[name="zip"]', wait );
						if ( hidden ) { hidden.value = zip; }
					}
					track( 'tradewell_area_check', { served: false, zip: zip } );
				}
			} );
		} );
	}

	/* ---------- Boot ---------- */

	function boot() {
		$$( '.twl-form' ).forEach( function ( form ) {
			if ( form.hasAttribute( 'data-config' ) ) { initQuote( form ); }
			if ( form.hasAttribute( 'data-booking' ) ) { initBooking( form ); }
			bindSubmit( form );
		} );
		$$( '.twl-area[data-area]' ).forEach( initArea );
		document.addEventListener( 'click', function ( e ) {
			var link = e.target.closest && e.target.closest( 'a[href^="tel:"]' );
			if ( link ) { track( 'tradewell_call', { from: link.className || 'link' } ); }
		} );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', boot );
	} else {
		boot();
	}
}() );
