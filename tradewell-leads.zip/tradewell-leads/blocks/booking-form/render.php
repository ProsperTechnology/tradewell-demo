<?php
/**
 * Booking form render.
 *
 * @package TradewellLeads
 * @var array $attributes Block attributes.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$twleads_h = max( 2, min( 6, (int) ( $attributes['headingLevel'] ?? 3 ) ) );

$twleads_lines    = function ( $text ) {
	return array_values( array_filter( array_map( 'trim', explode( "\n", (string) $text ) ) ) );
};
$twleads_services = $twleads_lines( $attributes['services'] );
$twleads_windows  = $twleads_lines( $attributes['windows'] );
$twleads_config   = array(
	'days'   => max( 1, min( 60, (int) $attributes['daysAhead'] ) ),
	'closed' => array_map( 'intval', (array) $attributes['closedDays'] ),
	'locale' => str_replace( '_', '-', get_locale() ),
);
$twleads_wrapper  = get_block_wrapper_attributes( array( 'class' => 'twl twl-booking' ) );
?>
<div <?php echo $twleads_wrapper; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<div class="twl-head">
		<h<?php echo (int) $twleads_h; ?> class="twl-title"><?php echo esc_html( $attributes['heading'] ); ?></h<?php echo (int) $twleads_h; ?>>
		<?php if ( $attributes['intro'] ) : ?>
			<p class="twl-intro"><?php echo esc_html( $attributes['intro'] ); ?></p>
		<?php endif; ?>
	</div>
	<?php echo twleads_fallback_notice(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	<?php echo twleads_form_open( 'booking', array( 'data-booking' => wp_json_encode( $twleads_config ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<?php if ( $twleads_services ) : ?>
			<fieldset class="twl-fieldset">
				<legend><?php esc_html_e( 'What is it for?', 'tradewell-leads' ); ?></legend>
				<div class="twl-chips twl-chips--row">
					<?php foreach ( $twleads_services as $twleads_i => $twleads_s ) : ?>
						<label class="twl-chip"><input type="radio" name="service" value="<?php echo esc_attr( $twleads_s ); ?>" <?php checked( 0, $twleads_i ); ?>><span><?php echo esc_html( $twleads_s ); ?></span></label>
					<?php endforeach; ?>
				</div>
			</fieldset>
		<?php endif; ?>
		<fieldset class="twl-fieldset">
			<legend><?php esc_html_e( 'Pick a day', 'tradewell-leads' ); ?></legend>
			<div class="twl-days"></div>
			<input class="twl-date-fallback" type="date" name="date" min="<?php echo esc_attr( wp_date( 'Y-m-d' ) ); ?>" aria-label="<?php esc_attr_e( 'Preferred day', 'tradewell-leads' ); ?>">
			<span class="twl-error" role="alert" data-for="date"></span>
		</fieldset>
		<?php if ( $twleads_windows ) : ?>
			<fieldset class="twl-fieldset">
				<legend><?php esc_html_e( 'Arrival window', 'tradewell-leads' ); ?></legend>
				<div class="twl-chips twl-chips--row">
					<?php foreach ( $twleads_windows as $twleads_i => $twleads_w ) : ?>
						<label class="twl-chip"><input type="radio" name="window" value="<?php echo esc_attr( $twleads_w ); ?>" <?php checked( 0, $twleads_i ); ?>><span><?php echo esc_html( $twleads_w ); ?></span></label>
					<?php endforeach; ?>
				</div>
			</fieldset>
		<?php endif; ?>
		<?php echo twleads_contact_fields( true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<?php echo twleads_form_submit( $attributes['buttonText'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	</form>
</div>
