<?php
/**
 * Service area list render.
 *
 * @package TradewellLeads
 * @var array $attributes Block attributes.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$twleads_areas = get_posts(
	array(
		'post_type'      => 'twleads_area',
		'post_status'    => 'publish',
		'posts_per_page' => 200, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- bounded, admin/cached lookup.
		'orderby'        => 'title',
		'order'          => 'ASC',
		'no_found_rows'  => true,
	)
);

$twleads_cols    = max( 1, min( 6, (int) $attributes['columns'] ) );
$twleads_wrapper = get_block_wrapper_attributes(
	array(
		'class' => 'twl twl-areas',
		'style' => '--twl-cols:' . $twleads_cols,
	)
);
?>
<div <?php echo $twleads_wrapper; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<?php if ( ! $twleads_areas ) : ?>
		<?php if ( current_user_can( 'edit_posts' ) ) : ?>
			<p class="twl-empty"><?php esc_html_e( 'Add your first Service Area under Leads > Service areas.', 'tradewell-leads' ); ?></p>
		<?php endif; ?>
	<?php else : ?>
		<ul class="twl-areas-list">
			<?php foreach ( $twleads_areas as $twleads_area ) : ?>
				<li>
					<a href="<?php echo esc_url( get_permalink( $twleads_area ) ); ?>"><?php echo twleads_icon( 'pin' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span><?php echo esc_html( get_the_title( $twleads_area ) ); ?></span></a>
					<?php if ( $attributes['showZips'] ) : ?>
						<small><?php echo esc_html( get_post_meta( $twleads_area->ID, '_twl_zips', true ) ); ?></small>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
</div>
