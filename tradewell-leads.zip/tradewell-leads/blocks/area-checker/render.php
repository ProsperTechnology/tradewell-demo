<?php
/**
 * Service area checker render.
 *
 * @package TradewellLeads
 * @var array $attributes Block attributes.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$twleads_h = max( 2, min( 6, (int) ( $attributes['headingLevel'] ?? 3 ) ) );

$twleads_uid     = wp_unique_id( 'twl-a-' );
$twleads_wrapper = get_block_wrapper_attributes( array( 'class' => 'twl twl-area' ) );
$twleads_archive = get_post_type_archive_link( 'twleads_area' );
$twleads_config  = array(
	'endpoint' => rest_url( 'twl/v1/areas' ),
	'i18n'     => array(
		/* translators: %s: area name. */
		'yesArea' => __( 'Yes! We serve %s.', 'tradewell-leads' ),
		'yes'     => __( 'Yes! We serve your area.', 'tradewell-leads' ),
		'see'     => __( 'See local details', 'tradewell-leads' ),
		'quote'   => __( 'Get a free estimate', 'tradewell-leads' ),
		/* translators: %s: ZIP code. */
		'no'      => __( 'We do not cover %s yet. Leave your number and we will call if we can help or know someone who can.', 'tradewell-leads' ),
		'bad'     => __( 'Please enter a valid ZIP code.', 'tradewell-leads' ),
	),
	'quote'    => twleads_quote_url(),
);
?>
<div <?php echo $twleads_wrapper; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> data-area="<?php echo esc_attr( wp_json_encode( $twleads_config ) ); ?>">
	<?php if ( $attributes['heading'] ) : ?>
		<h<?php echo (int) $twleads_h; ?> class="twl-title"><?php echo twleads_icon( 'pin' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <?php echo esc_html( $attributes['heading'] ); ?></h<?php echo (int) $twleads_h; ?>>
	<?php endif; ?>
	<form class="twl-area-form" action="<?php echo esc_url( $twleads_archive ? $twleads_archive : home_url( '/' ) ); ?>" method="get">
		<label class="screen-reader-text" for="<?php echo esc_attr( $twleads_uid ); ?>"><?php esc_html_e( 'ZIP code', 'tradewell-leads' ); ?></label>
		<input id="<?php echo esc_attr( $twleads_uid ); ?>" type="text" name="zip" inputmode="numeric" autocomplete="postal-code" maxlength="10" placeholder="<?php echo esc_attr( $attributes['placeholder'] ); ?>" required>
		<button type="submit" class="twl-btn wp-element-button"><?php echo esc_html( $attributes['buttonText'] ); ?></button>
	</form>
	<div class="twl-area-result" role="status" aria-live="polite">
	<?php
	// No-JavaScript result when the form was submitted normally.
	$twleads_zip = isset( $_GET['zip'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_GET['zip'] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( $twleads_zip ) {
		$twleads_map = twleads_zip_map();
		if ( isset( $twleads_map[ $twleads_zip ] ) ) {
			echo '<p class="is-yes">' . esc_html( $twleads_config['i18n']['yes'] ) . '</p>';
		} else {
			echo '<p class="is-no">' . esc_html( sprintf( $twleads_config['i18n']['no'], $twleads_zip ) ) . '</p>';
		}
	}
	?>
	</div>
	<div class="twl-area-waitlist" hidden>
		<?php echo twleads_form_open( 'area' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<input type="hidden" name="zip" value="">
			<div class="twl-grid">
				<?php
				// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- fields are escaped inside twleads_field().
				echo twleads_field(
					'name',
					__( 'Your name', 'tradewell-leads' ),
					array(
						'required'     => true,
						'autocomplete' => 'name',
					)
				);
				?>
				<?php
				echo twleads_field(
					'phone',
					__( 'Mobile phone', 'tradewell-leads' ),
					array(
						'type'         => 'tel',
						'required'     => true,
						'autocomplete' => 'tel',
						'inputmode'    => 'tel',
					)
				);
				// phpcs:enable
				?>
			</div>
			<?php echo twleads_form_submit( __( 'Call me', 'tradewell-leads' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</form>
	</div>
</div>
