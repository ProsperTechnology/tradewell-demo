<?php
/**
 * Phone button render.
 *
 * @package TradewellLeads
 * @var array $attributes Block attributes.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$twleads_phone = twleads_get( 'phone' );
if ( ! $twleads_phone ) {
	return;
}
$twleads_variant = in_array( $attributes['variant'], array( 'button', 'outline', 'text', 'dark' ), true ) ? $attributes['variant'] : 'button';
$twleads_classes = 'twl-phone twl-phone--' . $twleads_variant;
if ( 'text' !== $twleads_variant ) {
	$twleads_classes .= ' wp-element-button';
}
$twleads_wrapper = get_block_wrapper_attributes( array( 'class' => 'twl-phone-wrap' ) );
?>
<div <?php echo $twleads_wrapper; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>><a class="<?php echo esc_attr( $twleads_classes ); ?>" href="tel:<?php echo esc_attr( twleads_tel( $twleads_phone ) ); ?>"><?php echo twleads_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span>
<?php
if ( $attributes['label'] ) :
	?>
	<span class="twl-phone-label"><?php echo esc_html( $attributes['label'] ); ?></span> <?php endif; ?><?php echo esc_html( $twleads_phone ); ?></span></a></div>
