<?php
/**
 * Quote calculator render.
 *
 * @package TradewellLeads
 * @var array $attributes Block attributes.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$twleads_h = max( 2, min( 6, (int) ( $attributes['headingLevel'] ?? 3 ) ) );

$twleads_services = array();
foreach ( (array) $attributes['services'] as $twleads_s ) {
	if ( empty( $twleads_s['label'] ) ) {
		continue;
	}
	$twleads_services[] = array(
		'label'     => sanitize_text_field( $twleads_s['label'] ),
		'base'      => (float) ( $twleads_s['base'] ?? 0 ),
		'unit'      => sanitize_text_field( $twleads_s['unit'] ?? '' ),
		'unitPrice' => (float) ( $twleads_s['unitPrice'] ?? 0 ),
		'min'       => (float) ( $twleads_s['min'] ?? 0 ),
		'max'       => (float) ( $twleads_s['max'] ?? 0 ),
		'step'      => max( 0.01, (float) ( $twleads_s['step'] ?? 1 ) ),
		'def'       => (float) ( $twleads_s['def'] ?? 0 ),
	);
}

$twleads_config = array(
	'currency' => twleads_get( 'currency' ),
	'spread'   => max( 0, min( 60, (float) $attributes['spread'] ) ) / 100,
	'services' => $twleads_services,
	'urgency'  => array(
		'standard'  => 1,
		'next-day'  => 1.1,
		'emergency' => 1.25,
	),
	'i18n'     => array(
		'pick'    => __( 'Choose a service to see a price', 'tradewell-leads' ),
		/* translators: %s: service name. */
		'recap'   => __( 'Your estimate for %s:', 'tradewell-leads' ),
		'sending' => __( 'Sending…', 'tradewell-leads' ),
		'error'   => __( 'Something went wrong. Please call us instead.', 'tradewell-leads' ),
	),
);

$twleads_uid     = wp_unique_id( 'twl-q-' );
$twleads_wrapper = get_block_wrapper_attributes( array( 'class' => 'twl twl-quote' ) );
?>
<div <?php echo $twleads_wrapper; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
	<div class="twl-head">
		<h<?php echo (int) $twleads_h; ?> class="twl-title"><?php echo esc_html( $attributes['heading'] ); ?></h<?php echo (int) $twleads_h; ?>>
		<?php if ( $attributes['intro'] ) : ?>
			<p class="twl-intro"><?php echo esc_html( $attributes['intro'] ); ?></p>
		<?php endif; ?>
	</div>
	<?php echo twleads_fallback_notice(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	<?php echo twleads_form_open( 'quote', array( 'data-config' => wp_json_encode( $twleads_config ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<div class="twl-step" data-step="1">
			<fieldset class="twl-fieldset">
				<legend><?php esc_html_e( 'What do you need?', 'tradewell-leads' ); ?></legend>
				<div class="twl-chips">
					<?php foreach ( $twleads_services as $twleads_i => $twleads_s ) : ?>
						<label class="twl-chip"><input type="radio" name="service" value="<?php echo esc_attr( $twleads_s['label'] ); ?>" data-i="<?php echo esc_attr( $twleads_i ); ?>"><span><?php echo esc_html( $twleads_s['label'] ); ?></span></label>
					<?php endforeach; ?>
				</div>
			</fieldset>
			<div class="twl-size" hidden>
				<div class="twl-size-head"><label for="<?php echo esc_attr( $twleads_uid ); ?>-size" class="twl-size-label"><?php esc_html_e( 'Size', 'tradewell-leads' ); ?></label><output class="twl-size-out" for="<?php echo esc_attr( $twleads_uid ); ?>-size"></output></div>
				<input id="<?php echo esc_attr( $twleads_uid ); ?>-size" type="range" name="size" min="0" max="10" step="1" value="0">
			</div>
			<?php if ( $attributes['showUrgency'] ) : ?>
				<fieldset class="twl-fieldset">
					<legend><?php esc_html_e( 'How soon?', 'tradewell-leads' ); ?></legend>
					<div class="twl-chips twl-chips--row">
						<label class="twl-chip"><input type="radio" name="urgency" value="standard" checked><span><?php esc_html_e( 'This week', 'tradewell-leads' ); ?></span></label>
						<label class="twl-chip"><input type="radio" name="urgency" value="next-day"><span><?php esc_html_e( 'Next day', 'tradewell-leads' ); ?></span></label>
						<label class="twl-chip"><input type="radio" name="urgency" value="emergency"><span><?php esc_html_e( 'Emergency', 'tradewell-leads' ); ?></span></label>
					</div>
				</fieldset>
			<?php endif; ?>
			<div class="twl-estimate" aria-live="polite">
				<span class="twl-estimate-label"><?php esc_html_e( 'Estimated price', 'tradewell-leads' ); ?></span>
				<strong class="twl-estimate-value"><?php esc_html_e( 'Choose a service to see a price', 'tradewell-leads' ); ?></strong>
				<?php if ( $attributes['disclaimer'] ) : ?>
					<small><?php echo esc_html( $attributes['disclaimer'] ); ?></small>
				<?php endif; ?>
			</div>
			<input type="hidden" name="est_low" value="">
			<input type="hidden" name="est_high" value="">
			<button type="button" class="twl-btn twl-next wp-element-button" hidden disabled><?php esc_html_e( 'Lock in this estimate', 'tradewell-leads' ); ?> &rarr;</button>
		</div>
		<div class="twl-step" data-step="2">
			<button type="button" class="twl-back" hidden>&larr; <?php esc_html_e( 'Change details', 'tradewell-leads' ); ?></button>
			<p class="twl-recap" hidden></p>
			<?php echo twleads_contact_fields( false ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php echo twleads_form_submit( $attributes['buttonText'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</div>
	</form>
</div>
